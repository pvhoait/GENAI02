"""Test thuật toán của 4 bài - KHÔNG gọi model."""
from datetime import datetime, timedelta, timezone

import pytest

from app.exercises.ex01_reconcile.algorithm import ReconcileError, Transfer, find_single_exact, find_two_sum, split_eligible
from app.exercises.ex02_capacity.algorithm import CapacityError, choose_machine, hours_needed, min_required_rate
from app.exercises.ex03_notify.algorithm import ScheduleError, build_schedule, verify_schedule
from app.exercises.ex04_impact.algorithm import trace

VN = timezone(timedelta(hours=7))


# =============================================================== Bài 01
def tr(tid, amount, minute, cust="C-12", cur="VND", status="unmatched"):
    return Transfer(tid, cust, cur, amount, datetime(2026, 11, 3, 9, minute, tzinfo=VN), status)


SAMPLE_01 = [tr("P1", 900_000, 0), tr("P4", 600_000, 2, cust="C-99"), tr("P5", 600_000, 3, cur="USD"),
             tr("P2", 600_000, 5), tr("P3", 600_000, 10)]


def match(transfers, due=1_500_000):
    eligible, excluded = split_eligible(transfers, "C-12", "VND", due)
    return find_two_sum(eligible, due), excluded


def test_ex01_sample_P1_P2():
    res, excluded = match(SAMPLE_01)
    assert res["pair"] == ["P1", "P2"] and res["alternatives"] == [["P1", "P3"]]
    assert {e["transfer_id"] for e in excluded} == {"P4", "P5"}


def test_ex01_input_order_does_not_matter():
    assert match(list(reversed(SAMPLE_01)))[0]["pair"] == ["P1", "P2"]


def test_ex01_two_equal_amounts_distinct_ids():
    res, _ = match([tr("P21", 500_000, 5), tr("P20", 500_000, 5)], 1_000_000)
    assert res["pair"] == ["P20", "P21"]  # cùng giờ -> theo mã


def test_ex01_never_pairs_with_itself():
    assert match([tr("P30", 750_000, 0)])[0]["status"] == "no_match"


def test_ex01_matched_transfer_excluded():
    res, excluded = match([tr("P1", 900_000, 0), tr("P2", 600_000, 5, status="matched")])
    assert res["status"] == "no_match" and excluded[0]["transfer_id"] == "P2"


def test_ex01_negative_and_overshoot_ignored():
    res, _ = match([tr("A", 1_600_000, 0), tr("B", -100_000, 1)])
    assert res["status"] == "no_match"


def test_ex01_no_match_no_approximation():
    res, _ = match([tr("A", 700_000, 0), tr("B", 799_999, 1)])
    assert res["status"] == "no_match" and res["pair"] == []


def test_ex01_single_payment_bonus():
    eligible, _ = split_eligible([tr("A", 1_500_000, 0)], "C-12", "VND")
    assert find_single_exact(eligible, 1_500_000) == ["A"]


@pytest.mark.parametrize("due", [0, -5, 1.5, True])
def test_ex01_invalid_amount_due(due):
    with pytest.raises(ReconcileError):
        find_two_sum([], due)


def test_ex01_float_amount_rejected():
    with pytest.raises(ReconcileError):
        Transfer.from_dict({"transfer_id": "X", "customer_id": "C-1", "currency": "VND", "amount_minor": 10.5,
                            "received_at": "2026-11-03T09:00:00+07:00", "status": "unmatched"})


def test_ex01_linear_scan_large():
    many = [tr(f"T{i:06d}", 1_000 + i, 0) for i in range(100_000)]
    res, _ = match(many, 1_000 + 1_000 + 99_999 + 1)  # chỉ cặp đầu/cuối và vài cặp khác
    assert res["status"] == "matched"


# =============================================================== Bài 02
def test_ex02_sample_rate_11_machine_M2():
    res = min_required_rate([30, 11, 23, 4], 8)
    assert res["rate"] == 11 and res["hours_at_rate"] == 8 and res["hours_at_rate_minus_1"] == 9
    machines = [{"machine_id": "M1", "rate_per_hour": 8}, {"machine_id": "M2", "rate_per_hour": 12}, {"machine_id": "M3", "rate_per_hour": 16}]
    assert choose_machine(machines, 11)["machine_id"] == "M2"


def test_ex02_binary_search_equals_brute_force():
    import random
    rnd = random.Random(7)
    for _ in range(200):
        qs = [rnd.randint(0, 60) for _ in range(rnd.randint(1, 6))]
        hours = rnd.randint(0, 20)
        res = min_required_rate(qs, hours)
        if res["status"] == "ok":
            brute = next(r for r in range(1, 10_000) if hours_needed(qs, r) <= hours)
            assert res["rate"] == brute


def test_ex02_exactly_fits_shift():
    assert min_required_rate([0, 20, 0, 5], 3)["rate"] == 10


def test_ex02_zero_quantity_takes_no_time():
    assert hours_needed([0, 0, 10], 10) == 1


def test_ex02_no_batches_and_all_zero():
    assert min_required_rate([], 8)["status"] == "no_work"
    assert min_required_rate([0, 0], 8)["status"] == "no_work"


def test_ex02_fewer_hours_than_batches_impossible():
    assert min_required_rate([5, 5, 5], 2)["status"] == "impossible_under_rules"
    assert min_required_rate([5], 0)["status"] == "impossible_under_rules"


def test_ex02_no_machine_fast_enough():
    assert choose_machine([{"machine_id": "M8", "rate_per_hour": 40}], 100) is None


def test_ex02_tie_on_speed_picks_machine_id():
    ms = [{"machine_id": "M9", "rate_per_hour": 12}, {"machine_id": "M2", "rate_per_hour": 12}]
    assert choose_machine(ms, 11)["machine_id"] == "M2"


def test_ex02_setup_time_bonus():
    # 2 lô, mỗi lần đổi lô mất 1 giờ: cần ceil(q1/r)+ceil(q2/r)+1 <= 5
    assert min_required_rate([10, 10], 5, setup_hours=1)["rate"] == 5


@pytest.mark.parametrize("q,h", [([-1], 5), ([1.5], 5), (["3"], 5), ([3], -1), ([3], True)])
def test_ex02_invalid_input(q, h):
    with pytest.raises(CapacityError):
        min_required_rate(q, h)


def test_ex02_large_quantities_fast():
    res = min_required_rate([10**9, 7 * 10**8, 3], 10)
    assert res["iterations"] <= 31 and hours_needed([10**9, 7 * 10**8, 3], res["rate"]) <= 10


# =============================================================== Bài 03
SLOTS8 = [f"{h:02d}:00" for h in range(9, 17)]


def msgs(spec):
    return [{"message_id": f"{c}{i}", "customer_id": c} for c, n in spec.items() for i in range(1, n + 1)]


def row(res):
    return ["+".join(m["message_id"] for m in s["messages"]) or s["status"] for s in res["slots"]]


def test_ex03_sample_table():
    res = build_schedule(msgs({"A": 3, "B": 3}), SLOTS8, 2, {"A": True, "B": True})
    assert row(res) == ["A1", "B1", "idle", "A2", "B2", "idle", "A3", "B3"]
    assert res["violations"] == [] and res["unscheduled"] == []


def test_ex03_opt_out_removed_first():
    res = build_schedule(msgs({"A": 1, "C": 2}), SLOTS8[:3], 2, {"A": True, "C": False})
    assert row(res) == ["A1", "unused", "unused"] and len(res["excluded"]) == 2


def test_ex03_unknown_opt_in_treated_as_not_allowed():
    res = build_schedule(msgs({"Z": 1}), SLOTS8[:2], 0, {})
    assert res["scheduled_count"] == 0 and res["excluded"][0]["reason"] == "không rõ trạng thái đồng ý"


def test_ex03_single_customer_runs_out_of_slots():
    res = build_schedule(msgs({"X": 4}), SLOTS8[:6], 2, {"X": True})
    assert row(res) == ["X1", "idle", "idle", "X2", "idle", "idle"]
    assert [u["message_id"] for u in res["unscheduled"]] == ["X3", "X4"]


def test_ex03_gap_zero_and_ties_alphabetical():
    res = build_schedule(msgs({"G": 2, "E": 2, "F": 2}), SLOTS8[:6], 0, {c: True for c in "EFG"})
    assert row(res) == ["E1", "F1", "G1", "E2", "F2", "G2"]


def test_ex03_customer_with_more_messages_first():
    res = build_schedule(msgs({"A": 1, "B": 3}), SLOTS8, 1, {"A": True, "B": True})
    assert row(res)[:5] == ["B1", "A1", "B2", "idle", "B3"]


def test_ex03_daily_limit_bonus():
    res = build_schedule(msgs({"K": 3}), SLOTS8[:4], 0, {"K": True}, daily_limit=2)
    assert res["scheduled_count"] == 2 and "giới hạn" in res["unscheduled"][0]["reason"]


def test_ex03_verify_detects_violation():
    bad = [{"index": 0, "time": "09:00", "messages": [{"message_id": "A1", "customer_id": "A"}]},
           {"index": 1, "time": "10:00", "messages": [{"message_id": "A2", "customer_id": "A"}]}]
    assert verify_schedule(bad, gap=2)


@pytest.mark.parametrize("kwargs", [{"slots": []}, {"gap": -1}, {"slots": ["09:00", "09:00"]}])
def test_ex03_invalid_policy(kwargs):
    base = {"messages": msgs({"A": 1}), "slots": SLOTS8, "gap": 2, "opt_in": {"A": True}}
    with pytest.raises(ScheduleError):
        build_schedule(**{**base, **kwargs})


def test_ex03_duplicate_message_ids_rejected():
    with pytest.raises(ScheduleError):
        build_schedule([{"message_id": "A1", "customer_id": "A"}] * 2, SLOTS8, 0, {"A": True})


# =============================================================== Bài 04
NODES = ["DB", "Auth", "Reports", "Checkout", "MobileApp", "WebStore", "Inventory", "Search"]
EDGES = [["DB", "Auth"], ["DB", "Reports"], ["Auth", "Checkout"], ["Auth", "MobileApp"], ["Checkout", "WebStore"], ["Inventory", "Search"]]
CF = ["Reports", "MobileApp", "WebStore", "Search"]


def test_ex04_sample_paths():
    res = trace(NODES, EDGES, "DB", CF)
    assert [(a["service"], a["path"], a["hops"]) for a in res["customer_facing_affected"]] == [
        ("Reports", ["DB", "Reports"], 1), ("MobileApp", ["DB", "Auth", "MobileApp"], 2),
        ("WebStore", ["DB", "Auth", "Checkout", "WebStore"], 3)]
    assert res["customer_facing_not_reached"] == ["Search"] and res["incomplete_reasons"] == []


def test_ex04_edge_order_does_not_matter():
    assert trace(NODES, list(reversed(EDGES)), "DB", CF)["customer_facing_affected"] == trace(NODES, EDGES, "DB", CF)["customer_facing_affected"]


def test_ex04_shortest_path_chosen():
    res = trace(["A", "B", "C", "D"], [["A", "B"], ["B", "C"], ["C", "D"], ["A", "D"]], "A", ["D"])
    assert res["customer_facing_affected"][0]["path"] == ["A", "D"]


def test_ex04_cycle_terminates():
    res = trace(["DB", "Auth", "Checkout", "Cart"], [["DB", "Auth"], ["Auth", "Checkout"], ["Checkout", "Cart"], ["Cart", "Auth"]], "DB", ["Cart"])
    assert res["customer_facing_affected"][0]["hops"] == 3 and res["revisits"] >= 1


def test_ex04_duplicate_edges_and_self_loop_warned():
    res = trace(["A", "B"], [["A", "B"], ["A", "B"], ["B", "B"]], "A", ["B"])
    assert len(res["warnings"]) == 2 and res["customer_facing_affected"][0]["hops"] == 1


def test_ex04_missing_node_is_incomplete():
    res = trace(["DB", "WebStore"], [["DB", "Gateway"], ["Gateway", "WebStore"]], "DB", ["WebStore"])
    assert res["incomplete_reasons"]


def test_ex04_source_not_in_graph():
    res = trace(NODES, EDGES, "Payments", CF)
    assert res["affected"] == [] and res["incomplete_reasons"]


def test_ex04_large_graph_linear():
    n = 50_000
    nodes = [f"S{i}" for i in range(n)]
    edges = [[f"S{i}", f"S{i + 1}"] for i in range(n - 1)] + [[f"S{i}", f"S{i + 2}"] for i in range(0, n - 2, 5)]
    res = trace(nodes, edges, "S0", [f"S{n - 1}"])
    assert res["customer_facing_affected"][0]["hops"] < n
