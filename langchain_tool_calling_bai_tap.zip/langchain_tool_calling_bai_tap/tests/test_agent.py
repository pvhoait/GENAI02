"""Test vòng lặp Tool Calling, an toàn công cụ và API - không cần API key."""
import json

from fastapi.testclient import TestClient
from langchain_core.messages import AIMessage, ToolMessage

from app.core.agent import MockToolModel, execute_tool_call, run_agent
from app.exercises import EXERCISES
from app.exercises.ex01_reconcile import LEDGER
from app.main import create_app


class ScriptedModel:
    """Model giả trả về các AIMessage định sẵn; ghi lại messages nhận được."""

    name = "scripted"

    def __init__(self, replies):
        self.replies, self.seen = list(replies), []

    def invoke(self, messages):
        self.seen.append(list(messages))
        return self.replies.pop(0) if self.replies else AIMessage(content="xong")


def call(name, args, cid="c1"):
    return AIMessage(content="", tool_calls=[{"name": name, "args": args, "id": cid, "type": "tool_call"}])


def tools(eid):
    return {t.name: t for t in EXERCISES[eid].tools}


# ------------------------------------------------------------------ an toàn công cụ
def test_unknown_tool_rejected():
    r = execute_tool_call(tools("ex01"), {"name": "run_sql", "args": {"query": "DROP TABLE invoices"}})
    assert r["error_code"] == "unknown_tool"


def test_bad_argument_pattern_rejected():
    r = execute_tool_call(tools("ex01"), {"name": "get_open_invoice", "args": {"invoice_id": "I-77; DROP"}})
    assert r["error_code"] == "invalid_arguments"


def test_extra_arguments_rejected_model_cannot_inject_amounts():
    r = execute_tool_call(tools("ex01"), {"name": "find_two_transfer_match",
                                          "args": {"invoice_id": "I-77", "amounts": [1500000, 0]}})
    assert r["error_code"] == "invalid_arguments" and "amounts" in r["message"]


def test_tool_exception_becomes_error_result():
    r = execute_tool_call(tools("ex03"), {"name": "build_send_schedule", "args": {"campaign_id": "CMP-ERR"}})
    assert r["ok"] is False and r["error_code"] == "tool_error"


def test_tool_message_has_matching_id_and_loop_stops():
    model = ScriptedModel([call("get_open_invoice", {"invoice_id": "I-77"}, "abc123"), AIMessage(content="Đã đọc hóa đơn.")])
    run = run_agent(EXERCISES["ex01"], "Kiểm tra I-77", model)
    tool_msgs = [m for m in model.seen[1] if isinstance(m, ToolMessage)]
    assert tool_msgs[0].tool_call_id == "abc123" and json.loads(tool_msgs[0].content)["ok"]
    assert run["answer"] == "Đã đọc hóa đơn." and run["grounded"] is False  # chưa gọi công cụ thuật toán


def test_step_limit():
    model = ScriptedModel([call("get_open_invoice", {"invoice_id": "I-77"}, f"c{i}") for i in range(20)])
    run = run_agent(EXERCISES["ex01"], "Kiểm tra I-77", model, max_steps=3)
    assert run["stopped_reason"] == "max_steps" and len(run["tool_calls"]) == 3


def test_model_error_reported():
    class Broken:
        def invoke(self, _):
            raise TimeoutError("hết thời gian")
    run = run_agent(EXERCISES["ex01"], "Kiểm tra I-77", Broken())
    assert run["stopped_reason"] == "model_error" and "hết thời gian" in run["answer"]


def test_algorithm_tool_rereads_backend_not_model_data():
    LEDGER.transfers.append({"transfer_id": "P0", "customer_id": "C-12", "currency": "VND", "amount_minor": 600_000,
                             "received_at": "2026-11-03T08:00:00+07:00", "status": "unmatched"})
    r = execute_tool_call(tools("ex01"), {"name": "find_two_transfer_match", "args": {"invoice_id": "I-77"}})
    assert r["pair"] == ["P0", "P1"]  # dữ liệu mới nhất trong backend được dùng


# ------------------------------------------------------------------ luồng mock theo đề
def mock(eid, q):
    return run_agent(EXERCISES[eid], q, MockToolModel(EXERCISES[eid]))


def test_flow_ex01_and_proposal_does_not_change_ledger():
    run = mock("ex01", "Kiểm tra I-77 và ghi nhận luôn")
    assert [c["name"] for c in run["tool_calls"]] == ["get_open_invoice", "list_unmatched_transfers",
                                                      "find_two_transfer_match", "propose_invoice_match"]
    assert run["artifacts"]["find_two_transfer_match"]["pair"] == ["P1", "P2"]
    assert run["proposals"][0]["status"] == "pending_approval"
    assert LEDGER.invoices["I-77"]["status"] == "open"
    assert all(t["status"] == "unmatched" for t in LEDGER.transfers if t["transfer_id"] in ("P1", "P2"))


def test_flow_ex01_errors():
    assert "Không tìm thấy" in mock("ex01", "Kiểm tra hóa đơn I-404")["answer"]
    assert "paid" in mock("ex01", "Kiểm tra hóa đơn I-78")["answer"]
    assert mock("ex01", "Hai khoản nào trả đủ?")["tool_calls"] == []


def test_flow_ex02_asks_for_missing_shift():
    run = mock("ex02", "Máy nào kịp xong L1?")
    assert run["tool_calls"] == [] and "ca" in run["answer"]


def test_flow_ex02_sample_and_data_change():
    assert mock("ex02", "L1 ca S1")["artifacts"]["calculate_min_required_rate"]["recommended_machine"]["machine_id"] == "M2"
    run = mock("ex02", "Kiểm tra L5 ca S2")
    assert "đã đổi" in run["answer"] and run["artifacts"]["calculate_min_required_rate"]["recommended_machine"]["machine_id"] == "M12"


def test_flow_ex03_sample_and_no_sending():
    run = mock("ex03", "Gửi ngay chiến dịch CMP-1")
    assert run["artifacts"]["build_send_schedule"]["status"] == "proposed_not_sent"
    assert "không gửi" in run["answer"].lower()
    assert all("send" not in c["name"] or c["name"] == "build_send_schedule" for c in run["tool_calls"])


def test_flow_ex03_tool_error_not_hidden():
    run = mock("ex03", "Xếp lịch CMP-ERR")
    assert run["grounded"] is False and "báo lỗi" in run["answer"]


def test_flow_ex04_sample_and_incomplete():
    run = mock("ex04", "Sự cố INC-9 ảnh hưởng đến đâu?")
    assert run["artifacts"]["trace_impact"]["status"] == "ok" and "CÓ THỂ" in run["answer"]
    assert mock("ex04", "Phân tích INC-13")["artifacts"]["trace_impact"]["status"] == "incomplete_data"


# ------------------------------------------------------------------ API
def test_api_chat_history_and_proposal_decision(tmp_path):
    client = TestClient(create_app(tmp_path / "runs.jsonl"))
    run = client.post("/api/chat", json={"exercise": "ex02", "question": "L1 ca S1: đặt máy M2", "mode": "mock"}).json()
    assert run["proposals"] and client.get(f"/api/runs/{run['run_id']}").json()["question"] == "L1 ca S1: đặt máy M2"
    pid = run["proposals"][0]["proposal_id"]
    assert client.post(f"/api/proposals/{pid}/decision", json={"decision": "approve", "reviewer": ""}).status_code == 422
    ok = client.post(f"/api/proposals/{pid}/decision", json={"decision": "approve", "reviewer": "Trưởng ca Lan"})
    assert ok.json()["status"] == "approved"
    assert client.post(f"/api/proposals/{pid}/decision", json={"decision": "reject", "reviewer": "X"}).status_code == 409
    log = (tmp_path / "runs.jsonl").read_text("utf-8")
    assert "calculate_min_required_rate" in log


def test_api_openai_mode_without_key(tmp_path):
    client = TestClient(create_app(tmp_path / "r.jsonl"))
    r = client.post("/api/chat", json={"exercise": "ex01", "question": "I-77", "mode": "openai"})
    assert r.status_code == 400
    assert client.post("/api/chat", json={"exercise": "ex99", "question": "x", "mode": "mock"}).status_code == 404
