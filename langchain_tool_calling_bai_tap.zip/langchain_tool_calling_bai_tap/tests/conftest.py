import pytest

from app.core.stores import PROPOSALS
from app.exercises import reset_all


@pytest.fixture(autouse=True)
def clean_state(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    reset_all()
    PROPOSALS.clear()
    yield
