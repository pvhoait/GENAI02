# Bộ bài tập LangChain Tool Calling × Thuật toán

M��t web app chat cho cả 4 bài (đề cho phép ghép). Người dùng hỏi bằng tiếng Việt. AI **chọn công cụ** để đọc dữ liệu và gọi công cụ thuật toán. **Backend** kiểm tra lời gọi, chạy công cụ và tính toán. **Người dùng** xem câu trả lời, mọi lần gọi công cụ, dữ liệu đã dùng và duyệt đề xuất.

| Bài | Câu hỏi | Thuật toán | File thuật toán |
|---|---|---|---|
| 01 Đối soát hóa đơn | Hai khoản chuyển tiền nào trả đủ hóa đơn? | Hash map tìm hai số có tổng cho trước | `app/exercises/ex01_reconcile/algorithm.py` |
| 02 Công suất sản xuất | Cần máy nhanh cỡ nào để kịp ca? | Tìm kiếm nhị phân trên đáp án | `app/exercises/ex02_capacity/algorithm.py` |
| 03 Lịch gửi thông báo | Gửi khi nào để không làm phiền khách? | Max-heap + hàng đợi chờ | `app/exercises/ex03_notify/algorithm.py` |
| 04 Tác động sự cố | Một dịch vụ hỏng ảnh hưởng đến đâu? | BFS + lưu điểm trước đó | `app/exercises/ex04_impact/algorithm.py` |

![Bài 01](docs/screenshot_ex01.png)

## Cài đặt và chạy

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # điền OPENAI_API_KEY nếu muốn dùng OpenAI
uvicorn app.main:app --reload      # mở http://localhost:8000
pytest -q                          # 66 test, không cần API key
```

Không có `OPENAI_API_KEY` thì app dùng **MockToolModel**: một model giả trả về `AIMessage.tool_calls` y như model thật, theo kịch bản cố định của từng bài. Vòng lặp, phần kiểm tra tham số, `ToolMessage`, thuật toán và lưu vết đều chạy thật; chỉ phần "suy nghĩ" của model là giả lập. Có thể chọn chế độ ngay trên giao diện: Tự động, Mock hoặc OpenAI.

## Cấu trúc

```
app/
├── core/
│   ├── agent.py       Vòng lặp Tool Calling dùng chung, kiểm tra tên + tham số công cụ, MockToolModel
│   └── stores.py      Lưu lịch sử chạy (data/runs.jsonl), đề xuất chờ duyệt, định dạng tiền
├── exercises/
│   ├── ex01_reconcile/   __init__.py: dữ liệu giả lập + @tool + system prompt + kịch bản mock
│   ├── ex02_capacity/    algorithm.py: thuật toán thuần Python, test được không cần model
│   ├── ex03_notify/
│   └── ex04_impact/
├── main.py            FastAPI
└── static/index.html  Giao diện chat
sample_data/           Dữ liệu giả của 4 bài (gồm cả các ca lỗi/biên)
tests/
├── test_algorithms.py  Thuật toán 4 bài: ca thường, ca biên, dữ liệu sai, hiệu năng
└── test_agent.py       Vòng lặp Tool Calling, an toàn công cụ, luồng theo đề, API
docs/                   Ảnh chụp luồng chat của 4 bài
```

## Luồng Tool Calling

Code nằm ở `app/core/agent.py`:

1. Mỗi công cụ được khai báo bằng `@tool(args_schema=...)`. Model OpenAI được gắn công cụ bằng `llm.bind_tools(exercise.tools)`.
2. Backend gửi `SystemMessage` (quy trình của bài) và `HumanMessage` (câu hỏi), rồi gọi `model.invoke`.
3. Nếu `AIMessage` có `tool_calls`, backend xử lý **từng lời gọi**:
   - Tên công cụ phải nằm trong danh sách của bài. Nếu không, trả lỗi `unknown_tool`. Model không thể gọi SQL, URL hay hàm tùy ý.
   - Tham số được kiểm tra bằng Pydantic: mã phải đúng mẫu (`I-77`, `L1`, `CMP-1`, `INC-9`...), và **trường lạ bị từ chối** (`extra="forbid"`). Vì vậy model không thể tự truyền danh sách số tiền hay cạnh đồ thị.
   - Backend tự chạy công cụ. Mọi ngoại lệ được bắt lại thành kết quả lỗi, server không sập.
   - Kết quả được gửi lại model bằng `ToolMessage(content=JSON, tool_call_id=<đúng id>)`.
4. Vòng lặp chạy tối đa 8 bước và tối đa 6 lời gọi mỗi bước, đến khi model trả câu trả lời cuối. Vượt giới hạn hoặc model lỗi thì dừng và nói rõ.
5. Mỗi lượt chạy được đánh dấu `grounded` nếu công cụ thuật toán đã chạy thành công. Giao diện cảnh báo khi câu trả lời không dựa trên kết quả thuật toán.

**Công cụ thuật toán không tin dữ liệu từ model.** `find_two_transfer_match`, `calculate_min_required_rate`, `build_send_schedule` và `trace_impact` chỉ nhận ID, rồi tự đọc lại dữ liệu mới nhất trong backend.

**Hành động thay đổi dữ liệu chỉ tạo đề xuất.** `propose_invoice_match` và `propose_machine_assignment` tạo bản ghi `pending_approval`. Người duyệt phải nhập tên mới duyệt hoặc từ chối được, và việc duyệt chỉ ghi nhận quyết định, không thay đổi sổ sách hay khóa máy. Bài 03 không có công cụ gửi tin; Bài 04 không có công cụ khởi động lại dịch vụ.

## API

| Method | Đường dẫn | Việc làm |
|---|---|---|
| GET | `/api/exercises` | Danh sách bài, câu hỏi mẫu, công cụ và tham số |
| POST | `/api/chat` | `{exercise, question, mode}` → câu trả lời, các lần gọi công cụ, kết quả thuật toán, đề xuất |
| GET | `/api/runs?exercise=` / `/api/runs/{id}` | Lịch sử để xem lại |
| GET | `/api/proposals` | Đề xuất và trạng thái |
| POST | `/api/proposals/{id}/decision` | `{decision: approve/reject, reviewer, note}` |
| POST | `/api/demo/reset` | Khôi phục dữ liệu mẫu |

M��i lượt chạy được ghi vào `data/runs.jsonl`, gồm câu hỏi, model, từng lần gọi công cụ (tên, tham số, kết quả hoặc lỗi, `tool_call_id`, thời gian), kết quả thuật toán, đề xuất và câu trả lời.

## Bài 01 - Đối soát hóa đơn

**Công cụ:** `get_open_invoice` → `list_unmatched_transfers` (khách và loại tiền lấy từ hóa đơn) → `find_two_transfer_match` → `propose_invoice_match` (chỉ khi người dùng yêu cầu ghi nhận).

**Thuật toán:**
- Chỉ xét giao dịch unmatched, cùng khách, cùng loại tiền, số tiền dương. Sắp theo giờ nhận rồi mã giao dịch.
- Dùng hash map `số tiền → các giao dịch đã gặp`. Với mỗi khoản `x`, tra `amount_due - x` **trước** khi thêm `x`, nên một giao dịch không ghép với chính nó.
- Cặp được chọn là cặp hoàn thành sớm nhất khi quét. Tiền là số nguyên ở đơn vị nhỏ nhất.
- Độ phức tạp: O(n) sau bước sắp xếp.

**Kết quả với dữ liệu trong đề:** P1 + P2 = 1.500.000 VND. P1 + P3 được liệt kê là cặp khác nhưng hoàn thành muộn hơn. P4 bị loại vì sai khách (dù số tiền trông như khớp), P5 vì sai loại tiền.

**Ca biên:** I-78 đã thanh toán, I-404 không tồn tại, I-79 không có cặp (có cả khoản tiền âm), I-80 có hai khoản cùng số tiền, I-81 chỉ có một khoản bằng nửa hóa đơn (không tự ghép), I-82 có giao dịch đã ghép, I-83 có một khoản đủ tiền (phần làm thêm, chỉ gợi ý xem thủ công).

## Bài 02 - Công suất sản xuất

**Công cụ:** `get_open_batches`, `get_shift_hours`, `get_available_machines` → `calculate_min_required_rate` → `propose_machine_assignment` (khi người dùng muốn đặt máy). Thiếu mã dây chuyền hoặc mã ca thì AI hỏi lại.

**Thuật toán:**
- Ở tốc độ r, số giờ cần là `Σ ceil(q/r)`; lô 0 sản phẩm không chiếm giờ.
- Hàm này giảm dần khi r tăng, nên dùng tìm kiếm nhị phân trên khoảng `[1, max q]`.
- Nếu số giờ ít hơn số lô có sản phẩm thì trả `impossible_under_rules`.
- Chọn máy chậm nhất vẫn đạt yêu cầu.

**Kết quả với dữ liệu trong đề:** tốc độ 11. Ở 10 cần 3+2+3+1 = 9 giờ, ở 11 cần 3+1+3+1 = 8 giờ. Chọn máy M2.

**Ca biên:**
- L1/S0: ca 0 giờ.
- L2: không có lô.
- L3: có lô 0 sản phẩm, vừa khít ca.
- L4: thiếu công suất.
- L5/S2: dữ liệu máy đổi sau khi AI đọc. Công cụ đọc lại, báo phiên bản 1 → 2 và chọn M12.
- L6: không có máy rảnh.
- L1/S9: ca không tồn tại.

**Phần làm thêm:** `setup_hours` (giờ chuẩn bị giữa hai lô) có trong thuật toán và test; hằng `SETUP_HOURS` trong `ex02_capacity/__init__.py`.

## Bài 03 - Lịch gửi thông báo

**Công cụ:** `get_pending_messages`, `get_contact_policy`, `get_opt_in_status` → `build_send_schedule`. Công cụ xếp lịch tự kiểm tra lại quyền nhận tin, không dùng danh sách khách từ model.

**Thuật toán:**
- Loại tin của khách chưa đồng ý; khách không rõ trạng thái cũng bị loại.
- Max-heap ưu tiên khách còn nhiều tin, hòa thì theo mã khách.
- Khách vừa nhận ở ô i vào hàng đợi chờ đến ô `i + gap + 1`.
- Ô không ai đủ điều kiện là `idle`. Hết ô mà còn tin thì báo "chưa xếp được", không đẩy sang ngày khác.
- Sau khi xếp, `verify_schedule` kiểm tra lại toàn bộ lịch một cách độc lập.

**Kết quả với dữ liệu trong đề:** A1 B1 idle A2 B2 idle A3 B3. Kết quả luôn được trình bày là lịch đề xuất, chưa gửi.

**Ca biên:**
- CMP-2: có khách từ chối nhận tin và khách không rõ trạng thái.
- CMP-3: chỉ một khách, hết khung giờ.
- CMP-4: gap = 0, ba khách cùng số tin.
- CMP-5: giới hạn 2 tin mỗi ngày (phần làm thêm).
- CMP-ERR: công cụ đọc chính sách bị lỗi.
- "Gửi ngay": AI giải thích cần người có quyền duyệt và không gửi.

## Bài 04 - Tác động sự cố

**Công cụ:** `get_incident` → `get_service_graph`, `get_customer_facing_services` → `trace_impact`. AI truyền phiên bản sơ đồ vừa đọc để backend phát hiện sơ đồ đổi giữa chừng.

**Thuật toán:**
- BFS từ dịch vụ lỗi, có tập điểm đã thăm (không lặp vô hạn khi có vòng) và "điểm trước đó" để dựng đường đi ngắn nhất.
- Chỉ dựng đường đi đầy đủ cho dịch vụ người dùng thấy, giữ đúng O(V + E). Ban đầu tôi dựng cho mọi điểm và test hiệu năng đã bắt được lỗi bộ nhớ O(V²).

**Kết quả với dữ liệu trong đề:** Reports (1 cạnh), MobileApp (2), WebStore (3). Search không có đường đi từ DB nên không vào danh sách.

**Ca biên:**
- INC-10: vòng và cạnh trùng.
- INC-11: sơ đồ thiếu node.
- INC-12: sơ đồ quá cũ.
- INC-13: sơ đồ đổi phiên bản trong lúc xử lý.
- INC-14: dịch vụ lỗi không có trong sơ đồ.
- INC-8: sự cố đã đóng.
- INC-404: sự cố không tồn tại.

Các ca thiếu dữ liệu đều trả `incomplete_data`. Câu trả lời luôn nói "có thể bị ảnh hưởng", không khẳng định đã hỏng.

**Phần làm thêm:** gợi ý thứ tự kiểm tra theo số người dùng.

## Test

66 test, chạy không cần API key:

- **Thuật toán (`test_algorithms.py`):** ví dụ của đề cho cả 4 bài; ca biên (hai khoản bằng nhau, khít ca, gap = 0, vòng, cạnh trùng...); dữ liệu sai (tiền thực, số âm, chính sách rỗng, mã trùng...).
  - Tìm kiếm nhị phân được so với cách thử từng tốc độ trên 200 bộ dữ liệu ngẫu nhiên.
  - Hiệu năng: 100.000 giao dịch, 50.000 dịch vụ.
- **Tool Calling (`test_agent.py`):**
  - Từ chối công cụ lạ, tham số sai mẫu và tham số thừa (model không chèn được danh sách số tiền).
  - Công cụ lỗi được báo lại; `ToolMessage` có đúng `tool_call_id`.
  - Có giới hạn bước; model lỗi được báo rõ.
  - Công cụ thuật toán đọc lại dữ liệu backend.
  - Đề xuất không làm đổi sổ sách.
  - Duyệt đề xuất cần tên người duyệt và không duyệt được hai lần; lịch sử được ghi ra file.

## Vì sao GenAI cần gọi công cụ?

Model không có số liệu của doanh nghiệp: hóa đơn, giao dịch, lô hàng, máy, tin chờ gửi, sơ đồ dịch vụ đều nằm trong hệ thống và thay đổi liên tục. Nếu để model tự trả lời, nó sẽ đoán số tiền, đoán đường ảnh hưởng từ tên dịch vụ, hoặc tính nhẩm sai. Tool Calling chia việc rõ ràng:

- **Model** hiểu câu hỏi tiếng Việt, hỏi lại khi thiếu mã, chọn công cụ theo thứ tự hợp lý (đọc hóa đơn trước mới biết khách và loại tiền) và giải thích kết quả.
- **Backend** giữ dữ liệu thật, kiểm tra mọi lời gọi, chạy thuật toán cho kết quả đúng và lặp lại được.
- **Con người** xem toàn bộ dấu vết và là người duy nhất duyệt các hành động thay đổi dữ liệu.
