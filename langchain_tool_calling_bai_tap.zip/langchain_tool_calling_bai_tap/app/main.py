"""FastAPI backend: một web app chat cho cả 4 bài Tool Calling.

API key chỉ nằm ở backend (.env). Frontend chỉ gửi câu hỏi và nhận kết quả.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .core.agent import MAX_STEPS, get_model, run_agent
from .core.stores import PROPOSALS, RunStore
from .exercises import EXERCISES, reset_all

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent


class ChatRequest(BaseModel):
    exercise: str
    question: str = Field(min_length=1, max_length=1000)
    mode: Literal["auto", "mock", "openai"] = "auto"


class DecisionRequest(BaseModel):
    decision: Literal["approve", "reject"]
    reviewer: str = Field(min_length=1, max_length=60, description="Người có quyền duyệt")
    note: Optional[str] = Field(default=None, max_length=500)


def create_app(log_path: Optional[Path] = None) -> FastAPI:
    app = FastAPI(title="LangChain Tool Calling × Thuật toán", version="1.0.0")
    runs = RunStore(log_path)
    app.state.runs = runs

    def exercise_or_404(eid: str):
        ex = EXERCISES.get(eid)
        if ex is None:
            raise HTTPException(404, detail={"message": f"Không có bài '{eid}'.", "errors": []})
        return ex

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/api/config")
    def config() -> dict[str, Any]:
        return {"openai_available": bool(os.getenv("OPENAI_API_KEY")), "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
                "max_steps": MAX_STEPS}

    @app.get("/api/exercises")
    def exercises() -> list[dict[str, Any]]:
        return [{"id": e.id, "title": e.title, "sample_questions": e.sample_questions,
                 "algorithm_tools": sorted(e.algorithm_tools),
                 "tools": [{"name": t.name, "description": t.description,
                            "args": t.args_schema.model_json_schema().get("properties", {})} for t in e.tools]}
                for e in EXERCISES.values()]

    @app.post("/api/chat")
    def chat(req: ChatRequest) -> dict[str, Any]:
        ex = exercise_or_404(req.exercise)
        try:
            model = get_model(ex, req.mode)
        except RuntimeError as exc:
            raise HTTPException(400, detail={"message": str(exc), "errors": []})
        run = run_agent(ex, req.question.strip(), model)
        run["mode"] = req.mode
        runs.add(run)
        return run

    @app.get("/api/runs")
    def list_runs(exercise: Optional[str] = None, limit: int = Query(30, ge=1, le=200)) -> list[dict[str, Any]]:
        return [{k: r[k] for k in ("run_id", "exercise", "question", "created_at", "grounded", "stopped_reason", "model")}
                | {"tools": [c["name"] for c in r["tool_calls"]]} for r in runs.list(exercise, limit)]

    @app.get("/api/runs/{run_id}")
    def get_run(run_id: str) -> dict[str, Any]:
        run = runs.get(run_id)
        if run is None:
            raise HTTPException(404, detail={"message": "Không tìm thấy lượt chạy.", "errors": []})
        return run

    @app.get("/api/proposals")
    def proposals() -> list[dict[str, Any]]:
        return list(reversed(PROPOSALS.items.values()))

    @app.post("/api/proposals/{pid}/decision")
    def decide(pid: str, req: DecisionRequest) -> dict[str, Any]:
        if pid not in PROPOSALS.items:
            raise HTTPException(404, detail={"message": f"Không có đề xuất {pid}.", "errors": []})
        try:
            return PROPOSALS.decide(pid, req.decision, req.reviewer.strip(), req.note)
        except ValueError as exc:
            raise HTTPException(409, detail={"message": str(exc), "errors": []})

    @app.post("/api/demo/reset")
    def reset() -> dict[str, Any]:
        reset_all()
        PROPOSALS.clear()
        runs.runs.clear()
        return {"ok": True}

    return app


app = create_app(Path(os.getenv("AUDIT_LOG_PATH", str(BASE_DIR.parent / "data" / "runs.jsonl"))))
