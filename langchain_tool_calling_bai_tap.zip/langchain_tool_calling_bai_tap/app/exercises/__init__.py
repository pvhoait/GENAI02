from ..core.agent import Exercise
from . import ex01_reconcile, ex02_capacity, ex03_notify, ex04_impact

EXERCISES: dict[str, Exercise] = {m.EXERCISE.id: m.EXERCISE for m in (ex01_reconcile, ex02_capacity, ex03_notify, ex04_impact)}


def reset_all() -> None:
    ex01_reconcile.LEDGER.reset()
    ex02_capacity.PLANT.reset()
    ex03_notify.MKT.reset()
    ex04_impact.OPS.reset()
