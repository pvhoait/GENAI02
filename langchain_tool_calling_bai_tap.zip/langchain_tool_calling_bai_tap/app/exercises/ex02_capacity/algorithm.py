"""Thuật toán Bài 02 - tốc độ nguyên nhỏ nhất để xong mọi lô trong ca. Không phụ thuộc GenAI.

Một máy làm lần lượt từng lô; lô q sản phẩm ở tốc độ r chiếm ceil(q / r) giờ (không ghép giờ lẻ).
hours_needed(r) giảm dần khi r tăng (đơn điệu) => tìm kiếm nhị phân trên đáp án r trong [1, max(q)].
Mỗi bước kiểm tra O(n) => tổng O(n log max(q)).
"""
from __future__ import annotations

from typing import Any, Optional


class CapacityError(ValueError):
    pass


def _int(value: Any, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise CapacityError(f"{name} phải là số nguyên >= {minimum} (nhận {value!r}).")
    return value


def ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def hours_needed(quantities: list[int], rate: int, setup_hours: int = 0) -> int:
    positive = [q for q in quantities if q > 0]
    if not positive:
        return 0
    return sum(ceil_div(q, rate) for q in positive) + setup_hours * (len(positive) - 1)


def min_required_rate(quantities: list[int], hours: int, setup_hours: int = 0) -> dict[str, Any]:
    quantities = [_int(q, "Số lượng lô") for q in quantities]
    hours = _int(hours, "Số giờ còn lại")
    setup_hours = _int(setup_hours, "Giờ chuẩn bị giữa hai lô")
    positive = [q for q in quantities if q > 0]
    if not positive:
        return {"status": "no_work", "rate": None, "reason": "Không còn lô nào có sản phẩm cần làm."}
    floor_hours = len(positive) + setup_hours * (len(positive) - 1)
    if hours < floor_hours:
        return {"status": "impossible_under_rules", "rate": None,
                "reason": f"Ca còn {hours} giờ nhưng {len(positive)} lô có sản phẩm cần ít nhất {floor_hours} giờ "
                          "(mỗi lô ít nhất 1 giờ dù máy nhanh đến đâu)."}
    lo, hi, iterations = 1, max(positive), 0  # ở r = max(q), mỗi lô đúng 1 giờ => luôn khả thi ở đây
    while lo < hi:
        iterations += 1
        mid = (lo + hi) // 2
        if hours_needed(positive, mid, setup_hours) <= hours:
            hi = mid
        else:
            lo = mid + 1
    return {"status": "ok", "rate": lo, "hours_at_rate": hours_needed(positive, lo, setup_hours),
            "hours_at_rate_minus_1": hours_needed(positive, lo - 1, setup_hours) if lo > 1 else None,
            "search_range": [1, max(positive)], "iterations": iterations}


def choose_machine(machines: list[dict[str, Any]], rate: int) -> Optional[dict[str, Any]]:
    """Máy chậm nhất vẫn đạt tốc độ yêu cầu (giữ máy nhanh cho việc khác); hòa thì theo mã."""
    ok = [m for m in machines if _int(m["rate_per_hour"], f"Tốc độ máy {m['machine_id']}", 1) >= rate]
    return min(ok, key=lambda m: (m["rate_per_hour"], m["machine_id"])) if ok else None
