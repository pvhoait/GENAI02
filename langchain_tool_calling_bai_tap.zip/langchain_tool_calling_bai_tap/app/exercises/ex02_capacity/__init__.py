"""Bài 02 - Cần máy nhanh cỡ nào để kịp ca sản xuất?"""
from __future__ import annotations

import re

from langchain_core.tools import tool
from pydantic import Field

from ...core.agent import Exercise, ToolArgs
from ...core.stores import PROPOSALS, load_json
from .algorithm import CapacityError, ceil_div, choose_machine, min_required_rate

LINE_ID, SHIFT_ID = r"^L\d{1,3}$", r"^S\d{1,3}$"
SETUP_HOURS = 0  # phần làm thêm: giờ chuẩn bị giữa hai lô


class Plant:
    """Ba nguồn dữ liệu giả lập: hệ thống sản xuất (lô), lịch ca (giờ), quản lý thiết bị (máy)."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self.lines = load_json("ex02_production.json")["lines"]
        self.machine_reads: dict[str, int] = {}

    def new_run(self) -> None:
        self.machine_reads = {}

    def read_machines(self, line_id: str) -> tuple[list[dict], int]:
        """Mỗi lần đọc có thể thấy phiên bản mới hơn (mô phỏng máy đổi trạng thái)."""
        versions = self.lines[line_id]["machine_versions"]
        n = self.machine_reads.get(line_id, 0)
        self.machine_reads[line_id] = n + 1
        idx = min(n, len(versions) - 1)
        idle = [m for m in versions[idx] if m["status"] == "idle"]
        return sorted(idle, key=lambda m: m["machine_id"]), idx + 1


PLANT = Plant()


def _err(code: str, message: str) -> dict:
    return {"ok": False, "error_code": code, "message": message}


def _line(line_id: str):
    line = PLANT.lines.get(line_id)
    return (line, None) if line else (None, _err("line_not_found", f"Không có dây chuyền {line_id}."))


class LineArgs(ToolArgs):
    line_id: str = Field(pattern=LINE_ID, description="Mã dây chuyền, ví dụ L1.")


class LineShiftArgs(ToolArgs):
    line_id: str = Field(pattern=LINE_ID, description="Mã dây chuyền, ví dụ L1.")
    shift_id: str = Field(pattern=SHIFT_ID, description="Mã ca, ví dụ S1.")


class ProposeArgs(LineShiftArgs):
    machine_id: str = Field(pattern=r"^M\d{1,4}$", description="Máy muốn đặt, ví dụ M2.")


@tool(args_schema=LineArgs)
def get_open_batches(line_id: str) -> dict:
    """Các lô chưa làm của dây chuyền và số sản phẩm mỗi lô."""
    line, e = _line(line_id)
    return e or {"ok": True, "line_id": line_id, "batches": line["batches"]}


@tool(args_schema=LineShiftArgs)
def get_shift_hours(line_id: str, shift_id: str) -> dict:
    """Số giờ còn dùng được trong ca."""
    line, e = _line(line_id)
    if e:
        return e
    shift = line["shifts"].get(shift_id)
    if shift is None:
        return _err("shift_not_found", f"Dây chuyền {line_id} không có ca {shift_id}.")
    return {"ok": True, "line_id": line_id, "shift_id": shift_id, "remaining_hours": shift["remaining_hours"]}


@tool(args_schema=LineArgs)
def get_available_machines(line_id: str) -> dict:
    """Máy đang rảnh của dây chuyền và tốc độ mỗi máy (sản phẩm/giờ)."""
    line, e = _line(line_id)
    if e:
        return e
    machines, version = PLANT.read_machines(line_id)
    return {"ok": True, "line_id": line_id, "machines": machines, "data_version": version}


def _calculate(line_id: str, shift_id: str) -> dict:
    line, e = _line(line_id)
    if e:
        return e
    shift = line["shifts"].get(shift_id)
    if shift is None:
        return _err("shift_not_found", f"Dây chuyền {line_id} không có ca {shift_id}.")
    batches, hours = line["batches"], shift["remaining_hours"]
    machines, version = PLANT.read_machines(line_id)  # đọc LẠI dữ liệu mới nhất
    try:
        res = min_required_rate([b["quantity"] for b in batches], hours, SETUP_HOURS)
    except CapacityError as exc:
        return _err("invalid_data", str(exc))
    out = {"ok": True, "line_id": line_id, "shift_id": shift_id, "remaining_hours": hours, "setup_hours": SETUP_HOURS,
           "machines": machines, "machines_data_version": version, **res,
           "rule": "Máy làm lần lượt từng lô; lô q sản phẩm ở tốc độ r mất ceil(q/r) giờ; không ghép giờ lẻ; đổi lô mất 0 giờ."}
    if res["status"] != "ok":
        out["batches"] = batches
        return out
    r = res["rate"]
    out["batches"] = [{**b, "hours_at_rate": ceil_div(b["quantity"], r) if b["quantity"] > 0 else 0,
                       "hours_at_rate_minus_1": (ceil_div(b["quantity"], r - 1) if b["quantity"] > 0 else 0) if r > 1 else None}
                      for b in batches]
    try:
        best = choose_machine(machines, r)
    except CapacityError as exc:
        return _err("invalid_data", str(exc))
    out["eligible_machines"] = [m["machine_id"] for m in machines if m["rate_per_hour"] >= r]
    if not machines:
        out["machine_status"], out["recommended_machine"] = "no_machine_available", None
    elif best is None:
        out["machine_status"], out["recommended_machine"] = "insufficient_capacity", None
    else:
        out["machine_status"], out["recommended_machine"] = "ok", best
    return out


@tool(args_schema=LineShiftArgs)
def calculate_min_required_rate(line_id: str, shift_id: str) -> dict:
    """Chạy thuật toán tìm tốc độ nguyên nhỏ nhất để xong mọi lô trong ca và máy rảnh phù hợp.
    Công cụ tự đọc lại lô, giờ ca và máy từ backend."""
    return _calculate(line_id, shift_id)


@tool(args_schema=ProposeArgs)
def propose_machine_assignment(line_id: str, shift_id: str, machine_id: str) -> dict:
    """Tạo ĐỀ XUẤT dùng một máy cho ca, chờ trưởng ca xác nhận. Không khóa máy."""
    calc = _calculate(line_id, shift_id)
    if not calc["ok"]:
        return calc
    if calc["status"] != "ok":
        return _err("not_feasible", f"Không thể đề xuất máy: {calc.get('reason')}")
    m = next((x for x in calc["machines"] if x["machine_id"] == machine_id), None)
    if m is None:
        return _err("machine_not_available", f"Máy {machine_id} hiện không rảnh trên dây chuyền {line_id}.")
    if m["rate_per_hour"] < calc["rate"]:
        return _err("machine_too_slow", f"Máy {machine_id} chạy {m['rate_per_hour']} sp/giờ, cần ít nhất {calc['rate']}.")
    p = PROPOSALS.create("machine_assignment", {"line_id": line_id, "shift_id": shift_id, "machine_id": machine_id},
                         f"Dùng máy {machine_id} cho dây chuyền {line_id}, ca {shift_id}")
    return {"ok": True, "proposal": p, "note": "Đề xuất chờ trưởng ca xác nhận; máy chưa bị khóa."}


TOOLS = [get_open_batches, get_shift_hours, get_available_machines, calculate_min_required_rate, propose_machine_assignment]

SYSTEM_PROMPT = """Bạn là trợ lý lập kế hoạch sản xuất cho trưởng ca. Bạn KHÔNG có sẵn số liệu lô, giờ ca hay máy.
Quy trình:
1. Cần cả line_id (vd L1) và shift_id (vd S1). Nếu người dùng chưa nói, hãy hỏi lại; không đoán.
2. Gọi get_open_batches, get_shift_hours, get_available_machines để nắm dữ liệu.
3. Gọi calculate_min_required_rate để thuật toán tính tốc độ tối thiểu. Không tự tính nhẩm.
4. Chỉ khi người dùng muốn đặt/giữ máy, gọi propose_machine_assignment và nói rõ đây là đề xuất chờ trưởng ca xác nhận.
Nếu impossible_under_rules, no_work, insufficient_capacity hoặc no_machine_available: nói rõ, không nhận là ca khả thi.
Nếu machines_data_version khác lần đọc trước: báo dữ liệu máy đã đổi và dùng kết quả mới nhất.
Trả lời tiếng Việt: tốc độ tối thiểu, so sánh với tốc độ thấp hơn 1, máy đề xuất và vì sao."""


def mock_policy(question: str, history: list[dict]) -> dict:
    ml, ms = re.search(r"\bL\d+\b", question, re.I), re.search(r"\bS\d+\b", question, re.I)
    if not ml or not ms:
        missing = [x for x, ok in (("dây chuyền (vd L1)", ml), ("ca (vd S1)", ms)) if not ok]
        return {"answer": f"Bạn cho tôi biết thêm {' và '.join(missing)} nhé. Tôi cần đúng mã để đọc lô, giờ ca và máy."}
    line, shift = ml.group(0).upper(), ms.group(0).upper()
    done = {h["name"]: h["result"] for h in history}
    for name, args in (("get_open_batches", {"line_id": line}), ("get_shift_hours", {"line_id": line, "shift_id": shift}),
                       ("get_available_machines", {"line_id": line}), ("calculate_min_required_rate", {"line_id": line, "shift_id": shift})):
        if name not in done:
            return {"tool_calls": [(name, args)]}
        if not done[name]["ok"]:
            return {"answer": f"Tôi chưa trả lời được vì {done[name]['message']}"}
    c = done["calculate_min_required_rate"]
    wants_book = re.search(r"đặt máy|giữ máy|khóa máy|book|dùng máy", question.lower())
    asked = re.search(r"\bM\d+\b", question, re.I)
    if wants_book and c["status"] == "ok" and "propose_machine_assignment" not in done and (asked or c.get("recommended_machine")):
        mid = asked.group(0).upper() if asked else c["recommended_machine"]["machine_id"]
        return {"tool_calls": [("propose_machine_assignment", {"line_id": line, "shift_id": shift, "machine_id": mid})]}

    lines = [f"Dây chuyền {line}, ca {shift}: còn {c['remaining_hours']} giờ."]
    if c["status"] != "ok":
        lines.append(f"Kết quả: {c['status']}. {c['reason']}")
        return {"answer": "\n".join(lines)}
    qs = [b["quantity"] for b in c["batches"]]
    lines.append(f"Các lô: {', '.join(f'{b['batch_id']}={b['quantity']}' for b in c['batches'])} sản phẩm.")
    r = c["rate"]
    per_r = " + ".join(str(b["hours_at_rate"]) for b in c["batches"] if b["quantity"] > 0)
    lines.append(f"Tốc độ tối thiểu: {r} sản phẩm/giờ. Ở {r}: {per_r} = {c['hours_at_rate']} giờ, vừa đủ trong {c['remaining_hours']} giờ.")
    if c["hours_at_rate_minus_1"] is not None:
        per_r1 = " + ".join(str(b["hours_at_rate_minus_1"]) for b in c["batches"] if b["quantity"] > 0)
        lines.append(f"Ở {r - 1}: {per_r1} = {c['hours_at_rate_minus_1']} giờ, vượt ca.")
    if 0 in qs:
        lines.append("Lô có 0 sản phẩm không chiếm giờ nào.")
    before = done["get_available_machines"].get("data_version")
    if before != c["machines_data_version"]:
        lines.append(f"Lưu ý: dữ liệu máy đã đổi từ phiên bản {before} sang {c['machines_data_version']} kể từ lần đọc trước; "
                     "kết quả dưới đây dùng dữ liệu mới nhất.")
    if c["machine_status"] == "ok":
        m = c["recommended_machine"]
        lines.append(f"Đề xuất máy {m['machine_id']} ({m['rate_per_hour']} sp/giờ): máy chậm nhất vẫn đạt yêu cầu. "
                     f"Máy đạt yêu cầu: {', '.join(c['eligible_machines'])}.")
    elif c["machine_status"] == "insufficient_capacity":
        lines.append("Thiếu công suất: không máy rảnh nào đạt tốc độ này, ca hiện KHÔNG khả thi với máy đang có.")
    else:
        lines.append("Không có máy nào đang rảnh trên dây chuyền này.")
    if "propose_machine_assignment" in done:
        p = done["propose_machine_assignment"]
        lines.append(f"Đã tạo đề xuất {p['proposal']['proposal_id']} chờ trưởng ca xác nhận; máy chưa bị khóa."
                     if p["ok"] else f"Không tạo được đề xuất: {p['message']}")
    return {"answer": "\n".join(lines)}


EXERCISE = Exercise(
    id="ex02", title="Công suất sản xuất", system_prompt=SYSTEM_PROMPT, tools=TOOLS,
    algorithm_tools={"calculate_min_required_rate"}, mock_policy=mock_policy,
    sample_questions=[
        "Dây chuyền L1 ca S1 cần máy nhanh cỡ nào?", "L1 ca S1: đặt máy M2 giúp tôi", "Máy nào kịp xong L1 trước hết ca?",
        "Kiểm tra L3 ca S1", "Kiểm tra L4 ca S1", "Kiểm tra L5 ca S2", "Kiểm tra L1 ca S0", "Kiểm tra L2 ca S1",
        "Kiểm tra L6 ca S1", "Kiểm tra L1 ca S9",
    ],
    on_run_start=PLANT.new_run,
)
