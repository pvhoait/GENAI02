"""Bài 03 - Gửi thông báo khi nào để không làm phiền khách?"""
from __future__ import annotations

import re

from langchain_core.tools import tool
from pydantic import Field

from ...core.agent import Exercise, ToolArgs
from ...core.stores import load_json
from .algorithm import ScheduleError, build_schedule

CAMPAIGN_ID = r"^CMP-[A-Z0-9]{1,10}$"


class Marketing:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        data = load_json("ex03_campaigns.json")
        self.opt_in, self.campaigns = data["opt_in"], data["campaigns"]

    def policy(self, campaign_id: str) -> dict:
        c = self.campaigns[campaign_id]
        if c.get("policy_unavailable"):
            raise ConnectionError("Hệ thống chính sách liên hệ không phản hồi (mô phỏng sự cố).")
        return c["policy"]


MKT = Marketing()


def _err(code: str, message: str) -> dict:
    return {"ok": False, "error_code": code, "message": message}


class CampaignArgs(ToolArgs):
    campaign_id: str = Field(pattern=CAMPAIGN_ID, description="Mã chiến dịch, ví dụ CMP-1.")


class OptInArgs(ToolArgs):
    customer_ids: list[str] = Field(min_length=1, max_length=200, description="Các mã khách cần kiểm tra.")


@tool(args_schema=CampaignArgs)
def get_pending_messages(campaign_id: str) -> dict:
    """Các tin đang chờ gửi của chiến dịch: mã tin và mã người nhận."""
    c = MKT.campaigns.get(campaign_id)
    if c is None:
        return _err("campaign_not_found", f"Không có chiến dịch {campaign_id}.")
    return {"ok": True, "campaign_id": campaign_id, "name": c["name"],
            "messages": sorted(c["messages"], key=lambda m: m["message_id"])}


@tool(args_schema=CampaignArgs)
def get_contact_policy(campaign_id: str) -> dict:
    """Quy tắc liên hệ: khung giờ được dùng, số tin tối đa mỗi khung, số ô phải cách giữa hai tin cho cùng khách."""
    if campaign_id not in MKT.campaigns:
        return _err("campaign_not_found", f"Không có chiến dịch {campaign_id}.")
    return {"ok": True, "campaign_id": campaign_id, "policy": MKT.policy(campaign_id)}


@tool(args_schema=OptInArgs)
def get_opt_in_status(customer_ids: list[str]) -> dict:
    """Khách nào đã đồng ý nhận tin (true), đã từ chối (false) hoặc không rõ (null)."""
    return {"ok": True, "status": {c: MKT.opt_in.get(c) for c in sorted(set(customer_ids))}}


@tool(args_schema=CampaignArgs)
def build_send_schedule(campaign_id: str) -> dict:
    """Chạy thuật toán xếp LỊCH ĐỀ XUẤT từ dữ liệu mới nhất trong backend (tự kiểm tra lại quyền nhận tin).
    Không gửi tin nào."""
    c = MKT.campaigns.get(campaign_id)
    if c is None:
        return _err("campaign_not_found", f"Không có chiến dịch {campaign_id}.")
    policy = MKT.policy(campaign_id)  # lỗi đọc -> agent bắt và báo lại
    opt_in = {m["customer_id"]: MKT.opt_in.get(m["customer_id"]) for m in c["messages"]}  # đọc lại, không tin danh sách từ model
    try:
        res = build_schedule(c["messages"], policy["slots"], policy["gap_slots"], opt_in,
                             policy.get("max_per_slot", 1), policy.get("max_per_customer_per_day"))
    except ScheduleError as exc:
        return _err("invalid_data", str(exc))
    return {"ok": True, "campaign_id": campaign_id, "policy": policy, "opt_in_checked": opt_in, **res,
            "status": "proposed_not_sent",
            "rule": f"Mỗi ô tối đa {policy.get('max_per_slot', 1)} tin; nhận ở ô i thì sớm nhất ô i+{policy['gap_slots'] + 1}; "
                    "ưu tiên khách còn nhiều tin, hòa thì theo mã khách."}


TOOLS = [get_pending_messages, get_contact_policy, get_opt_in_status, build_send_schedule]

SYSTEM_PROMPT = """Bạn là trợ lý lập lịch gửi thông báo cho đội marketing. Bạn KHÔNG có sẵn danh sách tin hay quy tắc.
Quy trình:
1. Cần campaign_id (vd CMP-1). Nếu người dùng chưa nói, hãy hỏi lại.
2. Gọi get_pending_messages, get_contact_policy, rồi get_opt_in_status với các khách trong danh sách tin.
3. Gọi build_send_schedule để thuật toán xếp lịch. Không tự xếp lịch.
Trình bày: quy tắc, khách bị loại vì chưa đồng ý, lịch từng ô (kể cả ô idle), tin chưa xếp được.
Luôn nói đây là LỊCH ĐỀ XUẤT, chưa gửi. Không có công cụ gửi tin: nếu người dùng muốn "gửi ngay",
giải thích cần người có quyền duyệt và bài tập không gọi API gửi tin. Nếu công cụ lỗi, nói rõ, không bịa lịch."""


def mock_policy(question: str, history: list[dict]) -> dict:
    m = re.search(r"\bCMP-[A-Z0-9]+\b", question, re.I)
    if not m:
        return {"answer": "Bạn muốn xếp lịch cho chiến dịch nào? Hãy cho tôi mã, ví dụ CMP-1."}
    cid = m.group(0).upper()
    done = {h["name"]: h["result"] for h in history}
    for name in ("get_pending_messages", "get_contact_policy"):
        if name not in done:
            return {"tool_calls": [(name, {"campaign_id": cid})]}
        if not done[name]["ok"]:
            return {"answer": f"Tôi chưa xếp được lịch vì công cụ {name} báo lỗi: {done[name]['message']} "
                              "Tôi không tự đoán quy tắc hay lịch gửi."}
    if "get_opt_in_status" not in done:
        custs = sorted({x["customer_id"] for x in done["get_pending_messages"]["messages"]})
        return {"tool_calls": [("get_opt_in_status", {"customer_ids": custs})]}
    if "build_send_schedule" not in done:
        return {"tool_calls": [("build_send_schedule", {"campaign_id": cid})]}
    s = done["build_send_schedule"]
    if not s["ok"]:
        return {"answer": f"Thuật toán không xếp được lịch: {s['message']}"}
    p = s["policy"]
    lines = [f"Chiến dịch {cid}: {len(p['slots'])} ô từ {p['slots'][0]} đến {p['slots'][-1]}, mỗi ô tối đa {p.get('max_per_slot', 1)} tin, "
             f"hai tin cho cùng khách phải cách ít nhất {p['gap_slots']} ô."]
    if s["excluded"]:
        lines.append("Đã loại trước khi xếp: " + "; ".join(f"{e['message_id']} của {e['customer_id']} ({e['reason']})" for e in s["excluded"]) + ".")
    lines.append("Lịch đề xuất: " + ", ".join(
        f"{x['time']} {'+'.join(mm['message_id'] for mm in x['messages']) or x['status']}" for x in s["slots"]) + ".")
    lines.append(f"Đã xếp {s['scheduled_count']} tin." + (f" Ô idle: {', '.join(s['idle_slots'])} (không khách nào đủ điều kiện)." if s["idle_slots"] else ""))
    if s["unscheduled"]:
        lines.append("Chưa xếp được: " + "; ".join(f"{u['message_id']} ({u['reason']})" for u in s["unscheduled"]) + ". Tôi không tự đẩy sang ngày khác.")
    lines.append("Kiểm tra lại lịch: " + ("không có vi phạm." if not s["violations"] else "; ".join(s["violations"])))
    if re.search(r"gửi ngay|gửi luôn|gửi đi", question.lower()):
        lines.append("Tôi không gửi tin: cần người có quyền duyệt lịch này, và bài tập không có công cụ gọi API gửi tin.")
    else:
        lines.append("Đây là lịch đề xuất, chưa có tin nào được gửi.")
    return {"answer": "\n".join(lines)}


EXERCISE = Exercise(
    id="ex03", title="Lịch gửi thông báo", system_prompt=SYSTEM_PROMPT, tools=TOOLS,
    algorithm_tools={"build_send_schedule"}, mock_policy=mock_policy,
    sample_questions=[
        "Hôm nay nên xếp các tin của CMP-1 vào khung giờ nào?", "Gửi ngay chiến dịch CMP-1", "Xếp lịch CMP-2",
        "Xếp lịch CMP-3", "Xếp lịch CMP-4", "Xếp lịch CMP-5", "Xếp lịch CMP-ERR", "Xếp lịch CMP-77", "Nên gửi tin lúc nào?",
    ],
)
