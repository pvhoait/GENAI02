"""Thuật toán Bài 03 - xếp lịch gửi thông báo với khoảng cách tối thiểu cho cùng khách. Không phụ thuộc GenAI.

- Max-heap (dùng heapq với khóa âm): ưu tiên khách còn NHIỀU tin; hòa thì mã khách theo alphabet.
- Hàng đợi chờ (deque): khách vừa nhận tin ở ô i chỉ được nhận tiếp từ ô i + gap + 1.
  Vì i tăng dần nên hàng đợi luôn theo thứ tự thời điểm sẵn sàng (FIFO đủ dùng).
- Ô không có khách nào đủ điều kiện -> idle. Hết ô mà còn tin -> báo chưa xếp được, không đẩy sang ngày khác.
Độ phức tạp: O(S + M log C) với S ô, M tin, C khách.
"""
from __future__ import annotations

import heapq
from collections import deque
from typing import Any, Optional


class ScheduleError(ValueError):
    pass


def _check_int(v: Any, name: str, minimum: int) -> int:
    if isinstance(v, bool) or not isinstance(v, int) or v < minimum:
        raise ScheduleError(f"{name} phải là số nguyên >= {minimum} (nhận {v!r}).")
    return v


def build_schedule(messages: list[dict], slots: list[str], gap: int, opt_in: dict[str, Optional[bool]],
                   max_per_slot: int = 1, daily_limit: Optional[int] = None) -> dict[str, Any]:
    if not isinstance(slots, list) or not slots:
        raise ScheduleError("Chính sách không có khung giờ nào được dùng.")
    if len(set(slots)) != len(slots):
        raise ScheduleError("Khung giờ bị trùng.")
    gap = _check_int(gap, "gap", 0)
    max_per_slot = _check_int(max_per_slot, "max_per_slot", 1)
    if daily_limit is not None:
        daily_limit = _check_int(daily_limit, "max_per_customer_per_day", 1)
    ids = [m["message_id"] for m in messages]
    if len(set(ids)) != len(ids):
        raise ScheduleError("Mã tin bị trùng.")

    excluded, queues = [], {}
    for m in sorted(messages, key=lambda m: (m["customer_id"], m["message_id"])):
        status = opt_in.get(m["customer_id"])
        if status is not True:
            excluded.append({**m, "reason": "khách chưa đồng ý nhận tin" if status is False else "không rõ trạng thái đồng ý"})
            continue
        queues.setdefault(m["customer_id"], deque()).append(m["message_id"])

    heap = [(-len(q), c) for c, q in queues.items()]
    heapq.heapify(heap)
    waiting: deque[tuple[int, str]] = deque()
    sent: dict[str, int] = {}
    limit_hit: set[str] = set()
    out_slots = []
    for i, label in enumerate(slots):
        while waiting and waiting[0][0] <= i:
            _, c = waiting.popleft()
            heapq.heappush(heap, (-len(queues[c]), c))
        picked = []
        while heap and len(picked) < max_per_slot:
            _, c = heapq.heappop(heap)
            picked.append({"message_id": queues[c].popleft(), "customer_id": c})
            sent[c] = sent.get(c, 0) + 1
        for p in picked:
            c = p["customer_id"]
            if queues[c]:
                if daily_limit is not None and sent[c] >= daily_limit:
                    limit_hit.add(c)
                else:
                    waiting.append((i + gap + 1, c))
        status = "send" if picked else ("idle" if heap or waiting else "unused")
        out_slots.append({"index": i, "time": label, "status": status, "messages": picked})

    unscheduled = [{"message_id": m, "customer_id": c,
                    "reason": f"khách đã đạt giới hạn {daily_limit} tin/ngày" if c in limit_hit else "hết khung giờ trong ngày"}
                   for c in sorted(queues) for m in queues[c]]
    return {"slots": out_slots, "excluded": excluded, "unscheduled": unscheduled,
            "scheduled_count": sum(len(s["messages"]) for s in out_slots),
            "idle_slots": [s["time"] for s in out_slots if s["status"] == "idle"],
            "violations": verify_schedule(out_slots, gap, max_per_slot, daily_limit)}


def verify_schedule(slots: list[dict], gap: int, max_per_slot: int = 1, daily_limit: Optional[int] = None) -> list[str]:
    """Kiểm tra lại toàn bộ lịch độc lập với cách xếp: số tin mỗi ô, khoảng cách, giới hạn ngày."""
    problems, last, count = [], {}, {}
    for s in slots:
        if len(s["messages"]) > max_per_slot:
            problems.append(f"Ô {s['time']} có {len(s['messages'])} tin, vượt {max_per_slot}.")
        for m in s["messages"]:
            c = m["customer_id"]
            if c in last and s["index"] - last[c] <= gap:
                problems.append(f"Khách {c} nhận tin ở ô {last[c]} và {s['index']}: chưa cách đủ {gap} ô.")
            last[c] = s["index"]
            count[c] = count.get(c, 0) + 1
            if daily_limit is not None and count[c] > daily_limit:
                problems.append(f"Khách {c} nhận quá {daily_limit} tin/ngày.")
    return problems
