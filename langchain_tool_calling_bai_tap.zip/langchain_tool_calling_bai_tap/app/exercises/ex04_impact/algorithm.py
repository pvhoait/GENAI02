"""Thuật toán Bài 04 - BFS tìm phần có thể bị ảnh hưởng và đường đi ngắn nhất. Không phụ thuộc GenAI.

Cạnh A -> B nghĩa là B phụ thuộc vào A: A lỗi thì B có thể bị ảnh hưởng.
BFS từ dịch vụ lỗi, đánh dấu điểm đã đi qua (không lặp vô hạn khi có vòng),
lưu "điểm trước đó" để dựng lại đường đi ngắn nhất (ít cạnh nhất). O(V + E).
"""
from __future__ import annotations

from collections import deque
from typing import Any


def trace(nodes: list[str], edges: list[list[str]], source: str, customer_facing: list[str]) -> dict[str, Any]:
    warnings: list[str] = []
    incomplete: list[str] = []
    node_set = set(nodes)
    adj: dict[str, set[str]] = {}
    seen_edges: set[tuple[str, str]] = set()
    duplicates, missing, self_loops = [], set(), []
    for e in edges:
        if not isinstance(e, (list, tuple)) or len(e) != 2:
            incomplete.append(f"Cạnh sai định dạng: {e!r}.")
            continue
        a, b = e
        if a == b:
            self_loops.append(a)
            continue
        if (a, b) in seen_edges:
            duplicates.append(f"{a} → {b}")
            continue
        seen_edges.add((a, b))
        adj.setdefault(a, set()).add(b)
        missing.update(x for x in (a, b) if x not in node_set)
    if duplicates:
        warnings.append(f"Cạnh trùng chỉ tính một lần: {', '.join(duplicates)}.")
    if self_loops:
        warnings.append(f"Bỏ qua cạnh tự trỏ: {', '.join(sorted(set(self_loops)))}.")
    if missing:
        incomplete.append(f"Sơ đồ có cạnh trỏ tới dịch vụ không khai báo: {', '.join(sorted(missing))}.")
    for cf in customer_facing:
        if cf not in node_set:
            incomplete.append(f"Dịch vụ người dùng thấy '{cf}' không có trong sơ đồ.")

    if source not in node_set and source not in adj:
        incomplete.append(f"Dịch vụ lỗi '{source}' không có trong sơ đồ.")
        return {"source": source, "affected": [], "customer_facing_affected": [], "customer_facing_not_reached": sorted(customer_facing),
                "warnings": warnings, "incomplete_reasons": incomplete, "revisits": 0}

    parent: dict[str, str | None] = {source: None}
    dist = {source: 0}
    queue = deque([source])
    revisits = 0  # cạnh trỏ tới điểm đã thăm (có vòng hoặc nhiều đường) - không đi lại
    while queue:
        u = queue.popleft()
        for v in sorted(adj.get(u, ())):  # sắp xếp để kết quả ổn định
            if v in dist:
                revisits += 1
                continue
            dist[v], parent[v] = dist[u] + 1, u
            queue.append(v)

    def path_to(v: str) -> list[str]:
        out = []
        while v is not None:
            out.append(v)
            v = parent[v]
        return out[::-1]

    cf_set = set(customer_facing)
    # Chỉ dựng đường đi đầy đủ cho dịch vụ người dùng thấy (dựng cho mọi điểm sẽ tốn O(V^2) bộ nhớ).
    affected = sorted(({"service": v, "hops": d, "via": parent[v]} for v, d in dist.items() if v != source),
                      key=lambda x: (x["hops"], x["service"]))
    cf_affected = [{"service": a["service"], "hops": a["hops"], "path": path_to(a["service"])}
                   for a in affected if a["service"] in cf_set]
    return {
        "source": source,
        "affected": affected,
        "customer_facing_affected": cf_affected,
        "customer_facing_not_reached": sorted(c for c in customer_facing if c not in dist),
        "warnings": warnings, "incomplete_reasons": incomplete, "revisits": revisits,
    }
