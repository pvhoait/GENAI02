"""Bài 04 - Một dịch vụ hỏng sẽ ảnh hưởng đến đâu?"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional

from langchain_core.tools import tool
from pydantic import Field

from ...core.agent import Exercise, ToolArgs
from ...core.stores import load_json
from .algorithm import trace

INCIDENT_ID, SYSTEM_ID = r"^INC-\d{1,6}$", r"^[A-Z][A-Z0-9-]{1,20}$"
MAX_GRAPH_AGE = timedelta(days=30)


class Ops:
    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        data = load_json("ex04_systems.json")
        self.incidents, self.systems = data["incidents"], data["systems"]
        self.graph_reads: dict[str, int] = {}

    def new_run(self) -> None:
        self.graph_reads = {}

    def read_graph(self, system_id: str) -> dict:
        versions = self.systems[system_id]["versions"]
        n = self.graph_reads.get(system_id, 0)
        self.graph_reads[system_id] = n + 1
        return versions[min(n, len(versions) - 1)]


OPS = Ops()


def _err(code: str, message: str) -> dict:
    return {"ok": False, "error_code": code, "message": message}


class IncidentArgs(ToolArgs):
    incident_id: str = Field(pattern=INCIDENT_ID, description="Mã sự cố, ví dụ INC-9.")


class SystemArgs(ToolArgs):
    system_id: str = Field(pattern=SYSTEM_ID, description="Mã hệ thống lấy từ sự cố, ví dụ SHOP.")


class TraceArgs(IncidentArgs):
    expected_graph_version: Optional[str] = Field(default=None, max_length=20,
                                                  description="Phiên bản sơ đồ đã đọc trước đó, để phát hiện sơ đồ đổi giữa chừng.")


@tool(args_schema=IncidentArgs)
def get_incident(incident_id: str) -> dict:
    """Đọc sự cố: hệ thống, dịch vụ bị lỗi, thời điểm phát hiện, trạng thái."""
    inc = OPS.incidents.get(incident_id)
    return {"ok": True, "incident_id": incident_id, **inc} if inc else _err("incident_not_found", f"Không có sự cố {incident_id}.")


@tool(args_schema=SystemArgs)
def get_service_graph(system_id: str) -> dict:
    """Sơ đồ phụ thuộc của hệ thống: danh sách dịch vụ, cạnh A -> B (B phụ thuộc A), phiên bản và thời điểm cập nhật."""
    if system_id not in OPS.systems:
        return _err("system_not_found", f"Không có hệ thống {system_id}.")
    return {"ok": True, "system_id": system_id, **OPS.read_graph(system_id)}


@tool(args_schema=SystemArgs)
def get_customer_facing_services(system_id: str) -> dict:
    """Những dịch vụ người dùng trực tiếp thấy, kèm số người dùng."""
    if system_id not in OPS.systems:
        return _err("system_not_found", f"Không có hệ thống {system_id}.")
    return {"ok": True, "system_id": system_id, "services": OPS.systems[system_id]["customer_facing"]}


@tool(args_schema=TraceArgs)
def trace_impact(incident_id: str, expected_graph_version: Optional[str] = None) -> dict:
    """Chạy BFS từ dịch vụ lỗi trên sơ đồ MỚI NHẤT trong backend: các phần có thể bị ảnh hưởng và đường đi ngắn nhất.
    Công cụ tự đọc lại sự cố và sơ đồ theo ID; không nhận cạnh từ bên ngoài. Chỉ phân tích, không thay đổi hệ thống."""
    inc = OPS.incidents.get(incident_id)
    if inc is None:
        return _err("incident_not_found", f"Không có sự cố {incident_id}.")
    if inc["system_id"] not in OPS.systems:
        return _err("system_not_found", f"Không có hệ thống {inc['system_id']}.")
    graph = OPS.read_graph(inc["system_id"])
    cf = OPS.systems[inc["system_id"]]["customer_facing"]
    res = trace(graph["nodes"], graph["edges"], inc["service"], [c["service"] for c in cf])
    reasons = list(res["incomplete_reasons"])
    age = datetime.fromisoformat(inc["detected_at"]) - datetime.fromisoformat(graph["updated_at"])
    if age > MAX_GRAPH_AGE:
        reasons.append(f"Sơ đồ {graph['version']} cập nhật lần cuối {graph['updated_at'][:10]}, cũ hơn {age.days} ngày so với lúc phát hiện sự cố.")
    if expected_graph_version and expected_graph_version != graph["version"]:
        reasons.append(f"Sơ đồ đã đổi từ {expected_graph_version} sang {graph['version']} trong lúc xử lý; kết quả dùng {graph['version']}, nên kiểm tra lại.")
    users = {c["service"]: c["users"] for c in cf}
    affected_cf = [{**a, "users": users.get(a["service"])} for a in res["customer_facing_affected"]]
    return {
        "ok": True, "incident_id": incident_id, "system_id": inc["system_id"], "incident_status": inc["status"],
        "graph_version": graph["version"], "graph_updated_at": graph["updated_at"],
        "status": "incomplete_data" if reasons else "ok", "incomplete_reasons": reasons,
        **{k: v for k, v in res.items() if k != "incomplete_reasons"},
        "customer_facing_affected": affected_cf,
        "check_order_by_users": [a["service"] for a in sorted(affected_cf, key=lambda a: (-(a["users"] or 0), a["hops"], a["service"]))],
        "meaning": "Có thể bị ảnh hưởng theo sơ đồ phụ thuộc; KHÔNG phải đã xác nhận bị lỗi.",
    }


TOOLS = [get_incident, get_service_graph, get_customer_facing_services, trace_impact]

SYSTEM_PROMPT = """Bạn là trợ lý cho người trực vận hành. Bạn KHÔNG biết sơ đồ dịch vụ; mọi thông tin phải lấy qua công cụ.
Quy trình:
1. Cần incident_id (vd INC-9). Nếu người dùng chưa nói, hãy hỏi lại.
2. Gọi get_incident, rồi get_service_graph và get_customer_facing_services với system_id của sự cố.
3. Gọi trace_impact (truyền expected_graph_version là phiên bản vừa đọc). Không tự đoán đường ảnh hưởng từ tên dịch vụ.
Trình bày: trạng thái sự cố, phiên bản sơ đồ, từng dịch vụ người dùng thấy có thể bị ảnh hưởng kèm đường đi và số cạnh,
dịch vụ không có đường đi tới. Luôn nói đây là "có thể bị ảnh hưởng", không phải đã xác nhận lỗi.
Nếu status là incomplete_data: nói rõ lý do, không trình bày danh sách như chắc chắn đầy đủ.
Bạn chỉ phân tích: không có công cụ khởi động lại hay thay đổi dịch vụ."""


def mock_policy(question: str, history: list[dict]) -> dict:
    m = re.search(r"\bINC-\d+\b", question, re.I)
    if not m:
        return {"answer": "Bạn đang hỏi về sự cố nào? Hãy cho tôi mã sự cố, ví dụ INC-9."}
    iid = m.group(0).upper()
    done = {h["name"]: h["result"] for h in history}
    if "get_incident" not in done:
        return {"tool_calls": [("get_incident", {"incident_id": iid})]}
    inc = done["get_incident"]
    if not inc["ok"]:
        return {"answer": f"Tôi không phân tích được: {inc['message']} Hãy kiểm tra lại mã sự cố."}
    for name in ("get_service_graph", "get_customer_facing_services"):
        if name not in done:
            return {"tool_calls": [(name, {"system_id": inc["system_id"]})]}
        if not done[name]["ok"]:
            return {"answer": f"Tôi không phân tích được: {done[name]['message']}"}
    if "trace_impact" not in done:
        return {"tool_calls": [("trace_impact", {"incident_id": iid, "expected_graph_version": done["get_service_graph"]["version"]})]}
    t = done["trace_impact"]
    if not t["ok"]:
        return {"answer": f"Không chạy được phân tích tác động: {t['message']}"}
    lines = [f"Sự cố {iid} ({inc['title']}) tại {inc['service']} của hệ thống {t['system_id']}, trạng thái {t['incident_status']}. "
             f"Sơ đồ phiên bản {t['graph_version']}."]
    if t["incident_status"] != "open":
        lines.append("Lưu ý: sự cố này không còn mở; kết quả chỉ để tham khảo lại.")
    if t["status"] == "incomplete_data":
        lines.append("CẢNH BÁO incomplete_data: " + " ".join(t["incomplete_reasons"]) +
                     " Danh sách dưới đây có thể chưa đầy đủ.")
    if t["customer_facing_affected"]:
        lines.append("Dịch vụ người dùng thấy có thể bị ảnh hưởng:")
        lines += [f"- {a['service']}: {' → '.join(a['path'])} ({a['hops']} cạnh)" for a in t["customer_facing_affected"]]
    else:
        lines.append("Không tìm thấy dịch vụ người dùng thấy nào có đường đi từ dịch vụ lỗi.")
    if t["customer_facing_not_reached"]:
        lines.append(f"Không có đường đi từ {inc['service']}, nên không đưa vào danh sách: {', '.join(t['customer_facing_not_reached'])}.")
    if t["revisits"]:
        lines.append(f"BFS gặp lại {t['revisits']} lần dịch vụ đã thăm (do vòng hoặc nhiều đường đi) và không đi lại, nên không lặp vô hạn.")
    if t["warnings"]:
        lines.append("Ghi chú về sơ đồ: " + " ".join(t["warnings"]))
    if t["customer_facing_affected"]:
        lines.append(f"Gợi ý thứ tự kiểm tra theo số người dùng: {', '.join(t['check_order_by_users'])}.")
    lines.append("Đây là phần CÓ THỂ bị ảnh hưởng theo sơ đồ phụ thuộc, chưa phải đã xác nhận bị lỗi.")
    if re.search(r"khởi động lại|restart|reboot|tắt", question.lower()):
        lines.append("Tôi chỉ phân tích, không có công cụ khởi động lại hay thay đổi dịch vụ.")
    return {"answer": "\n".join(lines)}


EXERCISE = Exercise(
    id="ex04", title="Tác động sự cố", system_prompt=SYSTEM_PROMPT, tools=TOOLS,
    algorithm_tools={"trace_impact"}, mock_policy=mock_policy,
    sample_questions=[
        "Sự cố INC-9 ảnh hưởng đến đâu?", "INC-9: khởi động lại DB giúp tôi", "Phân tích INC-10", "Phân tích INC-11",
        "Phân tích INC-12", "Phân tích INC-13", "Phân tích INC-14", "Phân tích INC-8", "Phân tích INC-404", "DB hỏng thì sao?",
    ],
    on_run_start=OPS.new_run,
)
