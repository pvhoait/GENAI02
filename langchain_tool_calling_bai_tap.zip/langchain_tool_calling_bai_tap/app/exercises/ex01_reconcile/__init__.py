"""Bài 01 - Hai khoản chuyển tiền nào trả đủ hóa đơn?"""
from __future__ import annotations

import re
from typing import Any

from langchain_core.tools import tool
from pydantic import Field

from ...core.agent import Exercise, ToolArgs
from ...core.stores import PROPOSALS, fmt_minor, load_json
from .algorithm import ReconcileError, Transfer, find_single_exact, find_two_sum, split_eligible


class Ledger:
    """Database giả lập: hóa đơn và giao dịch chuyển tiền."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        data = load_json("ex01_ledger.json")
        self.invoices = {i["invoice_id"]: dict(i) for i in data["invoices"]}
        self.transfers = [dict(t) for t in data["transfers"]]


LEDGER = Ledger()
INVOICE_ID = r"^I-\d{1,6}$"


def _err(code: str, message: str) -> dict:
    return {"ok": False, "error_code": code, "message": message}


def _open_invoice(invoice_id: str) -> tuple[dict | None, dict | None]:
    inv = LEDGER.invoices.get(invoice_id)
    if inv is None:
        return None, _err("invoice_not_found", f"Không tìm thấy hóa đơn {invoice_id}.")
    if inv["status"] != "open":
        return None, _err("invoice_not_open", f"Hóa đơn {invoice_id} đang ở trạng thái '{inv['status']}', không cần đối soát.")
    return inv, None


# ------------------------------------------------------------------ công cụ
class InvoiceArgs(ToolArgs):
    invoice_id: str = Field(pattern=INVOICE_ID, description="Mã hóa đơn người dùng hỏi, ví dụ I-77.")


class TransferQueryArgs(ToolArgs):
    customer_id: str = Field(pattern=r"^C-\d{1,6}$", description="Mã khách lấy từ hóa đơn, ví dụ C-12.")
    currency: str = Field(pattern=r"^[A-Z]{3}$", description="Loại tiền lấy từ hóa đơn, ví dụ VND.")


class ProposeArgs(ToolArgs):
    invoice_id: str = Field(pattern=INVOICE_ID)
    transfer_ids: list[str] = Field(min_length=1, max_length=3, description="Các giao dịch đề xuất ghép.")


@tool(args_schema=InvoiceArgs)
def get_open_invoice(invoice_id: str) -> dict:
    """Đọc hóa đơn: mã khách, loại tiền, số tiền còn thiếu (đơn vị nhỏ nhất) và trạng thái."""
    inv = LEDGER.invoices.get(invoice_id)
    if inv is None:
        return _err("invoice_not_found", f"Không tìm thấy hóa đơn {invoice_id}.")
    return {"ok": True, "invoice": inv, "amount_due_display": fmt_minor(inv["amount_due_minor"], inv["currency"])}


@tool(args_schema=TransferQueryArgs)
def list_unmatched_transfers(customer_id: str, currency: str) -> dict:
    """Liệt kê các khoản chuyển tiền chưa ghép với hóa đơn nào của một khách, theo một loại tiền."""
    rows = [t for t in LEDGER.transfers
            if t["customer_id"] == customer_id and t["currency"] == currency and t["status"] == "unmatched"]
    rows.sort(key=lambda t: (t["received_at"], t["transfer_id"]))
    return {"ok": True, "customer_id": customer_id, "currency": currency, "transfers": rows}


@tool(args_schema=InvoiceArgs)
def find_two_transfer_match(invoice_id: str) -> dict:
    """Chạy thuật toán tìm HAI giao dịch có tổng đúng bằng số tiền còn thiếu của hóa đơn.
    Công cụ tự đọc lại hóa đơn và giao dịch từ backend; không nhận danh sách số tiền từ bên ngoài."""
    inv, error = _open_invoice(invoice_id)
    if error:
        return error
    try:
        transfers = [Transfer.from_dict(t) for t in LEDGER.transfers]
        eligible, excluded = split_eligible(transfers, inv["customer_id"], inv["currency"], inv["amount_due_minor"])
        result = find_two_sum(eligible, inv["amount_due_minor"])
    except ReconcileError as exc:
        return _err("invalid_data", str(exc))
    cur = inv["currency"]
    by_id = {t.transfer_id: t for t in eligible}
    out = {
        "ok": True, "invoice_id": invoice_id, "customer_id": inv["customer_id"], "currency": cur,
        "amount_due_minor": inv["amount_due_minor"], "amount_due_display": fmt_minor(inv["amount_due_minor"], cur),
        "eligible": [{"transfer_id": t.transfer_id, "amount_minor": t.amount_minor,
                      "amount_display": fmt_minor(t.amount_minor, cur), "received_at": t.received_at.isoformat()}
                     for t in eligible],
        "excluded": excluded, **result,
        "single_payment_candidates": find_single_exact(eligible, inv["amount_due_minor"]),
        "rule": "Chỉ xét giao dịch unmatched, cùng khách, cùng loại tiền, số tiền dương; sắp theo giờ nhận rồi mã; "
                "chọn cặp hoàn thành sớm nhất khi quét.",
    }
    if result["status"] == "matched":
        a, b = (by_id[x] for x in result["pair"])
        out["explanation"] = (f"{a.transfer_id} ({fmt_minor(a.amount_minor, cur)}) + {b.transfer_id} "
                              f"({fmt_minor(b.amount_minor, cur)}) = {out['amount_due_display']}.")
    return out


@tool(args_schema=ProposeArgs)
def propose_invoice_match(invoice_id: str, transfer_ids: list[str]) -> dict:
    """Tạo BẢN NHÁP đối soát chờ kế toán duyệt. Không ghi nhận thanh toán, không thay đổi sổ sách."""
    inv, error = _open_invoice(invoice_id)
    if error:
        return error
    if len(set(transfer_ids)) != len(transfer_ids):
        return _err("invalid_arguments", "Một giao dịch không được dùng hai lần.")
    by_id = {t["transfer_id"]: t for t in LEDGER.transfers}
    total = 0
    for tid in transfer_ids:
        t = by_id.get(tid)
        if t is None:
            return _err("transfer_not_found", f"Không có giao dịch {tid}.")
        if t["status"] != "unmatched" or t["customer_id"] != inv["customer_id"] or t["currency"] != inv["currency"]:
            return _err("transfer_not_eligible", f"Giao dịch {tid} không hợp lệ cho hóa đơn {invoice_id}.")
        total += t["amount_minor"]
    if total != inv["amount_due_minor"]:
        return _err("amount_mismatch", f"Tổng {fmt_minor(total, inv['currency'])} khác số tiền còn thiếu "
                                       f"{fmt_minor(inv['amount_due_minor'], inv['currency'])}.")
    proposal = PROPOSALS.create("invoice_match", {"invoice_id": invoice_id, "transfer_ids": transfer_ids},
                                f"Ghép {' + '.join(transfer_ids)} vào hóa đơn {invoice_id}")
    return {"ok": True, "proposal": proposal,
            "note": "Đây là bản nháp chờ kế toán có quyền duyệt. Hóa đơn chưa được ghi nhận đã thanh toán."}


TOOLS = [get_open_invoice, list_unmatched_transfers, find_two_transfer_match, propose_invoice_match]

SYSTEM_PROMPT = """Bạn là trợ lý đối soát cho kế toán. Bạn KHÔNG có sẵn số liệu: mọi số liệu phải lấy qua công cụ.
Quy trình:
1. Gọi get_open_invoice với ĐÚNG mã hóa đơn người dùng hỏi. Nếu người dùng chưa nói mã hóa đơn, hãy hỏi lại.
2. Gọi list_unmatched_transfers với customer_id và currency lấy từ hóa đơn.
3. Gọi find_two_transfer_match để thuật toán tìm cặp. Không tự cộng trừ hay tự chọn cặp.
4. Chỉ khi người dùng yêu cầu ghi nhận/đối soát luôn, gọi propose_invoice_match với cặp thuật toán trả về,
   rồi nói rõ đây là đề xuất chờ người có quyền duyệt, CHƯA ghi nhận.
Nếu công cụ báo lỗi hoặc no_match: nói rõ lý do, không đoán cặp "gần đúng".
Trả lời tiếng Việt, ngắn gọn: hóa đơn, cặp giao dịch, vì sao chọn cặp này, giao dịch bị loại và lý do."""


# ------------------------------------------------------------------ mock
def mock_policy(question: str, history: list[dict]) -> dict:
    m = re.search(r"\bI-\d+\b", question, re.I)
    if not m:
        return {"answer": "Bạn muốn kiểm tra hóa đơn nào? Hãy cho tôi mã hóa đơn, ví dụ I-77."}
    inv_id = m.group(0).upper()
    done = {h["name"]: h["result"] for h in history}
    wants_record = re.search(r"ghi nhận|ghép luôn|đối soát luôn|chốt luôn|xác nhận luôn|thanh toán luôn", question.lower())

    if "get_open_invoice" not in done:
        return {"tool_calls": [("get_open_invoice", {"invoice_id": inv_id})]}
    inv_res = done["get_open_invoice"]
    if not inv_res["ok"]:
        return {"answer": f"Tôi không kiểm tra được: {inv_res['message']} Hãy kiểm tra lại mã hóa đơn."}
    inv = inv_res["invoice"]
    if inv["status"] != "open":
        return {"answer": f"Hóa đơn {inv_id} đang ở trạng thái '{inv['status']}', không còn số tiền cần đối soát."}
    if "list_unmatched_transfers" not in done:
        return {"tool_calls": [("list_unmatched_transfers", {"customer_id": inv["customer_id"], "currency": inv["currency"]})]}
    if "find_two_transfer_match" not in done:
        return {"tool_calls": [("find_two_transfer_match", {"invoice_id": inv_id})]}
    r = done["find_two_transfer_match"]
    if not r["ok"]:
        return {"answer": f"Thuật toán không chạy được: {r['message']}"}
    if r["status"] == "matched" and wants_record and "propose_invoice_match" not in done:
        return {"tool_calls": [("propose_invoice_match", {"invoice_id": inv_id, "transfer_ids": r["pair"]})]}

    lines = [f"Hóa đơn {inv_id} của khách {r['customer_id']} còn thiếu {r['amount_due_display']}."]
    if r["status"] == "matched":
        lines.append(f"Cặp đề xuất: {r['explanation']}")
        if r["alternatives"]:
            alts = ", ".join(" + ".join(p) for p in r["alternatives"])
            lines.append(f"Các cặp khác cũng đủ tiền ({alts}) nhưng hoàn thành muộn hơn khi quét theo giờ nhận, "
                         "nên cặp trên được chọn.")
    else:
        lines.append(f"Không tìm được cặp: {r['reason']} Tôi không tự chọn cặp gần đúng.")
        if r["single_payment_candidates"]:
            lines.append(f"Tuy nhiên có giao dịch một lần đủ tiền: {', '.join(r['single_payment_candidates'])}. "
                         "Kế toán có thể xem xét thủ công.")
    if r["excluded"]:
        lines.append("Đã loại: " + "; ".join(f"{e['transfer_id']} ({e['reason']})" for e in r["excluded"]) + ".")
    if "propose_invoice_match" in done:
        p = done["propose_invoice_match"]
        lines.append(f"Đã tạo đề xuất {p['proposal']['proposal_id']} chờ kế toán có quyền duyệt. Hóa đơn CHƯA được ghi nhận đã thanh toán."
                     if p["ok"] else f"Không tạo được đề xuất: {p['message']}")
    elif wants_record:
        lines.append("Vì không có cặp hợp lệ nên tôi không tạo đề xuất ghi nhận.")
    else:
        lines.append("Đây mới là kết quả đối soát để xem; app không tự ghi nhận hóa đơn đã thanh toán.")
    return {"answer": "\n".join(lines)}


EXERCISE = Exercise(
    id="ex01", title="Đối soát hóa đơn", system_prompt=SYSTEM_PROMPT, tools=TOOLS,
    algorithm_tools={"find_two_transfer_match"}, mock_policy=mock_policy,
    sample_questions=[
        "Kiểm tra hóa đơn I-77", "Kiểm tra I-77 và ghi nhận luôn giúp tôi", "Hóa đơn I-80 được trả bằng hai khoản nào?",
        "Kiểm tra hóa đơn I-79", "Kiểm tra hóa đơn I-78", "Kiểm tra hóa đơn I-404", "Kiểm tra I-82",
        "Kiểm tra hóa đơn I-83", "Hai khoản nào trả đủ hóa đơn?",
    ],
    on_run_start=None,
)
