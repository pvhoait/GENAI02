"""Thuật toán Bài 01 - tìm hai khoản chuyển tiền có tổng đúng bằng số tiền còn thiếu.

Không phụ thuộc GenAI. Tiền là số nguyên ở đơn vị nhỏ nhất (VND: đồng, USD: cent).
Hash map "số tiền -> các giao dịch đã gặp": với mỗi khoản x, tra xem đã gặp (due - x) chưa.
Sau bước sắp xếp O(n log n), phần tìm cặp là O(n).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

MAX_ALTERNATIVES = 5


class ReconcileError(ValueError):
    pass


@dataclass(frozen=True)
class Transfer:
    transfer_id: str
    customer_id: str
    currency: str
    amount_minor: int
    received_at: datetime
    status: str

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "Transfer":
        amount = d.get("amount_minor")
        if isinstance(amount, bool) or not isinstance(amount, int):
            raise ReconcileError(f"Giao dịch {d.get('transfer_id')}: amount_minor phải là số nguyên.")
        received = datetime.fromisoformat(d["received_at"])
        if received.tzinfo is None:
            raise ReconcileError(f"Giao dịch {d.get('transfer_id')}: received_at thiếu múi giờ.")
        return Transfer(d["transfer_id"], d["customer_id"], d["currency"], amount, received, d["status"])


def split_eligible(
    transfers: list[Transfer], customer_id: str, currency: str, amount_due: int | None = None
) -> tuple[list[Transfer], list[dict]]:
    """Chỉ giữ giao dịch unmatched, đúng khách, đúng loại tiền, số tiền dương. Trả kèm lý do loại.

    Danh sách bị loại gồm mọi giao dịch của chính khách này, cộng với giao dịch của khách khác
    "trông như khớp" (cộng với một giao dịch hợp lệ thì đúng số tiền) để giải thích vì sao không chọn.
    """
    eligible, excluded, others = [], [], []
    for t in transfers:
        reason = None
        if t.customer_id != customer_id:
            reason = f"khác khách hàng ({t.customer_id})"
        elif t.currency != currency:
            reason = f"khác loại tiền ({t.currency})"
        elif t.status != "unmatched":
            reason = "đã được ghép với hóa đơn khác"
        elif t.amount_minor <= 0:
            reason = "số tiền không dương"
        if reason is None:
            eligible.append(t)
        elif t.customer_id == customer_id:
            excluded.append({"transfer_id": t.transfer_id, "reason": reason})
        else:
            others.append((t, reason))
    eligible.sort(key=lambda t: (t.received_at, t.transfer_id))  # thứ tự ổn định
    if amount_due is not None:
        amounts = {t.amount_minor for t in eligible}
        for t, reason in others:
            if t.amount_minor == amount_due or (amount_due - t.amount_minor) in amounts:
                excluded.append({"transfer_id": t.transfer_id, "reason": reason + ", dù số tiền trông như khớp"})
    excluded.sort(key=lambda e: e["transfer_id"])
    return eligible, excluded


def find_two_sum(eligible: list[Transfer], amount_due: int) -> dict[str, Any]:
    """Cặp được chọn là cặp HOÀN THÀNH sớm nhất khi quét theo thứ tự đã sắp."""
    if isinstance(amount_due, bool) or not isinstance(amount_due, int) or amount_due <= 0:
        raise ReconcileError("Số tiền còn thiếu phải là số nguyên dương.")
    seen: dict[int, list[str]] = {}
    pair, alternatives = None, []
    for t in eligible:
        need = amount_due - t.amount_minor
        if need > 0 and need in seen:  # kiểm tra TRƯỚC khi thêm t => không ghép với chính nó
            for prev in seen[need]:
                if pair is None:
                    pair = (prev, t.transfer_id)
                elif len(alternatives) < MAX_ALTERNATIVES:
                    alternatives.append((prev, t.transfer_id))
                else:
                    break
        seen.setdefault(t.amount_minor, []).append(t.transfer_id)
    if pair is None:
        return {"status": "no_match", "pair": [], "alternatives": [],
                "reason": "Không có hai giao dịch hợp lệ nào cộng lại đúng bằng số tiền còn thiếu."}
    return {"status": "matched", "pair": list(pair), "alternatives": [list(p) for p in alternatives]}


def find_single_exact(eligible: list[Transfer], amount_due: int) -> list[str]:
    """Phần làm thêm: một khoản đã đủ tiền."""
    return [t.transfer_id for t in eligible if t.amount_minor == amount_due]
