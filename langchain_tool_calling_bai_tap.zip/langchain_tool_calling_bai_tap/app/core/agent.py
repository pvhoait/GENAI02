"""Vòng lặp Tool Calling dùng chung cho cả 4 bài.

    model.bind_tools(tools)  ->  AIMessage.tool_calls
    backend kiểm tra TÊN công cụ (chỉ trong danh sách) và THAM SỐ (Pydantic args_schema)
    backend tự chạy công cụ  ->  ToolMessage(content=JSON, tool_call_id=đúng id)
    lặp tối đa MAX_STEPS bước cho đến khi model trả câu trả lời cuối.

Model không bao giờ chạy code hay truy cập dữ liệu trực tiếp: nó chỉ ĐỀ NGHỊ gọi công cụ.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from pydantic import BaseModel, ConfigDict, ValidationError

MAX_STEPS = 8
MAX_CALLS_PER_STEP = 6



class ToolArgs(BaseModel):
    """Tham số công cụ: từ chối trường lạ (vd model tự truyền danh sách số tiền hay cạnh đồ thị)."""

    model_config = ConfigDict(extra="forbid")


@dataclass
class Exercise:
    id: str
    title: str
    system_prompt: str
    tools: list                                   # danh sách @tool của bài
    algorithm_tools: set[str]                     # công cụ chạy thuật toán
    mock_policy: Callable[[str, list[dict]], dict]
    sample_questions: list[str] = field(default_factory=list)
    on_run_start: Optional[Callable[[], None]] = None


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------
class MockToolModel:
    """Chạy thử không cần API key.

    Trả về AIMessage có tool_calls y như model thật, quyết định theo kịch bản cố định
    của từng bài (mock_policy). Nhờ vậy vòng lặp, kiểm tra tham số, ToolMessage... được
    chạy thật, chỉ phần "suy nghĩ" của model là giả lập.
    """

    name = "mock"

    def __init__(self, exercise: Exercise) -> None:
        self.exercise = exercise

    def invoke(self, messages: list) -> AIMessage:
        question = next(m.content for m in messages if isinstance(m, HumanMessage))
        pending: dict[str, dict] = {}
        history: list[dict] = []
        for m in messages:
            if isinstance(m, AIMessage):
                for tc in m.tool_calls:
                    pending[tc["id"]] = tc
            elif isinstance(m, ToolMessage):
                tc = pending.get(m.tool_call_id, {})
                history.append({"name": tc.get("name"), "args": tc.get("args"), "result": json.loads(m.content)})
        decision = self.exercise.mock_policy(question, history)
        if "tool_calls" in decision:
            return AIMessage(content="", tool_calls=[
                {"name": n, "args": a, "id": f"call_{uuid.uuid4().hex[:10]}", "type": "tool_call"}
                for n, a in decision["tool_calls"]
            ])
        return AIMessage(content=decision["answer"])


def get_model(exercise: Exercise, mode: str = "auto"):
    has_key = bool(os.getenv("OPENAI_API_KEY"))
    if mode == "mock" or (mode == "auto" and (not has_key or os.getenv("LLM_MODE") == "mock")):
        return MockToolModel(exercise)
    if not has_key:
        raise RuntimeError("Chưa cấu hình OPENAI_API_KEY trong .env ở backend.")
    from langchain_openai import ChatOpenAI

    llm = ChatOpenAI(model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=0, timeout=60, max_retries=2)
    model = llm.bind_tools(exercise.tools)
    model.name = f"openai:{llm.model_name}"
    return model


# ---------------------------------------------------------------------------
# Chạy một lần gọi công cụ một cách an toàn
# ---------------------------------------------------------------------------
def execute_tool_call(tools: dict[str, Any], call: dict) -> dict:
    name, args = call.get("name"), call.get("args") or {}
    tool = tools.get(name)
    if tool is None:
        return {"ok": False, "error_code": "unknown_tool",
                "message": f"Công cụ '{name}' không có trong danh sách được phép: {sorted(tools)}."}
    if not isinstance(args, dict):
        return {"ok": False, "error_code": "invalid_arguments", "message": "Tham số phải là object JSON."}
    try:
        parsed = tool.args_schema.model_validate(args)
    except ValidationError as exc:
        msgs = [f"{'.'.join(str(p) for p in e['loc']) or 'args'}: {e['msg']}" for e in exc.errors()]
        return {"ok": False, "error_code": "invalid_arguments", "message": "; ".join(msgs)}
    try:
        out = tool.func(**parsed.model_dump())
    except Exception as exc:  # công cụ lỗi -> báo lại cho model, không làm sập server
        return {"ok": False, "error_code": "tool_error", "message": f"{type(exc).__name__}: {exc}"}
    if not isinstance(out, dict) or "ok" not in out:
        return {"ok": False, "error_code": "tool_error", "message": "Công cụ trả về sai định dạng."}
    return out


def _text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(b.get("text", "") for b in content if isinstance(b, dict))
    return str(content or "")


def run_agent(exercise: Exercise, question: str, model, max_steps: int = MAX_STEPS) -> dict:
    started = time.perf_counter()
    if exercise.on_run_start:
        exercise.on_run_start()
    tools = {t.name: t for t in exercise.tools}
    messages: list = [SystemMessage(exercise.system_prompt), HumanMessage(question)]
    trace: list[dict] = []
    artifacts: dict[str, Any] = {}
    proposals: list[dict] = []
    answer, stopped = "", None

    for step in range(1, max_steps + 1):
        try:
            ai = model.invoke(messages)
        except Exception as exc:
            stopped = "model_error"
            answer = f"Không gọi được model: {exc}. Chưa có kết quả nào được tạo."
            break
        messages.append(ai)
        calls = list(ai.tool_calls or [])
        if not calls:
            answer = _text(ai.content).strip()
            break
        for i, call in enumerate(calls):
            t0 = time.perf_counter()
            if i >= MAX_CALLS_PER_STEP:
                result = {"ok": False, "error_code": "too_many_calls",
                          "message": f"Mỗi bước chỉ được gọi tối đa {MAX_CALLS_PER_STEP} công cụ."}
            else:
                result = execute_tool_call(tools, call)
            trace.append({
                "step": step, "tool_call_id": call.get("id"), "name": call.get("name"), "args": call.get("args"),
                "ok": bool(result.get("ok")), "result": result, "duration_ms": round((time.perf_counter() - t0) * 1000, 2),
            })
            if result.get("ok"):
                artifacts[call["name"]] = result
                if result.get("proposal"):
                    proposals.append(result["proposal"])
            messages.append(ToolMessage(
                content=json.dumps(result, ensure_ascii=False, default=str),
                tool_call_id=call.get("id"), name=call.get("name") or "unknown",
                status="success" if result.get("ok") else "error",
            ))
    else:
        stopped = "max_steps"
        answer = (f"Đã dừng sau {max_steps} bước mà model chưa đưa ra câu trả lời cuối. "
                  "Kết quả chưa đầy đủ, hãy hỏi lại cụ thể hơn.")

    grounded = any(c["ok"] and c["name"] in exercise.algorithm_tools for c in trace)
    return {
        "run_id": uuid.uuid4().hex[:12],
        "exercise": exercise.id,
        "question": question,
        "model": getattr(model, "name", None) or type(model).__name__,
        "answer": answer,
        "tool_calls": trace,
        "artifacts": artifacts,
        "proposals": proposals,
        "grounded": grounded,
        "stopped_reason": stopped,
        "steps": len({c["step"] for c in trace}) + (0 if stopped else 1),
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "duration_ms": int((time.perf_counter() - started) * 1000),
    }
