"""Lưu lịch sử chạy và các đề xuất chờ duyệt."""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class RunStore:
    """Câu hỏi, các lần gọi công cụ (tên, tham số, kết quả/lỗi), kết quả thuật toán và câu trả lời."""

    def __init__(self, log_path: Optional[Path] = None) -> None:
        self.runs: list[dict[str, Any]] = []
        self.log_path = log_path
        self._lock = threading.Lock()
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)

    def add(self, run: dict[str, Any]) -> None:
        with self._lock:
            self.runs.append(run)
            if self.log_path:
                with self.log_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(run, ensure_ascii=False, default=str) + "\n")

    def get(self, run_id: str) -> Optional[dict[str, Any]]:
        return next((r for r in self.runs if r["run_id"] == run_id), None)

    def list(self, exercise: Optional[str] = None, limit: int = 50) -> list[dict[str, Any]]:
        rows = [r for r in reversed(self.runs) if exercise in (None, r["exercise"])]
        return rows[:limit]


class ProposalStore:
    """Đề xuất do công cụ tạo ra. KHÔNG thay đổi dữ liệu nghiệp vụ; chỉ người có quyền mới duyệt."""

    def __init__(self) -> None:
        self.items: dict[str, dict[str, Any]] = {}

    def create(self, kind: str, payload: dict[str, Any], summary: str) -> dict[str, Any]:
        pid = f"PR-{uuid.uuid4().hex[:6].upper()}"
        item = {"proposal_id": pid, "kind": kind, "payload": payload, "summary": summary,
                "status": "pending_approval", "created_at": now_iso(), "decision": None}
        self.items[pid] = item
        return item

    def decide(self, pid: str, decision: str, reviewer: str, note: Optional[str]) -> dict[str, Any]:
        item = self.items[pid]
        if item["status"] != "pending_approval":
            raise ValueError(f"Đề xuất {pid} đã được xử lý ({item['status']}).")
        item["status"] = "approved" if decision == "approve" else "rejected"
        item["decision"] = {"by": reviewer, "note": note, "at": now_iso(),
                            "effect": "Chỉ ghi nhận quyết định; bài tập không thay đổi hệ thống thật."}
        return item

    def clear(self) -> None:
        self.items.clear()


PROPOSALS = ProposalStore()


def load_json(name: str) -> Any:
    root = Path(__file__).resolve().parents[2]
    return json.loads((root / "sample_data" / name).read_text("utf-8"))


def fmt_minor(amount: int, currency: str) -> str:
    """1500000 VND -> '1.500.000 VND'; 12550 USD -> '125,50 USD'."""
    decimals = {"VND": 0, "JPY": 0}.get(currency, 2)
    if decimals == 0:
        return f"{amount:,}".replace(",", ".") + f" {currency}"
    whole, frac = divmod(abs(amount), 10**decimals)
    sign = "-" if amount < 0 else ""
    return f"{sign}{whole:,}".replace(",", ".") + f",{frac:0{decimals}d} {currency}"
