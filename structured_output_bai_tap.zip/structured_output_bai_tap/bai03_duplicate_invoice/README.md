# Bài 03 - Hóa đơn này đã được gửi trước đó chưa?

Trang web đọc văn bản chứng từ chi phí bằng GenAI (OpenAI qua LangChain), cho người duyệt xem và sửa, rồi code tạo **nhãn tra cứu** và tìm trong **hash map** để đánh dấu bản có thể đã gửi trước. Hệ thống chỉ giúp người duyệt; không kết luận gian lận và không tự từ chối hoàn tiền.

![Luồng chính](docs/screenshot.png)

## Cấu trúc

```
bai03_duplicate_invoice/
├── app/
│   ├── schemas.py      # Mẫu JSON GenAI phải trả + loại tiền hỗ trợ
│   ├── extractor.py    # GenAI: LangChain with_structured_output + MockExtractor
│   ├── validation.py   # Kiểm tra mã, ngày, tiền, loại tiền
│   ├── dedup.py        # THUẬT TOÁN: normalize_text, lookup_keys, DuplicateIndex
│   ├── storage.py      # Lưu vết data/audit_log.jsonl
│   ├── main.py         # FastAPI
│   └── static/index.html
├── tests/
│   ├── test_dedup.py   # Test thuật toán, không phụ thuộc GenAI
│   └── test_api.py     # Test validation + API (mock)
├── sample_data/
│   ├── receipts.json         # E01, E02, E03 trong đề
│   └── extra_receipts.json   # Ca lỗi và ca biên
└── docs/expense.schema.json  # Mẫu dữ liệu GenAI phải trả
```

## Cài đặt và chạy

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # điền OPENAI_API_KEY (không bắt buộc)
uvicorn app.main:app --reload      # http://localhost:8000
pytest -q
```

Không có `OPENAI_API_KEY` thì app dùng **MockExtractor**, đọc văn bản có nhãn như `Nơi bán:`, `Số hóa đơn:`, `Tổng tiền:`. Đầu vào là văn bản đã OCR. Nếu có ảnh hoặc PDF, chạy OCR trước (ví dụ Tesseract) rồi dán văn bản vào.

## Luồng sử dụng

1. Bấm **Nạp E01–E03 trong đề**: E01 chưa trùng theo quy tắc, E02 là ứng viên trùng E01, E03 cần người xem lại.
2. Chọn chip **Trùng mã, khác tiền** → **Đọc chứng từ** → **Kiểm tra trùng**. App vẫn đánh dấu vì mã biên nhận trùng, và hiện bảng so sánh với chênh lệch 100.000 VND.
3. Người duyệt bấm **Xác nhận là trùng** hoặc **Bỏ nghi vấn**, có thể kèm ghi chú.
4. Sửa **Mã biên nhận** rồi bấm **Kiểm tra trùng** lần nữa: hệ thống gỡ nhãn cũ và kiểm tra lại.
5. Chip **Tiền âm** và **Tiền JPY**: app báo lỗi, không bao giờ trả "chưa trùng".

## API

| Method | Đường dẫn | Việc làm |
|---|---|---|
| POST | `/expenses/extract` | Nhận `text`, `submission_id?`, `mode`. GenAI điền mẫu, code kiểm tra, trả lỗi + trường không đọc được. |
| POST | `/expenses/check` | Nhận bản người dùng đã sửa. Kiểm tra lại, tạo nhãn, tra hash map, lưu. Gửi lại cùng mã thì kiểm tra lại. Dữ liệu sai → 422. |
| POST | `/expenses/review` | Nhận `submission_id`, `decision` (`confirm_duplicate`/`dismiss`), `note`. Lưu quyết định, không xóa chứng từ. |
| GET | `/expenses` | Danh sách chứng từ, trạng thái, quyết định duyệt. |
| GET | `/records` | Lịch sử: văn bản gốc, JSON GenAI, bản sửa, các trường đã sửa, kết quả, quyết định. |
| GET | `/schema/expense` | JSON Schema GenAI phải trả. |
| POST | `/demo/load-sample`, `/demo/reset` | Nạp E01–E03 / xóa dữ liệu. |

## Mẫu dữ liệu GenAI phải trả

```json
{
  "submission_id": "E01",
  "vendor": "ABC Travel",
  "invoice_number": "INV-0042",
  "transaction_date": "2026-10-19",
  "amount_minor": 1250000,
  "currency": "VND",
  "receipt_id": "R-42",
  "missing_fields": []
}
```

`amount_minor` là số nguyên ở đơn vị nhỏ nhất (VND: đồng, USD/EUR: cent) để so sánh không sai số. Trường không đọc được để `null` và ghi tên vào `missing_fields`. Prompt yêu cầu chép nguyên dấu gạch nối và không tự sửa mã.

## Thuật toán

**Chuẩn hóa** (`normalize_text`): Unicode NFKC, không phân biệt hoa/thường (`casefold`), gộp dấu cách thừa. **Không** xóa dấu gạch nối, nên `INV-0042` và `INV0042` là hai mã khác nhau.

**Nhãn tra cứu** (`lookup_keys`):

| Nhãn | Tạo khi có |
|---|---|
| `("receipt", loại tiền, mã biên nhận)` | loại tiền + mã biên nhận |
| `("invoice", loại tiền, nơi bán, số hóa đơn)` | loại tiền + nơi bán + số hóa đơn |

Nhãn thứ hai giúp tìm bản gửi sau bị thiếu mã biên nhận.

**Tra cứu** (`DuplicateIndex`): hash map `nhãn → [submission_id]`. Với mỗi chứng từ:

- **`duplicate_candidate`:** có nhãn đã tồn tại. App trả bản cũ, nhãn nào trùng, từng trường khác nhau (đánh dấu trường chỉ khác hoa/thường) và chênh lệch số tiền.
- **`needs_review`:** không tạo được nhãn nào, hoặc thiếu số tiền. Chỉ cùng nơi bán, số tiền và ngày thì chưa đủ để gọi là trùng.
- **`unique_under_current_rules`:** chưa thấy nhãn này. Nghĩa là chưa trùng theo quy tắc hiện tại, không phải chắc chắn hợp lệ.

Gửi lại cùng `submission_id` (ví dụ sau khi sửa mã biên nhận) thì `upsert` gỡ nhãn cũ trước rồi mới kiểm tra lại, và một chứng từ không bao giờ tự trùng với chính nó.

Độ phức tạp: mỗi lần thêm hoặc tra là O(1) trung bình, n chứng từ là O(n).

**Làm thêm, mã gần giống do OCR:** trong cùng nơi bán và loại tiền, tìm số hóa đơn lệch đúng 1 ký tự (khoảng cách chỉnh sửa ≤ 1). Kết quả chỉ nằm trong `near_matches` để người duyệt xem lại, không đổi trạng thái thành trùng.

## Kiểm tra dữ liệu

- `submission_id` đúng mã hệ thống đã cấp.
- `transaction_date` đúng dạng `YYYY-MM-DD` và là ngày có thật; ngày ở tương lai thì cảnh báo.
- `amount_minor` là số nguyên, không âm, không lớn bất thường; bằng 0 thì cảnh báo.
- `currency` thuộc VND/USD/EUR (tự chuẩn hóa chữ hoa).
- Dữ liệu sai → 422, **không bao giờ** trả "chưa trùng" khi dữ liệu chưa đủ tin cậy.

## Test

41 test:

- **Ca thường:** E01/E02/E03 ra đúng ba trạng thái; trùng mã biên nhận nhưng khác tiền vẫn đánh dấu và hiện chênh lệch; bản gửi lại thiếu mã biên nhận vẫn tìm được qua nơi bán + số hóa đơn; nhiều bản cũ được liệt kê theo thứ tự.
- **Ca sát giới hạn:** dấu cách thừa và Unicode dạng tổ hợp vẫn trùng; `INV-0042` và `INV0042` không trùng khi khác mã biên nhận nhưng trùng khi cùng mã biên nhận; khác loại tiền thì không trùng; sửa mã biên nhận thì kiểm tra lại; không tự trùng với chính mình.
- **Dữ liệu sai:** thiếu mã, thiếu loại tiền, thiếu số tiền, tiền âm, số tiền dạng chuỗi hoặc thập phân, loại tiền chưa hỗ trợ, ngày sai định dạng, mã lượt gửi sai.
- **Hiệu năng:** 30.000 chứng từ trong vài giây.

## GenAI làm gì, code làm gì?

**GenAI** đọc văn bản chứng từ lộn xộn (có thể có lỗi OCR) và điền vào mẫu: nơi bán, số hóa đơn, ngày, số tiền quy về đơn vị nhỏ nhất, loại tiền, mã biên nhận. Không đọc được thì để `null`.

**Code** kiểm tra từng giá trị, chuẩn hóa văn bản theo quy tắc cố định, tạo nhãn tra cứu và tìm trong hash map. Nhờ vậy cùng một dữ liệu luôn cho cùng một kết quả và lý do giải thích được.

**Người duyệt** là người kết luận: xác nhận trùng hoặc bỏ nghi vấn. Hệ thống không tự kết luận gian lận và không tự từ chối hoàn tiền.
