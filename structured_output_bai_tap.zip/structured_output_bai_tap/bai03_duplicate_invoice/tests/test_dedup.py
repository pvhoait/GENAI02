"""Test thuật toán Bài 03 - không gọi GenAI."""
from datetime import date

import pytest

from app.dedup import (
    DUPLICATE,
    NEEDS_REVIEW,
    UNIQUE,
    DuplicateIndex,
    Expense,
    ExpenseError,
    edit_distance_at_most_one,
    lookup_keys,
    normalize_text,
)

D = date(2026, 10, 19)


def exp(sid, vendor="ABC Travel", inv="INV-0042", amount=1_250_000, cur="VND", rec="R-42", d=D):
    return Expense(sid, vendor, inv, d, amount, cur, rec)


@pytest.fixture
def idx():
    return DuplicateIndex()


# ----------------------------------------------------------------- ca thường
def test_sample_three_statuses(idx):
    r1 = idx.upsert(exp("E01"))
    r2 = idx.upsert(exp("E02", vendor="abc travel", inv="inv-0042"))
    r3 = idx.upsert(exp("E03", inv=None, rec=None))
    assert [r1.status, r2.status, r3.status] == [UNIQUE, DUPLICATE, NEEDS_REVIEW]
    assert r2.matches[0].submission_id == "E01"
    assert set(r2.matches[0].matched_by) == {"receipt", "invoice"}


def test_case_only_differences_flagged_as_cosmetic(idx):
    idx.upsert(exp("E01"))
    r = idx.upsert(exp("E02", vendor="abc travel", inv="inv-0042"))
    diffs = {d.field: d.same_after_normalize for d in r.matches[0].differences}
    assert diffs == {"vendor": True, "invoice_number": True}


def test_same_receipt_different_amount_still_flagged_with_difference(idx):
    idx.upsert(exp("E01"))
    r = idx.upsert(exp("E02", amount=1_350_000, d=date(2026, 10, 20)))
    assert r.status == DUPLICATE
    assert r.matches[0].amount_difference_minor == 100_000
    assert {d.field for d in r.matches[0].differences} == {"amount_minor", "transaction_date"}


def test_resubmission_without_receipt_found_by_vendor_invoice(idx):
    idx.upsert(exp("E01"))
    r = idx.upsert(exp("E05", vendor="ABC TRAVEL", rec=None))
    assert r.status == DUPLICATE and r.matches[0].matched_by == ["invoice"]


def test_multiple_previous_matches_listed_in_order(idx):
    idx.upsert(exp("E01"))
    idx.upsert(exp("E02"))
    r = idx.upsert(exp("E03"))
    assert [m.submission_id for m in r.matches] == ["E01", "E02"]


# ----------------------------------------------------------- ca sát giới hạn
def test_extra_spaces_and_unicode_forms_do_not_break_match(idx):
    idx.upsert(exp("E01", vendor="Khách sạn Hòa Bình", rec=None))
    decomposed = "Kha\u0301ch  sa\u0323n   Ho\u0300a Bi\u0300nh"  # NFD + dấu cách thừa
    r = idx.upsert(exp("E02", vendor=decomposed, rec=None))
    assert r.status == DUPLICATE


def test_hyphen_is_significant_without_shared_receipt(idx):
    idx.upsert(exp("E01"))
    r = idx.upsert(exp("E02", inv="INV0042", rec="R-77"))
    assert r.status == UNIQUE
    assert r.near_matches and r.near_matches[0]["submission_id"] == "E01"  # chỉ là gợi ý xem lại


def test_hyphen_difference_but_same_receipt_is_duplicate(idx):
    idx.upsert(exp("E01"))
    assert idx.upsert(exp("E02", inv="INV0042")).status == DUPLICATE


def test_different_currency_not_matched(idx):
    idx.upsert(exp("E01"))
    assert idx.upsert(exp("E02", cur="USD", amount=5000)).status == UNIQUE


def test_editing_receipt_rechecks_and_removes_old_key(idx):
    idx.upsert(exp("E01"))
    assert idx.upsert(exp("E02", inv="X-1")).status == DUPLICATE  # trùng R-42
    assert idx.upsert(exp("E02", inv="X-1", rec="R-99")).status == UNIQUE  # sửa mã biên nhận
    # E01 không còn bị E02 cũ "giữ chỗ"
    assert idx.upsert(exp("E03", inv="X-2", rec="R-99")).matches[0].submission_id == "E02"


def test_rechecking_same_submission_does_not_match_itself(idx):
    idx.upsert(exp("E01"))
    assert idx.upsert(exp("E01")).status == UNIQUE


def test_zero_amount_allowed(idx):
    assert idx.upsert(exp("E01", amount=0)).status == UNIQUE


# ------------------------------------------------------------- dữ liệu sai
def test_missing_codes_need_review_not_unique(idx):
    r = idx.upsert(exp("E03", inv=None, rec=None))
    assert r.status == NEEDS_REVIEW and lookup_keys(exp("E03", inv=None, rec=None)) == []


def test_missing_currency_needs_review(idx):
    assert idx.upsert(exp("E01", cur=None)).status == NEEDS_REVIEW


def test_missing_amount_never_unique(idx):
    assert idx.upsert(exp("E01", amount=None)).status == NEEDS_REVIEW


def test_same_vendor_amount_date_alone_is_not_duplicate(idx):
    idx.upsert(exp("E01", inv=None, rec=None))
    assert idx.upsert(exp("E02", inv=None, rec=None)).status == NEEDS_REVIEW


def test_negative_amount_rejected():
    with pytest.raises(ExpenseError, match="âm"):
        exp("E01", amount=-1)


def test_unsupported_currency_rejected():
    with pytest.raises(ExpenseError, match="chưa được hỗ trợ"):
        exp("E01", cur="JPY")


@pytest.mark.parametrize("bad", ["1250000", 12.5, True])
def test_non_integer_amount_rejected(bad):
    with pytest.raises(ExpenseError):
        exp("E01", amount=bad)


# ------------------------------------------------------------------ helpers
def test_normalize_keeps_hyphen():
    assert normalize_text("  INV-0042 ") == "inv-0042"
    assert normalize_text("INV-0042") != normalize_text("INV0042")


@pytest.mark.parametrize("a,b,ok", [("inv-0042", "inv0042", True), ("inv-0042", "inv-0043", True),
                                    ("inv-0042", "inv-0042", True), ("inv-0042", "inv-00", False)])
def test_edit_distance(a, b, ok):
    assert edit_distance_at_most_one(a, b) is ok


def test_performance_linear():
    import time

    idx = DuplicateIndex()
    start = time.perf_counter()
    for i in range(30_000):
        idx.upsert(exp(f"E{i}", vendor=f"Vendor {i % 500}", inv=f"INV-{i}", rec=f"R-{i}"))
    assert idx.upsert(exp("X", vendor="Vendor 7", inv="INV-7", rec=None)).status == DUPLICATE
    assert time.perf_counter() - start < 5
