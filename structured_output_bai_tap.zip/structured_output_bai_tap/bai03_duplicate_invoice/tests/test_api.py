"""Test API Bài 03 ở chế độ mock."""
import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.validation import validate_expense

E01 = "Nơi bán: ABC Travel\nSố hóa đơn: INV-0042\nNgày: 19/10/2026\nTổng tiền: 1.250.000 VND\nMã biên nhận: R-42"


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    return TestClient(create_app(tmp_path / "audit.jsonl"))


def extract(client, text, sid=None):
    r = client.post("/expenses/extract", json={"text": text, "submission_id": sid, "mode": "mock"})
    assert r.status_code == 200, r.text
    return r.json()


def check(client, ex, **patch):
    return client.post("/expenses/check", json={"extraction_id": ex["extraction_id"], "expense": {**ex["extraction"], **patch}})


def test_sample_statuses(client):
    statuses = {x["submission_id"]: x["status"] for x in client.post("/demo/load-sample").json()["loaded"]}
    assert statuses == {"E01": "unique_under_current_rules", "E02": "duplicate_candidate", "E03": "needs_review"}


def test_duplicate_shows_old_submission_and_amount_difference(client):
    check(client, extract(client, E01, "E01"))
    r = check(client, extract(client, E01.replace("1.250.000", "1.350.000"), "E02")).json()
    assert r["status"] == "duplicate_candidate"
    assert r["matches"][0]["submission_id"] == "E01"
    assert r["matches"][0]["amount_difference_minor"] == 100000


def test_editing_receipt_triggers_recheck(client):
    check(client, extract(client, E01, "E01"))
    ex2 = extract(client, E01.replace("INV-0042", "INV-9"), "E02")
    assert check(client, ex2).json()["status"] == "duplicate_candidate"
    r = check(client, ex2, receipt_id="R-99").json()
    assert r["status"] == "unique_under_current_rules" and r["rechecked"]
    assert "kiểm tra trùng lại" in r["reasons"][0]


def test_negative_amount_not_reported_unique(client):
    ex = extract(client, E01.replace("1.250.000", "-250.000"), "E10")
    assert any("âm" in e for e in ex["errors"])
    r = check(client, ex)
    assert r.status_code == 422


def test_unsupported_currency_not_reported_unique(client):
    ex = extract(client, E01.replace("VND", "JPY"), "E11")
    assert check(client, ex).status_code == 422


def test_review_flow(client):
    client.post("/demo/load-sample")
    r = client.post("/expenses/review", json={"submission_id": "E02", "decision": "dismiss", "note": "Hai chuyến khác nhau"})
    assert r.status_code == 200 and r.json()["review"]["decision"] == "dismiss"
    assert client.post("/expenses/review", json={"submission_id": "E01", "decision": "dismiss"}).status_code == 409
    assert client.post("/expenses/review", json={"submission_id": "E99", "decision": "dismiss"}).status_code == 404


def test_wrong_submission_id_rejected(client):
    ex = extract(client, E01, "E01")
    assert check(client, ex, submission_id="E77").status_code == 422


def test_duplicate_submission_id_on_extract(client):
    check(client, extract(client, E01, "E01"))
    assert client.post("/expenses/extract", json={"text": E01, "submission_id": "E01", "mode": "mock"}).status_code == 409


def test_audit_keeps_before_and_after(client):
    ex = extract(client, E01, "E01")
    check(client, ex, receipt_id="R-43")
    rec = client.get("/records").json()[0]
    assert rec["llm_output"]["receipt_id"] == "R-42" and rec["user_edited"]["receipt_id"] == "R-43"
    assert rec["user_changed_fields"] == ["receipt_id"]


@pytest.mark.parametrize("patch, expected", [
    ({"transaction_date": "19/10/2026"}, "YYYY-MM-DD"),
    ({"transaction_date": "2026-02-30"}, "không hợp lệ"),
    ({"amount_minor": "1.250.000"}, "số nguyên"),
    ({"currency": "XYZ"}, "chưa được hỗ trợ"),
])
def test_validation(patch, expected):
    base = {"submission_id": "E01", "vendor": "ABC", "invoice_number": "1", "transaction_date": "2026-10-19",
            "amount_minor": 1, "currency": "VND", "receipt_id": "R", "missing_fields": []}
    res = validate_expense({**base, **patch}, "E01")
    assert any(expected in e for e in res.errors)


def test_currency_lowercase_normalized():
    base = {"submission_id": "E01", "vendor": "ABC", "invoice_number": "1", "transaction_date": "2026-10-19",
            "amount_minor": 1, "currency": " vnd ", "receipt_id": "R", "missing_fields": []}
    assert validate_expense(base, "E01").expense.currency == "VND"
