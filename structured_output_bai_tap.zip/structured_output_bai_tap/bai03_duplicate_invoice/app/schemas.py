"""Schema dữ liệu Bài 03 - rà soát hóa đơn gửi trùng."""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

# Loại tiền hỗ trợ -> số chữ số thập phân của đơn vị nhỏ nhất (VND: đồng, USD: cent)
SUPPORTED_CURRENCIES: dict[str, int] = {"VND": 0, "USD": 2, "EUR": 2}
DATA_FIELDS: tuple[str, ...] = (
    "vendor", "invoice_number", "transaction_date", "amount_minor", "currency", "receipt_id",
)
MAX_AMOUNT_MINOR = 10**13

Status = Literal["duplicate_candidate", "needs_review", "unique_under_current_rules"]
FieldName = Literal["vendor", "invoice_number", "transaction_date", "amount_minor", "currency", "receipt_id"]


class ExpenseExtraction(BaseModel):
    """Thông tin đọc ra từ chứng từ. Chỉ điền, không kết luận trùng hay gian lận."""

    submission_id: str = Field(description="Mã lượt gửi hệ thống đã cấp. Chép y nguyên.")
    vendor: Optional[str] = Field(description="Tên nơi bán, chép như trên chứng từ. null nếu không đọc được.")
    invoice_number: Optional[str] = Field(
        description="Số hóa đơn, chép nguyên ký tự kể cả dấu gạch nối. null nếu không có."
    )
    transaction_date: Optional[str] = Field(description="Ngày giao dịch dạng YYYY-MM-DD. null nếu không có.")
    amount_minor: Optional[int] = Field(
        description="Tổng tiền ở đơn vị nhỏ nhất, số nguyên: VND tính bằng đồng, USD/EUR tính bằng cent. "
        "Ví dụ 1.250.000 đ -> 1250000; 12,50 USD -> 1250. null nếu không đọc được."
    )
    currency: Optional[str] = Field(description="Mã loại tiền ISO 4217, ví dụ VND, USD. null nếu không rõ.")
    receipt_id: Optional[str] = Field(description="Mã biên nhận / mã giao dịch. null nếu không có.")
    missing_fields: list[FieldName] = Field(description="Tên các trường để null vì không đọc được.")


class ExtractRequest(BaseModel):
    text: str = Field(min_length=1, max_length=10000, description="Văn bản chứng từ (đã OCR nếu là ảnh/PDF)")
    submission_id: Optional[str] = None
    mode: Literal["auto", "mock", "openai"] = "auto"


class CheckRequest(BaseModel):
    extraction_id: Optional[str] = None
    expense: dict[str, Any]


class ReviewRequest(BaseModel):
    submission_id: str
    decision: Literal["confirm_duplicate", "dismiss"]
    note: Optional[str] = Field(default=None, max_length=500)
