"""Kiểm tra lại dữ liệu GenAI (hoặc người dùng sửa) cho chứng từ chi phí."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from .dedup import Expense
from .schemas import DATA_FIELDS, MAX_AMOUNT_MINOR, SUPPORTED_CURRENCIES

SUBMISSION_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
VN_TZ = timezone(timedelta(hours=7))


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    expense: Optional[Expense] = None

    @property
    def ok(self) -> bool:
        return not self.errors


def _clean(value: Any, name: str, res: ValidationResult, max_len: int = 120) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        res.errors.append(f"{name} phải là chuỗi hoặc null.")
        return None
    text = " ".join(unicodedata.normalize("NFC", value).split())
    if len(text) > max_len:
        res.errors.append(f"{name} dài {len(text)} ký tự, vượt {max_len}.")
    return text or None


def validate_expense(data: Any, expected_id: Optional[str] = None, today: Optional[date] = None) -> ValidationResult:
    res = ValidationResult()
    if not isinstance(data, dict):
        res.errors.append("Dữ liệu không phải object JSON.")
        return res

    sid = data.get("submission_id")
    if not isinstance(sid, str) or not SUBMISSION_ID_RE.match(sid.strip()):
        res.errors.append("submission_id chỉ gồm chữ, số, '-' hoặc '_' (tối đa 32 ký tự).")
    elif expected_id and sid.strip() != expected_id:
        res.errors.append(f"submission_id '{sid}' không khớp mã hệ thống đã cấp '{expected_id}'.")

    vendor = _clean(data.get("vendor"), "vendor", res)
    invoice = _clean(data.get("invoice_number"), "invoice_number", res, 60)
    receipt = _clean(data.get("receipt_id"), "receipt_id", res, 60)

    tx_date = None
    raw_date = data.get("transaction_date")
    if raw_date is not None:
        try:
            if not isinstance(raw_date, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw_date.strip()):
                raise ValueError
            tx_date = date.fromisoformat(raw_date.strip())
            today = today or datetime.now(VN_TZ).date()
            if tx_date > today:
                res.warnings.append(f"Ngày giao dịch {tx_date:%d/%m/%Y} ở tương lai: cần kiểm tra lại.")
        except ValueError:
            res.errors.append(f"transaction_date '{raw_date}' không hợp lệ (cần dạng YYYY-MM-DD).")

    amount = data.get("amount_minor")
    if amount is not None:
        if isinstance(amount, bool) or not isinstance(amount, int):
            res.errors.append("amount_minor phải là số nguyên ở đơn vị nhỏ nhất (vd 1250000 cho 1.250.000 đ).")
            amount = None
        elif amount < 0:
            res.errors.append(f"amount_minor = {amount}: số tiền không được âm.")
            amount = None
        elif amount > MAX_AMOUNT_MINOR:
            res.errors.append(f"amount_minor = {amount}: lớn bất thường, cần kiểm tra lại.")
            amount = None
        elif amount == 0:
            res.warnings.append("Số tiền bằng 0: cần kiểm tra lại.")

    currency = data.get("currency")
    if currency is not None:
        if not isinstance(currency, str):
            res.errors.append("currency phải là chuỗi hoặc null.")
            currency = None
        else:
            currency = currency.strip().upper() or None
            if currency and currency not in SUPPORTED_CURRENCIES:
                res.errors.append(f"Loại tiền '{currency}' chưa được hỗ trợ {list(SUPPORTED_CURRENCIES)}.")
                currency = None

    values = {"vendor": vendor, "invoice_number": invoice, "transaction_date": raw_date if tx_date else None,
              "amount_minor": amount, "currency": currency, "receipt_id": receipt}
    res.missing = [f for f in DATA_FIELDS if values[f] is None and data.get(f) is None]
    declared = data.get("missing_fields", [])
    if isinstance(declared, list):
        undeclared = set(res.missing) - set(declared)
        if undeclared:
            res.warnings.append(f"Trường đang null nhưng chưa ghi vào missing_fields: {sorted(undeclared)}.")
    else:
        res.errors.append("missing_fields phải là danh sách.")

    if not res.errors:
        res.expense = Expense(sid.strip(), vendor, invoice, tx_date, amount, currency, receipt)
    return res
