"""Thuật toán Bài 03 - tìm chứng từ có thể đã gửi trước đó. Không phụ thuộc GenAI.

Mỗi chứng từ sinh tối đa 2 "nhãn tra cứu":
  - ("receipt", loại tiền, mã biên nhận)                 nếu có mã biên nhận
  - ("invoice", loại tiền, tên nơi bán, số hóa đơn)       nếu có nơi bán và số hóa đơn
Nhãn được chuẩn hóa (Unicode NFKC, bỏ dấu cách thừa, không phân biệt hoa/thường)
nhưng KHÔNG xóa dấu gạch nối: INV-0042 và INV0042 là hai mã khác nhau.

Hash map: nhãn -> danh sách submission_id. Thêm/tra một chứng từ O(1) trung bình,
n chứng từ O(n).

Hệ thống chỉ gợi ý để người duyệt kiểm tra; không kết luận gian lận.
"""
from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

from .schemas import SUPPORTED_CURRENCIES

DUPLICATE = "duplicate_candidate"
NEEDS_REVIEW = "needs_review"
UNIQUE = "unique_under_current_rules"


class ExpenseError(ValueError):
    """Dữ liệu chứng từ không hợp lệ cho thuật toán."""


def normalize_text(value: Optional[str]) -> Optional[str]:
    """NFKC + casefold + gộp khoảng trắng. Giữ nguyên dấu gạch nối và ký tự khác."""
    if value is None:
        return None
    text = " ".join(unicodedata.normalize("NFKC", value).casefold().split())
    return text or None


@dataclass(frozen=True)
class Expense:
    submission_id: str
    vendor: Optional[str] = None
    invoice_number: Optional[str] = None
    transaction_date: Optional[date] = None
    amount_minor: Optional[int] = None
    currency: Optional[str] = None
    receipt_id: Optional[str] = None

    def __post_init__(self) -> None:
        if not isinstance(self.submission_id, str) or not self.submission_id.strip():
            raise ExpenseError("submission_id không được rỗng.")
        if self.amount_minor is not None:
            if isinstance(self.amount_minor, bool) or not isinstance(self.amount_minor, int):
                raise ExpenseError("amount_minor phải là số nguyên.")
            if self.amount_minor < 0:
                raise ExpenseError(f"amount_minor = {self.amount_minor}: không được âm.")
        if self.currency is not None and self.currency not in SUPPORTED_CURRENCIES:
            raise ExpenseError(f"Loại tiền '{self.currency}' chưa được hỗ trợ {list(SUPPORTED_CURRENCIES)}.")


Key = tuple[str, ...]


def lookup_keys(e: Expense) -> list[Key]:
    keys: list[Key] = []
    cur = e.currency
    receipt = normalize_text(e.receipt_id)
    vendor, invoice = normalize_text(e.vendor), normalize_text(e.invoice_number)
    if cur and receipt:
        keys.append(("receipt", cur, receipt))
    if cur and vendor and invoice:
        keys.append(("invoice", cur, vendor, invoice))
    return keys


@dataclass
class FieldDiff:
    field: str
    old: object
    new: object
    same_after_normalize: bool  # chỉ khác hoa/thường hoặc dấu cách


@dataclass
class Match:
    submission_id: str
    matched_by: list[str]
    differences: list[FieldDiff]
    amount_difference_minor: Optional[int] = None


@dataclass
class CheckResult:
    submission_id: str
    status: str
    keys: list[Key]
    matches: list[Match] = field(default_factory=list)
    reasons: list[str] = field(default_factory=list)
    near_matches: list[dict] = field(default_factory=list)  # gợi ý OCR đọc sai, chỉ để xem lại


COMPARE_FIELDS = ("vendor", "invoice_number", "transaction_date", "amount_minor", "currency", "receipt_id")
TEXT_FIELDS = {"vendor", "invoice_number", "receipt_id"}


def diff_fields(old: Expense, new: Expense) -> list[FieldDiff]:
    out = []
    for f in COMPARE_FIELDS:
        a, b = getattr(old, f), getattr(new, f)
        if a == b:
            continue
        same = f in TEXT_FIELDS and normalize_text(a) == normalize_text(b) and a is not None and b is not None
        out.append(FieldDiff(f, a.isoformat() if isinstance(a, date) else a,
                             b.isoformat() if isinstance(b, date) else b, same))
    return out


def edit_distance_at_most_one(a: str, b: str) -> bool:
    if a == b:
        return True
    if abs(len(a) - len(b)) > 1:
        return False
    if len(a) > len(b):
        a, b = b, a
    i = j = edits = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1
            j += 1
            continue
        edits += 1
        if edits > 1:
            return False
        if len(a) == len(b):
            i += 1
        j += 1
    return edits + (len(b) - j) <= 1


class DuplicateIndex:
    def __init__(self) -> None:
        self._subs: dict[str, Expense] = {}
        self._by_key: dict[Key, list[str]] = {}
        self._by_vendor: dict[tuple[str, str], list[str]] = {}  # cho phần gợi ý OCR

    def __len__(self) -> int:
        return len(self._subs)

    def get(self, submission_id: str) -> Optional[Expense]:
        return self._subs.get(submission_id)

    # ----------------------------------------------------------- tra cứu
    def check(self, e: Expense) -> CheckResult:
        keys = lookup_keys(e)
        res = CheckResult(e.submission_id, UNIQUE, keys)

        if not keys:
            res.status = NEEDS_REVIEW
            missing = []
            if not e.currency:
                missing.append("loại tiền")
            if not e.receipt_id:
                missing.append("mã biên nhận")
            if not (e.vendor and e.invoice_number):
                missing.append("cặp nơi bán + số hóa đơn")
            res.reasons.append(
                f"Không đủ thông tin để tạo nhãn tra cứu (thiếu {', '.join(missing)}). "
                "Chỉ cùng nơi bán, số tiền và ngày chưa đủ để gọi là trùng."
            )
            return res

        found: dict[str, list[str]] = {}
        for key in keys:
            for sid in self._by_key.get(key, []):
                if sid != e.submission_id:
                    found.setdefault(sid, []).append(key[0])
        if found:
            res.status = DUPLICATE
            for sid, kinds in found.items():
                old = self._subs[sid]
                amount_diff = None
                if old.amount_minor is not None and e.amount_minor is not None and old.amount_minor != e.amount_minor:
                    amount_diff = e.amount_minor - old.amount_minor
                res.matches.append(Match(sid, kinds, diff_fields(old, e), amount_diff))
                label = " và ".join("mã biên nhận" if k == "receipt" else "nơi bán + số hóa đơn" for k in kinds)
                res.reasons.append(f"Trùng {label} với {sid} (sau khi chuẩn hóa chữ hoa/thường, dấu cách).")
            return res

        if e.amount_minor is None:
            res.status = NEEDS_REVIEW
            res.reasons.append("Chưa trùng nhãn nào nhưng thiếu số tiền, nên chưa đủ tin cậy để kết luận.")
        else:
            res.reasons.append("Chưa thấy nhãn này: chưa trùng theo quy tắc hiện tại (không có nghĩa là chắc chắn hợp lệ).")
        res.near_matches = self._near_matches(e)
        return res

    def _near_matches(self, e: Expense) -> list[dict]:
        vendor, invoice = normalize_text(e.vendor), normalize_text(e.invoice_number)
        if not (e.currency and vendor and invoice):
            return []
        out = []
        for sid in self._by_vendor.get((e.currency, vendor), []):
            other = normalize_text(self._subs[sid].invoice_number)
            if sid != e.submission_id and other and other != invoice and edit_distance_at_most_one(other, invoice):
                out.append({"submission_id": sid, "invoice_number": self._subs[sid].invoice_number,
                            "note": "Số hóa đơn gần giống (lệch 1 ký tự), có thể do OCR đọc sai. Cần người xem lại."})
        return out

    # ----------------------------------------------------------- cập nhật
    def remove(self, submission_id: str) -> None:
        old = self._subs.pop(submission_id, None)
        if old is None:
            return
        for key in lookup_keys(old):
            ids = self._by_key.get(key, [])
            if submission_id in ids:
                ids.remove(submission_id)
            if not ids:
                self._by_key.pop(key, None)
        vk = (old.currency, normalize_text(old.vendor))
        if vk in self._by_vendor and submission_id in self._by_vendor[vk]:
            self._by_vendor[vk].remove(submission_id)

    def upsert(self, e: Expense) -> CheckResult:
        """Kiểm tra rồi lưu. Gửi lại cùng submission_id (đã sửa) thì gỡ bản cũ và kiểm tra lại."""
        self.remove(e.submission_id)
        result = self.check(e)
        self._subs[e.submission_id] = e
        for key in result.keys:
            self._by_key.setdefault(key, []).append(e.submission_id)
        vendor = normalize_text(e.vendor)
        if e.currency and vendor:
            self._by_vendor.setdefault((e.currency, vendor), []).append(e.submission_id)
        return result

    def clear(self) -> None:
        self._subs.clear()
        self._by_key.clear()
        self._by_vendor.clear()
