"""FastAPI backend - Bài 03: Hóa đơn này đã được gửi trước đó chưa?

Luồng: POST /expenses/extract (GenAI đọc chứng từ -> JSON, code kiểm tra)
    -> người dùng xem/sửa
    -> POST /expenses/check   (code tạo nhãn tra cứu, tìm trong hash map)
    -> POST /expenses/review  (người duyệt xác nhận trùng hoặc bỏ nghi vấn)
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse

from .dedup import DUPLICATE, NEEDS_REVIEW, CheckResult, DuplicateIndex
from .extractor import MockExtractor, get_extractor
from .schemas import SUPPORTED_CURRENCIES, CheckRequest, ExpenseExtraction, ExtractRequest, ReviewRequest
from .storage import AuditStore, utc_now_iso
from .validation import SUBMISSION_ID_RE, validate_expense

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent


def _error(status: int, message: str, errors: Optional[list[str]] = None, **extra: Any):
    raise HTTPException(status, detail={"message": message, "errors": errors or [], **extra})


def result_to_dict(r: CheckResult) -> dict[str, Any]:
    d = asdict(r)
    d["keys"] = [list(k) for k in r.keys]
    return d


def create_app(log_path: Optional[Path] = None) -> FastAPI:
    app = FastAPI(title="Bài 03 - Rà soát hóa đơn gửi trùng", version="1.0.0")
    store = AuditStore(log_path)
    index = DuplicateIndex()
    lock = threading.Lock()
    # submission_id -> {"expense": dict, "result": dict, "review": dict|None, "extraction_id": str}
    subs: dict[str, dict[str, Any]] = {}
    counter = {"n": 0}
    app.state.index = index

    def next_id() -> str:
        used = set(subs) | {r["submission_id"] for r in store.all()}
        while True:
            counter["n"] += 1
            sid = f"E{counter['n']:02d}"
            if sid not in used:
                return sid

    @app.get("/", include_in_schema=False)
    def page() -> FileResponse:
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/config")
    def config() -> dict[str, Any]:
        return {"openai_available": bool(os.getenv("OPENAI_API_KEY")),
                "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"), "currencies": SUPPORTED_CURRENCIES}

    @app.get("/schema/expense")
    def schema() -> dict[str, Any]:
        return ExpenseExtraction.model_json_schema()

    # ------------------------------------------------------------------ extract
    @app.post("/expenses/extract")
    def extract(req: ExtractRequest) -> dict[str, Any]:
        if req.submission_id is not None:
            sid = req.submission_id.strip()
            if not SUBMISSION_ID_RE.match(sid):
                _error(422, "Mã lượt gửi không hợp lệ.", ["submission_id chỉ gồm chữ, số, '-' hoặc '_'."])
            if sid in subs:
                _error(409, f"Mã '{sid}' đã được kiểm tra. Muốn sửa thì gửi lại qua bước kiểm tra.",
                       [f"submission_id '{sid}' bị trùng."])
        else:
            sid = next_id()
        try:
            extractor = get_extractor(req.mode)
        except RuntimeError as exc:
            _error(400, str(exc))
        started = time.perf_counter()
        result = extractor.extract(sid, req.text)
        latency = int((time.perf_counter() - started) * 1000)

        errors, warnings, missing = [], [], []
        if result.data is not None:
            vr = validate_expense(result.data, sid)
            errors, warnings, missing = vr.errors, vr.warnings, vr.missing
        if result.error:
            errors.insert(0, result.error)
        record = store.create(submission_id=sid, raw_text=req.text, source=result.source, llm_output=result.data,
                              llm_error=result.error, extract_errors=errors, extract_latency_ms=latency)
        return {"extraction_id": record["extraction_id"], "submission_id": sid, "source": result.source,
                "extraction": result.data, "errors": errors, "warnings": warnings, "missing": missing,
                "latency_ms": latency}

    # ------------------------------------------------------------------ check
    def _check(expense_data: dict[str, Any], extraction_id: Optional[str]) -> dict[str, Any]:
        record = store.get(extraction_id) if extraction_id else None
        if extraction_id and record is None:
            _error(404, "Không tìm thấy lượt đọc chứng từ này.")
        expected = record["submission_id"] if record else None
        vr = validate_expense(expense_data, expected)
        if not vr.ok:
            # Dữ liệu chưa đủ tin cậy -> KHÔNG trả "chưa trùng"
            _error(422, "Dữ liệu chưa hợp lệ nên chưa kiểm tra trùng.", vr.errors, warnings=vr.warnings)
        e = vr.expense
        with lock:
            previous = subs.get(e.submission_id)
            result = index.upsert(e)
            entry = {"expense": expense_data, "result": result_to_dict(result), "review": None,
                     "extraction_id": extraction_id or (previous or {}).get("extraction_id"),
                     "checked_at": utc_now_iso()}
            rechecked = previous is not None
            if rechecked and previous["expense"].get("receipt_id") != expense_data.get("receipt_id"):
                entry["result"]["reasons"].insert(0, "Mã biên nhận vừa được sửa nên đã kiểm tra trùng lại.")
            subs[e.submission_id] = entry

        rec_id = entry["extraction_id"]
        if rec_id and store.get(rec_id):
            r = store.get(rec_id)
            store.update(rec_id, status="checked", user_edited=expense_data,
                         user_changed_fields=sorted(k for k in expense_data if (r.get("llm_output") or {}).get(k) != expense_data.get(k)),
                         check_result=entry["result"], checked_at=entry["checked_at"])
        return {**entry["result"], "warnings": vr.warnings, "rechecked": rechecked}

    @app.post("/expenses/check")
    def check(req: CheckRequest) -> dict[str, Any]:
        return _check(req.expense, req.extraction_id)

    # ------------------------------------------------------------------ review
    @app.post("/expenses/review")
    def review(req: ReviewRequest) -> dict[str, Any]:
        entry = subs.get(req.submission_id)
        if entry is None:
            _error(404, f"Chưa có chứng từ '{req.submission_id}'.")
        status = entry["result"]["status"]
        if status not in (DUPLICATE, NEEDS_REVIEW) and not entry["result"]["near_matches"]:
            _error(409, "Chứng từ này không có nghi vấn để duyệt.", [f"Trạng thái hiện tại: {status}."])
        entry["review"] = {"decision": req.decision, "note": req.note, "reviewed_at": utc_now_iso()}
        if entry["extraction_id"] and store.get(entry["extraction_id"]):
            store.update(entry["extraction_id"], review=entry["review"])
        return {"submission_id": req.submission_id, "status": status, "review": entry["review"]}

    @app.get("/expenses")
    def list_expenses() -> list[dict[str, Any]]:
        return [{"submission_id": sid, **v} for sid, v in subs.items()]

    @app.get("/records")
    def records(limit: int = Query(50, ge=1, le=500)) -> list[dict[str, Any]]:
        return list(reversed(store.all()))[:limit]

    @app.post("/demo/load-sample")
    def load_sample() -> dict[str, Any]:
        """Đọc E01-E03 trong đề bằng mock rồi kiểm tra - không gọi model."""
        samples = json.loads((ROOT_DIR / "sample_data" / "receipts.json").read_text("utf-8"))
        out = []
        for s in samples:
            if s["submission_id"] in subs:
                continue
            data = MockExtractor().extract(s["submission_id"], s["text"]).data
            rec = store.create(submission_id=s["submission_id"], raw_text=s["text"], source="sample", llm_output=data)
            res = _check(data, rec["extraction_id"])
            out.append({"submission_id": s["submission_id"], "status": res["status"]})
        return {"loaded": out}

    @app.post("/demo/reset")
    def reset() -> dict[str, Any]:
        with lock:
            index.clear()
            subs.clear()
            store.clear()
            counter["n"] = 0
        return {"ok": True}

    return app


app = create_app(Path(os.getenv("AUDIT_LOG_PATH", str(ROOT_DIR / "data" / "audit_log.jsonl"))))
