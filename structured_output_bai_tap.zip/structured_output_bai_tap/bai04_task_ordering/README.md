# Bài 04 - Việc nào phải làm trước?

Trang web đọc biên bản họp bằng GenAI (OpenAI qua LangChain) để lập danh sách công việc và quan hệ trước-sau, cho người dùng xem và sửa, rồi code xếp thứ tự bằng **topological sort**. Nếu kế hoạch có vòng chờ nhau, app báo `cycle_detected` và chỉ ra vòng cần sửa.

![Xếp được thứ tự](docs/screenshot.png)
![Có vòng chờ nhau](docs/screenshot_cycle.png)

## Cấu trúc

```
bai04_task_ordering/
├── app/
│   ├── schemas.py      # Mẫu JSON GenAI phải trả (tasks + dependencies)
│   ├── extractor.py    # GenAI: LangChain with_structured_output + MockExtractor
│   ├── topo.py         # THUẬT TOÁN: validate_plan, topo_order (Kahn + heap), tìm vòng
│   ├── storage.py      # Lưu vết data/audit_log.jsonl
│   ├── main.py         # FastAPI
│   └── static/index.html
├── tests/
│   ├── test_topo.py    # Test thuật toán, không phụ thuộc GenAI
│   └── test_api.py     # Test API (mock)
├── sample_data/minutes.json   # Biên bản trong đề, biên bản có vòng, biên bản không có quan hệ
└── docs/plan.schema.json      # Mẫu dữ liệu GenAI phải trả
```

## Cài đặt và chạy

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # điền OPENAI_API_KEY (không bắt buộc)
uvicorn app.main:app --reload      # http://localhost:8000
pytest -q
```

Không có `OPENAI_API_KEY` thì app dùng **MockExtractor**. Mock đọc được biên bản có dòng `- A: Tên việc (Nhóm)` và các câu chứa mã việc trong ngoặc như `(A)`, kèm từ chỉ quan hệ "trước", "sau", "chờ", "phụ thuộc". Biên bản viết tự do thì cần dùng OpenAI.

## Luồng sử dụng

1. Trang mở sẵn biên bản trong đề. Bấm **Đọc biên bản**, xem bảng công việc và bảng quan hệ (mỗi quan hệ kèm câu bằng chứng).
2. Sửa nếu cần: đổi mã, tên, người phụ trách; thêm hoặc xóa việc và quan hệ.
3. Bấm **Xếp thứ tự**: A → B → C → D, kèm lý do từng bước ("Lúc này A, B cùng sẵn sàng; chọn A vì mã đứng trước theo alphabet") và nhóm việc làm cùng lúc: [A, B] → [C] → [D].
4. Chip **Có vòng D → A**: app báo vòng A → C → D → A, liệt kê từng quan hệ trong vòng kèm bằng chứng. Bấm **Xóa quan hệ này** trên D → A thì app xếp lại được ngay.
5. **Chỉ kiểm tra** để xem lỗi và cảnh báo mà chưa xếp thứ tự.

## API

| Method | Đường dẫn | Việc làm |
|---|---|---|
| POST | `/plans/extract` | Nhận `minutes`, `mode`. GenAI lập danh sách, code kiểm tra, trả lỗi + cảnh báo. |
| POST | `/plans/validate` | Nhận `plan` đã sửa. Trả `valid`, lỗi, cảnh báo và kế hoạch đã chuẩn hóa (bỏ quan hệ lặp). |
| POST | `/plans/order` | Kiểm tra lại, rồi trả `status: ok` + `order`, `reasons`, `levels`; hoặc `status: cycle_detected` + `cycle`, `cycle_edges`, `blocked`. Còn lỗi → 422. |
| GET | `/records` | Lịch sử: biên bản gốc, JSON GenAI, bản sửa, kết quả, thời gian. |
| GET | `/schema/plan` | JSON Schema GenAI phải trả. |

## Mẫu dữ liệu GenAI phải trả

```json
{
  "tasks": [
    {"id": "A", "title": "Chốt yêu cầu API", "owner": "Product"},
    {"id": "B", "title": "Duyệt thiết kế UI", "owner": "Design"},
    {"id": "C", "title": "Tích hợp frontend", "owner": "Engineering"},
    {"id": "D", "title": "Kiểm thử end-to-end", "owner": "QA"}
  ],
  "dependencies": [
    {"before": "A", "after": "C", "evidence": "Sau khi chốt API mới tích hợp frontend"},
    {"before": "B", "after": "C", "evidence": "Duyệt UI trước khi tích hợp"},
    {"before": "C", "after": "D", "evidence": "Kiểm thử sau khi tích hợp"}
  ]
}
```

`owner` có thể `null`. Prompt yêu cầu `evidence` phải chép nguyên văn từ biên bản và cấm suy luận quan hệ khi không có bằng chứng. Backend kiểm tra thêm: nếu câu bằng chứng không có nguyên văn trong biên bản thì cảnh báo để người dùng xem lại quan hệ đó.

## Thuật toán

**Kiểm tra kế hoạch** (`validate_plan`):
- Từ chối mã việc trống, sai định dạng hoặc trùng.
- Từ chối quan hệ dùng mã lạ, việc tự chờ chính nó, hoặc thiếu câu bằng chứng.
- Quan hệ ghi lặp chỉ tính một lần, kèm cảnh báo.
- Kế hoạch không có quan hệ nào vẫn hợp lệ, kèm cảnh báo.

**Xếp thứ tự** (`topo_order`, thuật toán Kahn):
1. Đếm số việc đứng trước (bậc vào) của từng việc. Việc có bậc vào 0 vào một min-heap.
2. Lấy việc có mã nhỏ nhất khỏi heap, ghi vào thứ tự, giảm bậc vào các việc đứng sau nó. Việc nào về 0 thì vào heap.
3. Dùng heap nên khi nhiều việc cùng sẵn sàng, việc có mã đứng trước theo alphabet luôn được chọn. Đổi thứ tự task trong JSON vẫn cho cùng kết quả.

Độ phức tạp: O((V + E) log V) với V việc và E quan hệ.

**Tìm vòng:** nếu không xếp hết được, các việc còn lại đều đang kẹt. Mỗi việc kẹt luôn có ít nhất một việc đứng trước cũng đang kẹt, nên bắt đầu từ việc kẹt có mã nhỏ nhất và đi ngược theo việc đứng trước, chắc chắn sẽ gặp lại một việc đã đi qua. Đoạn từ lần gặp đầu đến lần gặp lại chính là một vòng. App đảo lại theo chiều mũi tên và bắt đầu từ mã nhỏ nhất cho dễ đọc: A → C → D → A. Các việc kẹt nhưng không nằm trong vòng được liệt kê riêng trong `blocked`. App **không** trả nửa danh sách như thể đó là kế hoạch hoàn chỉnh.

**Làm thêm, nhóm làm song song:** mức của một việc bằng 1 + mức lớn nhất trong các việc đứng trước nó. Việc cùng mức có thể làm cùng lúc. App chỉ hiển thị thứ tự và nhóm, không tự biến thành lịch ngày giờ vì chưa có thời lượng và số người.

## Test

32 test:

- **Ca thường:** ví dụ trong đề ra A → B → C → D; xáo trộn thứ tự task và quan hệ 10 lần vẫn cùng kết quả; mọi mũi tên đều đi từ việc trước sang việc sau; lý do bước đầu nêu A và B cùng sẵn sàng; nhóm song song [A, B] → [C] → [D].
- **Ca sát giới hạn:** không có quan hệ nào; chỉ một việc; vòng ba việc A → C → D → A; vòng hai việc kèm việc bị kẹt; việc có mã nhỏ nhất nằm sau vòng nhưng không thuộc vòng; xóa quan hệ gây vòng thì xếp được.
- **Dữ liệu sai:** mã lạ, việc tự chờ chính nó, mã việc trùng, quan hệ lặp, thiếu bằng chứng, mã việc sai định dạng, kế hoạch rỗng, bằng chứng không có trong biên bản.
- **Hiệu năng:** 20.000 việc và khoảng 27.000 quan hệ trong vài giây.

## GenAI làm gì, code làm gì?

**GenAI** đọc biên bản viết thành đoạn văn và tách ra hai thứ: danh sách công việc (mã, tên, người phụ trách) và các quan hệ trước-sau, mỗi quan hệ kèm câu bằng chứng chép từ biên bản.

**Code** kiểm tra danh sách (mã lạ, mã trùng, tự phụ thuộc, quan hệ lặp, bằng chứng có thật trong biên bản không), rồi chạy topological sort với quy tắc chọn theo alphabet để kết quả luôn giống nhau. Khi có vòng, code chỉ ra chính xác các quan hệ tạo thành vòng.

**Con người** xem và sửa danh sách trước khi xếp. Chỉ những quan hệ người dùng đã xác nhận mới được dùng để tính thứ tự.
