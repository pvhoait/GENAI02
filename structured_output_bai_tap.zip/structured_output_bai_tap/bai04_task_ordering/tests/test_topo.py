"""Test thuật toán Bài 04 - không gọi GenAI."""
import random

import pytest

from app.topo import Dependency, topo_order, validate_plan

TASKS = [
    {"id": "A", "title": "Chốt yêu cầu API", "owner": "Product"},
    {"id": "B", "title": "Duyệt thiết kế UI", "owner": "Design"},
    {"id": "C", "title": "Tích hợp frontend", "owner": "Engineering"},
    {"id": "D", "title": "Kiểm thử end-to-end", "owner": "QA"},
]
DEPS = [
    {"before": "A", "after": "C", "evidence": "Sau khi chốt API mới tích hợp frontend"},
    {"before": "B", "after": "C", "evidence": "Duyệt UI trước khi tích hợp"},
    {"before": "C", "after": "D", "evidence": "Kiểm thử sau khi tích hợp"},
]


def run(tasks, deps):
    v = validate_plan(tasks, deps)
    assert v.ok, v.errors
    return topo_order([t.id for t in v.tasks], v.dependencies)


# ----------------------------------------------------------------- ca thường
def test_sample_order_A_B_C_D():
    r = run(TASKS, DEPS)
    assert r.status == "ok" and r.order == ["A", "B", "C", "D"]


def test_same_result_when_json_order_shuffled():
    rnd = random.Random(1)
    for _ in range(10):
        t, d = TASKS[:], DEPS[:]
        rnd.shuffle(t)
        rnd.shuffle(d)
        assert run(t, d).order == ["A", "B", "C", "D"]


def test_steps_explain_alphabet_choice():
    first = run(TASKS, DEPS).steps[0]
    assert first.task_id == "A" and first.ready == ["A", "B"] and first.waited_for == []


def test_parallel_groups():
    assert run(TASKS, DEPS).levels == [["A", "B"], ["C"], ["D"]]


def test_every_edge_goes_forward():
    r = run(TASKS, DEPS)
    pos = {n: i for i, n in enumerate(r.order)}
    assert all(pos[d["before"]] < pos[d["after"]] for d in DEPS)


# ----------------------------------------------------------- ca sát giới hạn
def test_no_dependencies_sorted_alphabetically():
    r = run([{"id": i, "title": i} for i in ["C", "A", "B"]], [])
    assert r.order == ["A", "B", "C"] and r.levels == [["A", "B", "C"]]


def test_single_task():
    assert run([{"id": "X", "title": "x"}], []).order == ["X"]


def test_cycle_detected_with_cycle_path():
    r = run(TASKS, DEPS + [{"before": "D", "after": "A", "evidence": "Kiểm thử trước khi chốt API"}])
    assert r.status == "cycle_detected"
    assert r.cycle == ["A", "C", "D", "A"]
    assert [(e.before, e.after) for e in r.cycle_edges] == [("A", "C"), ("C", "D"), ("D", "A")]
    assert r.order == []  # không trả nửa danh sách


def test_remove_cycle_edge_then_order_works():
    assert run(TASKS, DEPS).status == "ok"


def test_two_task_cycle_and_blocked_tasks():
    tasks = [{"id": x, "title": x} for x in "ABCE"]
    deps = [{"before": "A", "after": "B", "evidence": "e"}, {"before": "B", "after": "A", "evidence": "e"},
            {"before": "B", "after": "C", "evidence": "e"}]
    r = run(tasks, deps)
    assert r.cycle == ["A", "B", "A"] and r.blocked == ["C"]


def test_cycle_found_even_when_start_node_is_downstream():
    # A có ID nhỏ nhất nhưng chỉ nằm SAU vòng B <-> C, không thuộc vòng
    tasks = [{"id": x, "title": x} for x in "ABC"]
    deps = [{"before": "B", "after": "C", "evidence": "e"}, {"before": "C", "after": "B", "evidence": "e"},
            {"before": "C", "after": "A", "evidence": "e"}]
    r = run(tasks, deps)
    assert r.cycle == ["B", "C", "B"] and r.blocked == ["A"]


# ------------------------------------------------------------- dữ liệu sai
def test_unknown_id_rejected():
    v = validate_plan(TASKS, [{"before": "A", "after": "Z", "evidence": "e"}])
    assert any("mã lạ" in e for e in v.errors)


def test_self_dependency_rejected():
    v = validate_plan(TASKS, [{"before": "C", "after": "C", "evidence": "e"}])
    assert any("tự chờ" in e for e in v.errors)


def test_duplicate_task_id_rejected():
    v = validate_plan(TASKS + [{"id": "A", "title": "Trùng"}], DEPS)
    assert any("bị trùng" in e for e in v.errors)


def test_duplicate_dependency_counted_once():
    v = validate_plan(TASKS, DEPS + [DEPS[0]])
    assert v.ok and len(v.dependencies) == 3 and any("ghi lặp" in w for w in v.warnings)


def test_missing_evidence_rejected():
    v = validate_plan(TASKS, [{"before": "A", "after": "C", "evidence": "  "}])
    assert any("bằng chứng" in e for e in v.errors)


@pytest.mark.parametrize("bad", ["", "A B", None, "x" * 40])
def test_invalid_task_id(bad):
    assert not validate_plan([{"id": bad, "title": "t"}], []).ok


def test_empty_plan_rejected():
    assert not validate_plan([], []).ok


def test_topo_order_rejects_unknown_ids_directly():
    with pytest.raises(ValueError):
        topo_order(["A"], [Dependency("A", "Z")])


# ----------------------------------------------------------------- hiệu năng
def test_large_dag_fast():
    import time

    n = 20_000
    tasks = [f"T{i:05d}" for i in range(n)]
    deps = [Dependency(tasks[i], tasks[i + 1]) for i in range(n - 1)]
    deps += [Dependency(tasks[i], tasks[i + 7]) for i in range(0, n - 7, 3)]
    start = time.perf_counter()
    r = topo_order(tasks, deps)
    assert r.status == "ok" and r.order == tasks
    assert time.perf_counter() - start < 3
