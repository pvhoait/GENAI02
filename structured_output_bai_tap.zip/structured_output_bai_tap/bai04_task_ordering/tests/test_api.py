"""Test API Bài 04 ở chế độ mock."""
import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app

SAMPLES = json.loads((Path(__file__).parent.parent / "sample_data" / "minutes.json").read_text("utf-8"))


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    return TestClient(create_app(tmp_path / "audit.jsonl"))


def extract(client, i):
    r = client.post("/plans/extract", json={"minutes": SAMPLES[i]["minutes"], "mode": "mock"})
    assert r.status_code == 200, r.text
    return r.json()


def test_sample_flow(client):
    ex = extract(client, 0)
    assert ex["errors"] == [] and len(ex["extraction"]["dependencies"]) == 3
    r = client.post("/plans/order", json={"extraction_id": ex["extraction_id"], "plan": ex["extraction"]}).json()
    assert r["status"] == "ok" and r["order"] == ["A", "B", "C", "D"]
    assert "chọn A vì mã đứng trước" in r["reasons"][0]


def test_cycle_then_fix(client):
    ex = extract(client, 1)
    r = client.post("/plans/order", json={"extraction_id": ex["extraction_id"], "plan": ex["extraction"]}).json()
    assert r["status"] == "cycle_detected" and r["cycle"] == ["A", "C", "D", "A"] and "order" not in r
    plan = ex["extraction"]
    plan["dependencies"] = [d for d in plan["dependencies"] if (d["before"], d["after"]) != ("D", "A")]
    r2 = client.post("/plans/order", json={"extraction_id": ex["extraction_id"], "plan": plan}).json()
    assert r2["status"] == "ok"


def test_no_dependencies(client):
    ex = extract(client, 2)
    r = client.post("/plans/order", json={"plan": ex["extraction"]}).json()
    assert r["order"] == ["T1", "T2", "T3"] and any("không có quan hệ" in w for w in r["warnings"])


@pytest.mark.parametrize("patch, expected", [
    ({"dependencies": [{"before": "A", "after": "Z", "evidence": "x"}]}, "mã lạ"),
    ({"dependencies": [{"before": "A", "after": "A", "evidence": "x"}]}, "tự chờ"),
])
def test_validate_rejects(client, patch, expected):
    plan = {**extract(client, 0)["extraction"], **patch}
    v = client.post("/plans/validate", json={"plan": plan}).json()
    assert not v["valid"] and any(expected in e for e in v["errors"])
    assert client.post("/plans/order", json={"plan": plan}).status_code == 422


def test_duplicate_task_id_rejected(client):
    plan = extract(client, 0)["extraction"]
    plan["tasks"].append({"id": "A", "title": "Trùng", "owner": None})
    assert client.post("/plans/order", json={"plan": plan}).status_code == 422


def test_duplicate_dependency_counted_once(client):
    plan = extract(client, 0)["extraction"]
    plan["dependencies"].append(dict(plan["dependencies"][0]))
    v = client.post("/plans/validate", json={"plan": plan}).json()
    assert v["valid"] and len(v["plan"]["dependencies"]) == 3


def test_evidence_not_in_minutes_warned(client):
    ex = extract(client, 0)
    plan = ex["extraction"]
    plan["dependencies"].append({"before": "A", "after": "B", "evidence": "Câu này không có trong biên bản"})
    v = client.post("/plans/validate", json={"extraction_id": ex["extraction_id"], "plan": plan}).json()
    assert v["valid"] and any("không có nguyên văn" in w for w in v["warnings"])


def test_audit_record(client):
    ex = extract(client, 0)
    client.post("/plans/order", json={"extraction_id": ex["extraction_id"], "plan": ex["extraction"]})
    rec = client.get("/records").json()[0]
    assert rec["raw_minutes"] and rec["llm_output"] and rec["user_edited"] and rec["final_result"]["status"] == "ok"
