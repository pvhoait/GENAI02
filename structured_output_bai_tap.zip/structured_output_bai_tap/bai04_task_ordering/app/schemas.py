"""Schema dữ liệu Bài 04 - xếp việc theo thứ tự trước-sau."""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

MAX_TASKS = 200


class TaskItem(BaseModel):
    id: str = Field(description="Mã việc ngắn, duy nhất (vd A, B, C hoặc T1, T2). Không dùng tên việc làm mã.")
    title: str = Field(description="Tên công việc, ngắn gọn.")
    owner: Optional[str] = Field(description="Người hoặc nhóm phụ trách. null nếu biên bản không nói.")


class DependencyItem(BaseModel):
    before: str = Field(description="Mã việc phải xong TRƯỚC.")
    after: str = Field(description="Mã việc chỉ làm được SAU khi việc 'before' xong.")
    evidence: str = Field(description="Câu ngắn chép từ biên bản cho thấy quan hệ trước-sau này.")


class PlanExtraction(BaseModel):
    """Danh sách việc và quan hệ trước-sau đọc từ biên bản. Không tự thêm quan hệ khi không có bằng chứng."""

    tasks: list[TaskItem] = Field(description="Các công việc được nhắc trong biên bản.")
    dependencies: list[DependencyItem] = Field(
        description="Chỉ những quan hệ trước-sau CÓ câu bằng chứng trong biên bản. Không suy đoán."
    )


class ExtractRequest(BaseModel):
    minutes: str = Field(min_length=1, max_length=20000, description="Nội dung biên bản họp")
    mode: Literal["auto", "mock", "openai"] = "auto"


class PlanRequest(BaseModel):
    extraction_id: Optional[str] = None
    plan: dict[str, Any]
