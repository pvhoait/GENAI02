"""FastAPI backend - Bài 04: Việc nào phải làm trước?

Luồng: POST /plans/extract  (GenAI đọc biên bản -> tasks + dependencies, code kiểm tra)
    -> người dùng xem/sửa danh sách việc và quan hệ
    -> POST /plans/validate (kiểm tra mã lạ, mã trùng, tự phụ thuộc, quan hệ lặp)
    -> POST /plans/order    (topological sort, hoặc báo cycle_detected)
"""
from __future__ import annotations

import os
import time
import unicodedata
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse

from .extractor import get_extractor
from .schemas import MAX_TASKS, ExtractRequest, PlanExtraction, PlanRequest
from .storage import AuditStore, utc_now_iso
from .topo import OrderResult, PlanValidation, topo_order, validate_plan

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent


def _error(status: int, message: str, errors: Optional[list[str]] = None, **extra: Any):
    raise HTTPException(status, detail={"message": message, "errors": errors or [], **extra})


def _norm(text: str) -> str:
    return " ".join(unicodedata.normalize("NFC", text).casefold().split())


def _validate(plan: Any, minutes: Optional[str]) -> PlanValidation:
    if not isinstance(plan, dict):
        res = PlanValidation()
        res.errors.append("plan phải là object có tasks và dependencies.")
        return res
    res = validate_plan(plan.get("tasks"), plan.get("dependencies", []))
    if isinstance(plan.get("tasks"), list) and len(plan["tasks"]) > MAX_TASKS:
        res.errors.append(f"Kế hoạch có hơn {MAX_TASKS} việc.")
    if minutes:
        source = _norm(minutes)
        for d in res.dependencies:
            if _norm(d.evidence) not in source:
                res.warnings.append(
                    f"Bằng chứng của {d.before} → {d.after} không có nguyên văn trong biên bản: hãy kiểm tra quan hệ này."
                )
    return res


def plan_to_dict(v: PlanValidation) -> dict[str, Any]:
    return {"tasks": [asdict(t) for t in v.tasks], "dependencies": [asdict(d) for d in v.dependencies]}


def explain(result: OrderResult, v: PlanValidation) -> list[str]:
    titles = {t.id: t.title for t in v.tasks}
    lines = []
    for s in result.steps:
        why = "không phải chờ việc nào" if not s.waited_for else f"chờ {', '.join(s.waited_for)} xong"
        line = f"{s.task_id} ({titles.get(s.task_id, '')}): {why}."
        if len(s.ready) > 1:
            line += f" Lúc này {', '.join(s.ready)} cùng sẵn sàng; chọn {s.task_id} vì mã đứng trước theo alphabet."
        lines.append(line)
    return lines


def create_app(log_path: Optional[Path] = None) -> FastAPI:
    app = FastAPI(title="Bài 04 - Xếp việc theo thứ tự trước-sau", version="1.0.0")
    store = AuditStore(log_path)

    @app.get("/", include_in_schema=False)
    def page() -> FileResponse:
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/config")
    def config() -> dict[str, Any]:
        return {"openai_available": bool(os.getenv("OPENAI_API_KEY")), "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini")}

    @app.get("/schema/plan")
    def schema() -> dict[str, Any]:
        return PlanExtraction.model_json_schema()

    @app.post("/plans/extract")
    def extract(req: ExtractRequest) -> dict[str, Any]:
        try:
            extractor = get_extractor(req.mode)
        except RuntimeError as exc:
            _error(400, str(exc))
        started = time.perf_counter()
        result = extractor.extract(req.minutes)
        latency = int((time.perf_counter() - started) * 1000)
        errors, warnings = [], []
        if result.data is not None:
            v = _validate(result.data, req.minutes)
            errors, warnings = v.errors, v.warnings
        if result.error:
            errors.insert(0, result.error)
        record = store.create(raw_minutes=req.minutes, source=result.source, llm_output=result.data,
                              llm_error=result.error, extract_errors=errors, extract_latency_ms=latency)
        return {"extraction_id": record["extraction_id"], "source": result.source, "extraction": result.data,
                "errors": errors, "warnings": warnings, "latency_ms": latency}

    def _minutes(extraction_id: Optional[str]) -> Optional[str]:
        if not extraction_id:
            return None
        rec = store.get(extraction_id)
        if rec is None:
            _error(404, "Không tìm thấy lượt đọc biên bản này.")
        return rec["raw_minutes"]

    @app.post("/plans/validate")
    def validate(req: PlanRequest) -> dict[str, Any]:
        v = _validate(req.plan, _minutes(req.extraction_id))
        return {"valid": v.ok, "errors": v.errors, "warnings": v.warnings, "plan": plan_to_dict(v)}

    @app.post("/plans/order")
    def order(req: PlanRequest) -> dict[str, Any]:
        v = _validate(req.plan, _minutes(req.extraction_id))
        if not v.ok:
            _error(422, "Kế hoạch còn lỗi, chưa thể xếp thứ tự.", v.errors, warnings=v.warnings)
        result = topo_order([t.id for t in v.tasks], v.dependencies)
        out: dict[str, Any] = {"status": result.status, "warnings": v.warnings, "plan": plan_to_dict(v)}
        if result.status == "ok":
            out.update(order=result.order, reasons=explain(result, v), levels=result.levels)
        else:
            out.update(
                cycle=result.cycle,
                cycle_edges=[asdict(d) for d in result.cycle_edges],
                blocked=result.blocked,
                message=f"Có vòng chờ nhau: {' → '.join(result.cycle)}. Hãy xóa hoặc sửa một quan hệ trong vòng.",
            )
        if req.extraction_id:
            store.update(req.extraction_id, user_edited=req.plan, final_result=out,
                         status=result.status, ordered_at=utc_now_iso())
        return out

    @app.get("/records")
    def records(limit: int = Query(50, ge=1, le=500)) -> list[dict[str, Any]]:
        return list(reversed(store.all()))[:limit]

    return app


app = create_app(Path(os.getenv("AUDIT_LOG_PATH", str(ROOT_DIR / "data" / "audit_log.jsonl"))))
