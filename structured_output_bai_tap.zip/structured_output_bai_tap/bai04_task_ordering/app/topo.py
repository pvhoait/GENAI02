"""Thuật toán Bài 04 - xếp việc theo thứ tự trước-sau. Không phụ thuộc GenAI.

Mũi tên A -> B nghĩa là phải xong A rồi mới làm B.
- Kahn + min-heap: khi nhiều việc cùng sẵn sàng, chọn ID nhỏ nhất theo alphabet,
  nên mỗi lần chạy cho cùng một kết quả. O((V + E) log V).
- Không xếp hết được => có vòng. Tìm một vòng bằng cách đi ngược theo việc đứng trước:
  mọi việc còn kẹt đều có ít nhất một việc đứng trước cũng đang kẹt, nên đi mãi sẽ gặp lại
  một việc đã qua. O(V + E).
"""
from __future__ import annotations

import heapq
import re
from dataclasses import dataclass, field
from typing import Any, Optional

TASK_ID_RE = re.compile(r"^[A-Za-z0-9_.-]{1,32}$")


@dataclass(frozen=True)
class Task:
    id: str
    title: str
    owner: Optional[str] = None


@dataclass(frozen=True)
class Dependency:
    before: str
    after: str
    evidence: str = ""


@dataclass
class PlanValidation:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    tasks: list[Task] = field(default_factory=list)
    dependencies: list[Dependency] = field(default_factory=list)  # đã bỏ quan hệ lặp

    @property
    def ok(self) -> bool:
        return not self.errors


@dataclass
class Step:
    task_id: str
    ready: list[str]           # các việc đang sẵn sàng lúc chọn
    waited_for: list[str]      # các việc phải xong trước việc này


@dataclass
class OrderResult:
    status: str                                  # "ok" | "cycle_detected"
    order: list[str] = field(default_factory=list)
    steps: list[Step] = field(default_factory=list)
    levels: list[list[str]] = field(default_factory=list)  # nhóm làm song song (phần làm thêm)
    cycle: list[str] = field(default_factory=list)          # vd ["A", "C", "D", "A"]
    cycle_edges: list[Dependency] = field(default_factory=list)
    blocked: list[str] = field(default_factory=list)        # bị kẹt vì phụ thuộc vào vòng


def _text(value: Any) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        return None
    return " ".join(value.split()) or None


def validate_plan(raw_tasks: Any, raw_deps: Any) -> PlanValidation:
    """Từ chối ID lạ, ID trùng, việc tự phụ thuộc chính nó; quan hệ lặp chỉ tính một lần."""
    res = PlanValidation()
    if not isinstance(raw_tasks, list):
        res.errors.append("tasks phải là danh sách.")
        return res
    if not isinstance(raw_deps, list):
        res.errors.append("dependencies phải là danh sách.")
        return res
    if not raw_tasks:
        res.errors.append("Kế hoạch chưa có công việc nào.")

    seen: set[str] = set()
    for i, t in enumerate(raw_tasks, 1):
        if not isinstance(t, dict):
            res.errors.append(f"Việc thứ {i} không phải object.")
            continue
        tid = _text(t.get("id"))
        title = _text(t.get("title"))
        if not tid or not TASK_ID_RE.match(tid):
            res.errors.append(f"Việc thứ {i}: mã '{t.get('id')}' không hợp lệ (chữ, số, '.', '-', '_', tối đa 32 ký tự).")
            continue
        if tid in seen:
            res.errors.append(f"Mã việc '{tid}' bị trùng.")
            continue
        if not title:
            res.errors.append(f"Việc '{tid}' chưa có tên.")
        seen.add(tid)
        res.tasks.append(Task(tid, title or "", _text(t.get("owner"))))

    pairs: set[tuple[str, str]] = set()
    for i, d in enumerate(raw_deps, 1):
        if not isinstance(d, dict):
            res.errors.append(f"Quan hệ thứ {i} không phải object.")
            continue
        b, a, ev = _text(d.get("before")), _text(d.get("after")), _text(d.get("evidence"))
        label = f"{b} → {a}"
        unknown = [x for x in (b, a) if x not in seen]
        if unknown:
            res.errors.append(f"Quan hệ {label}: mã lạ {sorted(set(str(u) for u in unknown))} không có trong danh sách việc.")
            continue
        if b == a:
            res.errors.append(f"Quan hệ {label}: việc '{b}' không thể tự chờ chính nó.")
            continue
        if not ev:
            res.errors.append(f"Quan hệ {label}: thiếu câu làm bằng chứng.")
            continue
        if (b, a) in pairs:
            res.warnings.append(f"Quan hệ {label} bị ghi lặp: chỉ tính một lần.")
            continue
        pairs.add((b, a))
        res.dependencies.append(Dependency(b, a, ev))

    if res.tasks and not raw_deps:
        res.warnings.append("Kế hoạch không có quan hệ trước-sau nào: mọi việc đều có thể bắt đầu ngay.")
    return res


def topo_order(task_ids: list[str], deps: list[Dependency]) -> OrderResult:
    nodes = sorted(set(task_ids))
    succ: dict[str, list[str]] = {n: [] for n in nodes}
    pred: dict[str, list[str]] = {n: [] for n in nodes}
    indeg = {n: 0 for n in nodes}
    for d in deps:
        if d.before not in indeg or d.after not in indeg:
            raise ValueError(f"Quan hệ {d.before} → {d.after} dùng mã không có trong danh sách việc.")
        if d.before == d.after:
            raise ValueError(f"Việc '{d.before}' không thể tự chờ chính nó.")
        succ[d.before].append(d.after)
        pred[d.after].append(d.before)
        indeg[d.after] += 1

    heap = [n for n in nodes if indeg[n] == 0]
    heapq.heapify(heap)
    result = OrderResult(status="ok")
    remaining = dict(indeg)
    while heap:
        ready = sorted(heap)
        n = heapq.heappop(heap)
        result.order.append(n)
        result.steps.append(Step(n, ready, sorted(pred[n])))
        for m in succ[n]:
            remaining[m] -= 1
            if remaining[m] == 0:
                heapq.heappush(heap, m)

    if len(result.order) == len(nodes):
        level: dict[str, int] = {}
        for n in result.order:
            level[n] = max((level[p] + 1 for p in pred[n]), default=0)
        groups: dict[int, list[str]] = {}
        for n, lv in level.items():
            groups.setdefault(lv, []).append(n)
        result.levels = [sorted(groups[k]) for k in sorted(groups)]
        return result

    # ---- Có vòng: KHÔNG trả nửa danh sách như thể là kế hoạch hoàn chỉnh
    stuck = {n for n in nodes if remaining[n] > 0}
    start = min(stuck)
    path: list[str] = []
    pos: dict[str, int] = {}
    cur = start
    while cur not in pos:
        pos[cur] = len(path)
        path.append(cur)
        cur = min(p for p in pred[cur] if p in stuck)  # luôn tồn tại
    loop_back = path[pos[cur]:]          # đi ngược: x <- pred(x) <- ...
    forward = list(reversed(loop_back))  # chiều mũi tên
    k = forward.index(min(forward))      # bắt đầu từ ID nhỏ nhất cho dễ đọc
    forward = forward[k:] + forward[:k]
    cycle = forward + [forward[0]]

    edge_map = {(d.before, d.after): d for d in deps}
    return OrderResult(
        status="cycle_detected",
        cycle=cycle,
        cycle_edges=[edge_map[(cycle[i], cycle[i + 1])] for i in range(len(cycle) - 1)],
        blocked=sorted(stuck - set(forward)),
    )
