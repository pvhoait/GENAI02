"""Lưu vết xử lý để xem lại sau.

Mỗi lần extract tạo một record; confirm/next cập nhật record đó.
Record được giữ trong bộ nhớ và ghi thêm (append) vào file JSONL - mỗi dòng là
một phiên bản của record, nên đọc file là thấy toàn bộ lịch sử.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class AuditStore:
    def __init__(self, log_path: Optional[Path] = None) -> None:
        self._records: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()
        self._log_path = log_path
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)

    def create(self, **fields: Any) -> dict[str, Any]:
        record = {
            "extraction_id": uuid.uuid4().hex[:12],
            "status": "extracted",
            "created_at": utc_now_iso(),
            **fields,
        }
        with self._lock:
            self._records[record["extraction_id"]] = record
            self._append(record)
        return record

    def get(self, extraction_id: str) -> Optional[dict[str, Any]]:
        return self._records.get(extraction_id)

    def update(self, extraction_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            record = self._records[extraction_id]
            record.update(fields, updated_at=utc_now_iso())
            self._append(record)
            return record

    def find_by_ticket(self, ticket_id: str) -> Optional[dict[str, Any]]:
        for r in reversed(list(self._records.values())):
            if r.get("ticket_id") == ticket_id and r.get("status") != "extracted":
                return r
        return None

    def all(self) -> list[dict[str, Any]]:
        return list(self._records.values())

    def clear(self) -> None:
        with self._lock:
            self._records.clear()

    def _append(self, record: dict[str, Any]) -> None:
        if not self._log_path:
            return
        with self._log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
