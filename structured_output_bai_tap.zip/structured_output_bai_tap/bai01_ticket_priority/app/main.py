"""FastAPI backend - Bài 01: Khách hàng nào cần được hỗ trợ trước?

Luồng: POST /tickets/extract  (GenAI đọc tin nhắn -> JSON theo mẫu, code kiểm tra)
    -> người dùng xem/sửa trên web
    -> POST /tickets/confirm   (code kiểm tra lại, tính hạn SLA, đưa vào min-heap)
    -> GET  /tickets/queue     (xem top K, không xóa)
    -> POST /tickets/next      (lấy ticket kế tiếp)
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse

from .extractor import get_extractor
from .priority_queue import (
    DuplicateTicketError,
    Ticket,
    TicketError,
    TicketQueue,
    compare_reason,
    explain_order,
)
from .schemas import (
    ConfirmRequest,
    ExtractRequest,
    ExtractResponse,
    QueueItem,
    QueueResponse,
    TicketExtraction,
)
from .storage import AuditStore, utc_now_iso
from .validation import build_ticket, parse_aware_datetime

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent
VN_TZ = timezone(timedelta(hours=7))
TICKET_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")


def ticket_to_dict(t: Ticket) -> dict[str, Any]:
    return {
        "ticket_id": t.ticket_id,
        "received_at": t.received_at.isoformat(),
        "deadline_at": t.deadline_at.isoformat(),
        "severity": t.severity,
        "severity_rank": t.severity_rank,
        "intent": t.intent,
        "product": t.product,
        "summary": t.summary,
        "needs_human_review": t.needs_human_review,
    }


def _error(status: int, message: str, errors: Optional[list[str]] = None, **extra: Any):
    raise HTTPException(status, detail={"message": message, "errors": errors or [], **extra})


def create_app(log_path: Optional[Path] = None) -> FastAPI:
    app = FastAPI(title="Bài 01 - Hàng đợi ưu tiên ticket CSKH", version="1.0.0")
    queue = TicketQueue()
    store = AuditStore(log_path)
    lock = threading.Lock()
    counter = {"n": 0}

    app.state.queue = queue
    app.state.store = store

    # ------------------------------------------------------------------ helpers
    def next_ticket_id() -> str:
        pending = {r["ticket_id"] for r in store.all()}
        while True:
            counter["n"] += 1
            tid = f"T{counter['n']:03d}"
            if not queue.has_seen(tid) and tid not in pending:
                return tid

    # ------------------------------------------------------------------ pages
    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/config")
    def config() -> dict[str, Any]:
        return {
            "openai_available": bool(os.getenv("OPENAI_API_KEY")),
            "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            "llm_mode": os.getenv("LLM_MODE", "auto"),
        }

    @app.get("/schema/ticket-extraction")
    def extraction_schema() -> dict[str, Any]:
        """Mẫu JSON GenAI phải trả."""
        return TicketExtraction.model_json_schema()

    # ------------------------------------------------------------------ extract
    @app.post("/tickets/extract", response_model=ExtractResponse)
    def extract(req: ExtractRequest) -> ExtractResponse:
        # 1) Thông tin hệ thống đã biết: ticket_id, received_at
        if req.ticket_id is not None:
            tid = req.ticket_id.strip()
            if not TICKET_ID_RE.match(tid):
                _error(422, "Mã ticket không hợp lệ.", ["ticket_id chỉ gồm chữ, số, '-' hoặc '_' (tối đa 32 ký tự)."])
            if queue.has_seen(tid):
                _error(409, f"Mã ticket '{tid}' đã có trong hệ thống.", [f"ticket_id '{tid}' bị trùng."])
        else:
            tid = next_ticket_id()

        if req.received_at:
            try:
                received = parse_aware_datetime(req.received_at)
            except TicketError as exc:
                _error(422, "Thời điểm nhận không hợp lệ.", [str(exc)])
        else:
            received = datetime.now(VN_TZ).replace(microsecond=0)

        # 2) GenAI điền mẫu
        started = time.perf_counter()
        try:
            extractor = get_extractor(req.mode)
        except RuntimeError as exc:
            _error(400, str(exc))
        result = extractor.extract(tid, req.message)
        latency_ms = int((time.perf_counter() - started) * 1000)

        # 3) Code kiểm tra lại
        errors: list[str] = []
        warnings: list[str] = []
        deadline_preview = None
        if result.data is not None:
            ticket, vr = build_ticket(result.data, tid, received.isoformat())
            errors, warnings = vr.errors, vr.warnings
            if ticket:
                deadline_preview = ticket.deadline_at.isoformat()
        if result.error:
            errors.insert(0, result.error)

        record = store.create(
            ticket_id=tid,
            received_at=received.isoformat(),
            raw_message=req.message,
            source=result.source,
            llm_output=result.data,
            llm_error=result.error,
            extract_errors=errors,
            extract_latency_ms=latency_ms,
        )
        return ExtractResponse(
            extraction_id=record["extraction_id"],
            ticket_id=tid,
            received_at=received.isoformat(),
            source=result.source,
            extraction=result.data,
            errors=errors,
            warnings=warnings,
            llm_error=result.error,
            deadline_preview=deadline_preview,
            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------ confirm
    @app.post("/tickets/confirm")
    def confirm(req: ConfirmRequest) -> dict[str, Any]:
        record = store.get(req.extraction_id)
        if record is None:
            _error(404, "Không tìm thấy lượt đọc tin nhắn này.", [f"extraction_id '{req.extraction_id}' không tồn tại."])
        if record["status"] != "extracted":
            _error(409, "Ticket này đã được xác nhận trước đó.", [f"Trạng thái hiện tại: {record['status']}."])

        ticket, vr = build_ticket(req.ticket, record["ticket_id"], record["received_at"])
        if ticket is None:
            store.update(req.extraction_id, user_edited=req.ticket, confirm_errors=vr.errors)
            _error(422, "Dữ liệu chưa hợp lệ, ticket chưa được đưa vào hàng đợi.", vr.errors, warnings=vr.warnings)

        with lock:
            try:
                queue.push(ticket)
            except DuplicateTicketError as exc:
                _error(409, "Mã ticket bị trùng.", [str(exc)])
            position = [t.ticket_id for t in queue.snapshot()].index(ticket.ticket_id) + 1

        created = datetime.fromisoformat(record["created_at"])
        store.update(
            req.extraction_id,
            status="confirmed",
            user_edited=req.ticket,
            user_changed_fields=sorted(
                k for k in vr.normalized
                if (record.get("llm_output") or {}).get(k) != vr.normalized.get(k)
            ),
            final_ticket=ticket_to_dict(ticket),
            confirmed_at=utc_now_iso(),
            total_processing_ms=int((datetime.now(timezone.utc) - created).total_seconds() * 1000),
        )
        return {
            "ticket": ticket_to_dict(ticket),
            "position": position,
            "queue_size": len(queue),
            "warnings": vr.warnings,
        }

    # ------------------------------------------------------------------ queue
    @app.get("/tickets/queue", response_model=QueueResponse)
    def get_queue(limit: int = Query(10, ge=1, le=100)) -> QueueResponse:
        with lock:
            # Lấy K+1 để ticket thứ K vẫn có lý do so sánh với ticket ngay sau nó.
            window = queue.top_k(limit + 1) if len(queue) else []
            total = len(queue)
        reasons = explain_order(window)
        items = [
            QueueItem(position=i + 1, reason=reasons[i], **ticket_to_dict(t))
            for i, t in enumerate(window[:limit])
        ]
        return QueueResponse(total=total, limit=limit, items=items)

    @app.post("/tickets/next")
    def next_ticket() -> dict[str, Any]:
        with lock:
            ticket = queue.pop()
            following = queue.peek()
        if ticket is None:
            return {"ticket": None, "message": "Hàng đợi trống.", "queue_size": 0}
        reason = f"Đứng đầu hàng đợi: hạn {ticket.deadline_at.strftime('%H:%M %d/%m')}"
        if following:
            reason += f"; {compare_reason(ticket, following)}"
        rec = store.find_by_ticket(ticket.ticket_id)
        if rec:
            store.update(rec["extraction_id"], status="dispatched", dispatched_at=utc_now_iso())
        return {"ticket": ticket_to_dict(ticket), "reason": reason + ".", "queue_size": len(queue)}

    # ------------------------------------------------------------------ audit + demo
    @app.get("/tickets/records")
    def records(limit: int = Query(50, ge=1, le=500)) -> list[dict[str, Any]]:
        return list(reversed(store.all()))[:limit]

    @app.post("/demo/load-sample")
    def load_sample() -> dict[str, Any]:
        """Nạp 3 ticket mẫu trong đề (đã xác nhận) - không gọi model."""
        data = json.loads((ROOT_DIR / "sample_data" / "confirmed_tickets.json").read_text("utf-8"))
        added, skipped = [], []
        for item in data:
            ticket, vr = build_ticket(item["extraction"], item["ticket_id"], item["received_at"])
            if ticket is None:
                skipped.append({"ticket_id": item["ticket_id"], "errors": vr.errors})
                continue
            with lock:
                try:
                    queue.push(ticket)
                    added.append(ticket.ticket_id)
                except DuplicateTicketError as exc:
                    skipped.append({"ticket_id": ticket.ticket_id, "errors": [str(exc)]})
                    continue
            store.create(
                ticket_id=ticket.ticket_id, received_at=item["received_at"],
                raw_message=item["message"], source="sample", llm_output=item["extraction"],
                status="confirmed", final_ticket=ticket_to_dict(ticket), confirmed_at=utc_now_iso(),
            )
        return {"added": added, "skipped": skipped, "queue_size": len(queue)}

    @app.post("/demo/reset")
    def reset() -> dict[str, Any]:
        with lock:
            queue.clear()
            store.clear()
            counter["n"] = 0
        return {"queue_size": 0}

    return app


app = create_app(Path(os.getenv("AUDIT_LOG_PATH", str(ROOT_DIR / "data" / "audit_log.jsonl"))))
