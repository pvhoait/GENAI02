"""Schema dữ liệu cho Bài 01.

- TicketExtraction: mẫu JSON GenAI PHẢI trả (dùng với with_structured_output).
- Các model *Request/*Response: hợp đồng của API FastAPI.
- Hằng số SLA / thứ hạng mức khẩn cấp: do CODE quyết định, GenAI không đoán.
"""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Danh sách giá trị cho phép + quy tắc nghiệp vụ (nguồn sự thật duy nhất)
# ---------------------------------------------------------------------------
INTENTS: tuple[str, ...] = ("billing", "technical", "account", "other")
SEVERITIES: tuple[str, ...] = ("low", "medium", "high", "critical")

SEVERITY_RANK: dict[str, int] = {"critical": 4, "high": 3, "medium": 2, "low": 1}
SLA_MINUTES: dict[str, int] = {"critical": 30, "high": 120, "medium": 480, "low": 1440}
SUMMARY_MAX_LEN = 200

Intent = Literal["billing", "technical", "account", "other"]
Severity = Literal["low", "medium", "high", "critical"]


# ---------------------------------------------------------------------------
# Mẫu GenAI phải điền
# ---------------------------------------------------------------------------
class TicketExtraction(BaseModel):
    """Thông tin đọc ra từ tin nhắn khách hàng. Chỉ điền, không tính hạn xử lý."""

    ticket_id: str = Field(
        description="Mã ticket hệ thống đã cấp. Chép y nguyên, không tự tạo mã mới."
    )
    intent: Intent = Field(
        description=(
            "billing = thanh toán/hóa đơn/bị trừ tiền; technical = lỗi kỹ thuật; "
            "account = đăng nhập/mật khẩu/tài khoản; other = việc khác hoặc tin nhắn mơ hồ."
        )
    )
    severity: Severity = Field(description="Mức độ khẩn cấp: low, medium, high, critical.")
    product: Optional[str] = Field(
        description="Sản phẩm/tính năng khách nhắc tới (vd: checkout). null nếu khách không nói."
    )
    summary: str = Field(description=f"Tóm tắt tiếng Việt, tối đa {SUMMARY_MAX_LEN} ký tự.")
    needs_human_review: bool = Field(
        description="true nếu tin nhắn mơ hồ, thiếu thông tin hoặc không chắc chắn."
    )


# ---------------------------------------------------------------------------
# API models
# ---------------------------------------------------------------------------
class ExtractRequest(BaseModel):
    message: str = Field(min_length=1, max_length=5000, description="Tin nhắn gốc của khách")
    ticket_id: Optional[str] = Field(
        default=None, description="Mã ticket hệ thống đã cấp. Bỏ trống để hệ thống tự cấp."
    )
    received_at: Optional[str] = Field(
        default=None,
        description="Thời điểm nhận, ISO 8601 có múi giờ (vd 2026-10-21T09:00:00+07:00). "
        "Bỏ trống = thời điểm hiện tại (+07:00).",
    )
    mode: Literal["auto", "mock", "openai"] = Field(
        default="auto", description="auto: dùng OpenAI nếu có API key, ngược lại dùng mock."
    )


class ExtractResponse(BaseModel):
    extraction_id: str
    ticket_id: str
    received_at: str
    source: str
    extraction: Optional[dict[str, Any]]
    errors: list[str]
    warnings: list[str]
    llm_error: Optional[str] = None
    deadline_preview: Optional[str] = None
    latency_ms: int


class ConfirmRequest(BaseModel):
    extraction_id: str
    # Nhận dict "lỏng" để tự kiểm tra và trả lỗi dễ hiểu thay vì 422 khó đọc.
    ticket: dict[str, Any]


class QueueItem(BaseModel):
    position: int
    ticket_id: str
    received_at: str
    deadline_at: str
    severity: str
    severity_rank: int
    intent: str
    product: Optional[str]
    summary: str
    needs_human_review: bool
    reason: str


class QueueResponse(BaseModel):
    total: int
    limit: int
    items: list[QueueItem]
