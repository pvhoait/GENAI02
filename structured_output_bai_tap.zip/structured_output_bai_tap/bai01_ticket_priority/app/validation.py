"""Kiểm tra lại dữ liệu GenAI trả về (hoặc người dùng đã sửa).

JSON đúng khuôn vẫn có thể sai: sai mã ticket, mức khẩn cấp ngoài danh sách,
tóm tắt quá dài, thời gian không có múi giờ... Mọi lỗi được gom lại thành danh sách
để hiển thị cho người dùng sửa. Ticket có lỗi KHÔNG được đưa vào hàng đợi.
"""
from __future__ import annotations

import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from .priority_queue import Ticket, TicketError, compute_deadline
from .schemas import INTENTS, SEVERITIES, SUMMARY_MAX_LEN

EXPECTED_FIELDS = {"ticket_id", "intent", "severity", "product", "summary", "needs_human_review"}


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    normalized: dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.errors


def parse_aware_datetime(value: Any, field_name: str = "received_at") -> datetime:
    """Parse ISO 8601 và BẮT BUỘC có múi giờ."""
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, str) and value.strip():
        try:
            dt = datetime.fromisoformat(value.strip())
        except ValueError as exc:
            raise TicketError(
                f"{field_name} '{value}' không đúng định dạng ISO 8601 "
                "(ví dụ 2026-10-21T09:00:00+07:00)."
            ) from exc
    else:
        raise TicketError(f"{field_name} bị thiếu.")
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise TicketError(f"{field_name} '{value}' thiếu múi giờ (cần dạng ...+07:00).")
    return dt


def _clean_text(value: str) -> str:
    return " ".join(unicodedata.normalize("NFC", value).split())


def validate_extraction(data: Any, expected_ticket_id: str) -> ValidationResult:
    res = ValidationResult()
    if not isinstance(data, dict):
        res.errors.append("Dữ liệu GenAI trả về không phải object JSON.")
        return res

    extra = set(data) - EXPECTED_FIELDS
    if extra:
        res.warnings.append(f"Bỏ qua trường không có trong mẫu: {sorted(extra)}.")
    missing = EXPECTED_FIELDS - set(data)
    if missing:
        res.errors.append(f"Thiếu trường bắt buộc: {sorted(missing)}.")

    # ticket_id phải đúng mã hệ thống đã cấp
    tid = data.get("ticket_id")
    if "ticket_id" in data:
        if not isinstance(tid, str) or tid.strip() != expected_ticket_id:
            res.errors.append(
                f"ticket_id '{tid}' không khớp mã hệ thống đã cấp '{expected_ticket_id}'."
            )
    res.normalized["ticket_id"] = expected_ticket_id

    intent = data.get("intent")
    if "intent" in data:
        if intent not in INTENTS:
            res.errors.append(f"intent '{intent}' không thuộc danh sách cho phép {list(INTENTS)}.")
        res.normalized["intent"] = intent

    severity = data.get("severity")
    if "severity" in data:
        if severity not in SEVERITIES:
            res.errors.append(
                f"severity '{severity}' không thuộc danh sách cho phép {list(SEVERITIES)}."
            )
        res.normalized["severity"] = severity

    product = data.get("product")
    if "product" in data:
        if product is None:
            res.normalized["product"] = None
        elif isinstance(product, str):
            cleaned = _clean_text(product)
            res.normalized["product"] = cleaned or None
        else:
            res.errors.append("product phải là chuỗi hoặc null.")

    summary = data.get("summary")
    if "summary" in data:
        if not isinstance(summary, str) or not summary.strip():
            res.errors.append("summary không được rỗng.")
        else:
            cleaned = _clean_text(summary)
            if len(cleaned) > SUMMARY_MAX_LEN:
                res.errors.append(
                    f"summary dài {len(cleaned)} ký tự, vượt giới hạn {SUMMARY_MAX_LEN}."
                )
            res.normalized["summary"] = cleaned

    review = data.get("needs_human_review")
    if "needs_human_review" in data:
        if not isinstance(review, bool):
            res.errors.append("needs_human_review phải là true/false.")
        res.normalized["needs_human_review"] = review

    # Cảnh báo nhất quán (không chặn): tin nhắn mơ hồ thì intent=other + cần người xem
    if intent == "other" and review is False:
        res.warnings.append("intent=other nhưng needs_human_review=false: nên kiểm tra lại.")
    if review is True:
        res.warnings.append("GenAI đánh dấu ticket này cần người xem lại trước khi xác nhận.")
    return res


def build_ticket(
    data: Any, expected_ticket_id: str, received_at: Any
) -> tuple[Optional[Ticket], ValidationResult]:
    """Kiểm tra toàn bộ và tạo Ticket. Trả (None, result) nếu còn lỗi."""
    res = validate_extraction(data, expected_ticket_id)
    try:
        received = parse_aware_datetime(received_at)
    except TicketError as exc:
        res.errors.append(str(exc))
        received = None

    if res.errors or received is None:
        return None, res

    try:
        compute_deadline(received, res.normalized["severity"])
        ticket = Ticket(
            ticket_id=expected_ticket_id,
            received_at=received,
            severity=res.normalized["severity"],
            intent=res.normalized["intent"],
            product=res.normalized["product"],
            summary=res.normalized["summary"],
            needs_human_review=res.normalized["needs_human_review"],
        )
    except TicketError as exc:
        res.errors.append(f"Không tính được hạn xử lý: {exc}")
        return None, res
    return ticket, res
