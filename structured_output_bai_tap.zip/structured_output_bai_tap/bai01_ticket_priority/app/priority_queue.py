"""Hàng đợi ưu tiên ticket bằng min-heap - phần THUẬT TOÁN, không phụ thuộc GenAI.

Khóa so sánh: (deadline_at, -severity_rank, received_at, ticket_id)
  1. Hạn xử lý sớm hơn đứng trước.
  2. Cùng hạn -> mức khẩn cấp cao hơn đứng trước.
  3. Vẫn bằng -> tin nhắn đến trước đứng trước.
  4. Vẫn bằng -> mã ticket theo alphabet.

Độ phức tạp với n ticket: push O(log n), pop O(log n), top K O(n log K) và KHÔNG xóa phần tử.
"""
from __future__ import annotations

import heapq
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from .schemas import SEVERITIES, SEVERITY_RANK, SLA_MINUTES


class TicketError(ValueError):
    """Dữ liệu ticket không hợp lệ cho thuật toán."""


class DuplicateTicketError(TicketError):
    """Mã ticket đã từng được đưa vào hàng đợi."""


def ensure_aware(dt: datetime, field: str = "received_at") -> datetime:
    if not isinstance(dt, datetime):
        raise TicketError(f"{field} phải là datetime.")
    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        raise TicketError(f"{field} thiếu múi giờ (ví dụ cần +07:00).")
    return dt


def compute_deadline(received_at: datetime, severity: str) -> datetime:
    """Hạn xử lý = thời điểm nhận + SLA theo mức khẩn cấp. Giữ nguyên múi giờ của received_at."""
    ensure_aware(received_at)
    if severity not in SLA_MINUTES:
        raise TicketError(f"severity '{severity}' không thuộc {list(SEVERITIES)}.")
    return received_at + timedelta(minutes=SLA_MINUTES[severity])


@dataclass(frozen=True)
class Ticket:
    ticket_id: str
    received_at: datetime
    severity: str
    intent: str = "other"
    product: Optional[str] = None
    summary: str = ""
    needs_human_review: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.ticket_id, str) or not self.ticket_id.strip():
            raise TicketError("ticket_id không được rỗng.")
        ensure_aware(self.received_at)
        if self.severity not in SEVERITY_RANK:
            raise TicketError(f"severity '{self.severity}' không thuộc {list(SEVERITIES)}.")

    @property
    def severity_rank(self) -> int:
        return SEVERITY_RANK[self.severity]

    @property
    def deadline_at(self) -> datetime:
        return compute_deadline(self.received_at, self.severity)

    def sort_key(self) -> tuple:
        # Đưa về UTC để so sánh đúng khi các ticket có múi giờ khác nhau.
        return (
            self.deadline_at.astimezone(timezone.utc),
            -self.severity_rank,
            self.received_at.astimezone(timezone.utc),
            self.ticket_id,
        )


class TicketQueue:
    """Min-heap các ticket. Mã ticket là duy nhất trong suốt vòng đời hàng đợi."""

    def __init__(self) -> None:
        # Phần tử heap: (sort_key, ticket). sort_key chứa ticket_id duy nhất
        # nên tuple không bao giờ phải so sánh tới đối tượng Ticket.
        self._heap: list[tuple[tuple, Ticket]] = []
        self._seen_ids: set[str] = set()

    def __len__(self) -> int:
        return len(self._heap)

    def has_seen(self, ticket_id: str) -> bool:
        return ticket_id in self._seen_ids

    def push(self, ticket: Ticket) -> None:
        if ticket.ticket_id in self._seen_ids:
            raise DuplicateTicketError(
                f"Mã ticket '{ticket.ticket_id}' đã tồn tại. Hệ thống từ chối mã trùng."
            )
        heapq.heappush(self._heap, (ticket.sort_key(), ticket))
        self._seen_ids.add(ticket.ticket_id)

    def pop(self) -> Optional[Ticket]:
        """Lấy và xóa ticket đứng đầu. Trả None nếu hàng đợi rỗng."""
        if not self._heap:
            return None
        return heapq.heappop(self._heap)[1]

    def peek(self) -> Optional[Ticket]:
        return self._heap[0][1] if self._heap else None

    def top_k(self, k: int) -> list[Ticket]:
        """Xem K ticket đầu theo đúng thứ tự, KHÔNG thay đổi heap."""
        if not isinstance(k, int) or k < 1:
            raise TicketError("limit phải là số nguyên >= 1.")
        return [t for _, t in heapq.nsmallest(k, self._heap)]

    def snapshot(self) -> list[Ticket]:
        return [t for _, t in sorted(self._heap)]

    def clear(self) -> None:
        self._heap.clear()
        self._seen_ids.clear()


# ---------------------------------------------------------------------------
# Giải thích thứ tự (cho người dùng đọc)
# ---------------------------------------------------------------------------
def _fmt(dt: datetime) -> str:
    return dt.strftime("%H:%M %d/%m")


def _base_reason(t: Ticket) -> str:
    sla = SLA_MINUTES[t.severity]
    sla_txt = f"{sla} phút" if sla < 60 else f"{sla // 60} giờ"
    return f"Hạn {_fmt(t.deadline_at)} = nhận {_fmt(t.received_at)} + SLA {t.severity} ({sla_txt})"


def compare_reason(a: Ticket, b: Ticket) -> str:
    """Giải thích vì sao a đứng trước b dựa trên thành phần đầu tiên khác nhau của khóa."""
    ka, kb = a.sort_key(), b.sort_key()
    if ka[0] != kb[0]:
        return f"hạn sớm hơn {b.ticket_id} ({_fmt(b.deadline_at)})"
    if ka[1] != kb[1]:
        return f"cùng hạn với {b.ticket_id} nhưng mức {a.severity} cao hơn {b.severity}"
    if ka[2] != kb[2]:
        return f"cùng hạn và mức với {b.ticket_id}, nhưng nhận trước ({_fmt(b.received_at)})"
    return f"trùng hạn, mức và giờ nhận với {b.ticket_id}; mã đứng trước theo alphabet"


def explain_order(ordered: list[Ticket]) -> list[str]:
    """Lý do xếp hạng cho từng ticket trong danh sách đã sắp xếp."""
    reasons = []
    for i, t in enumerate(ordered):
        base = _base_reason(t)
        if i + 1 < len(ordered):
            reasons.append(f"{base}; {compare_reason(t, ordered[i + 1])}.")
        elif i == 0:
            reasons.append(f"{base}; ticket duy nhất trong danh sách.")
        else:
            reasons.append(f"{base}; xếp sau các ticket phía trên.")
    return reasons
