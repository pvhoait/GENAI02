# Bài 01 - Khách hàng nào cần được hỗ trợ trước?

Trang web nhận tin nhắn khách hàng, dùng GenAI (OpenAI qua LangChain) đọc ra thông tin theo mẫu JSON cố định, cho nhân viên xem và sửa, rồi code xếp ticket vào **min-heap** theo hạn xử lý (SLA).

## Cấu trúc

```
bai01_ticket_priority/
├── app/
│   ├── schemas.py          # Mẫu JSON GenAI phải trả (Pydantic) + hằng số SLA
│   ├── extractor.py        # GenAI: LangChain with_structured_output + MockExtractor
│   ├── validation.py       # Code kiểm tra lại dữ liệu GenAI / người dùng sửa
│   ├── priority_queue.py   # THUẬT TOÁN: min-heap, tính hạn, giải thích thứ tự
│   ├── storage.py          # Lưu vết vào data/audit_log.jsonl
│   ├── main.py             # FastAPI
│   └── static/index.html   # Giao diện web
├── tests/
│   ├── test_priority_queue.py  # Test thuật toán, không phụ thuộc GenAI
│   └── test_api.py             # Test validation + API (chạy mock)
├── sample_data/            # Dữ liệu mẫu chạy thử không tốn tiền
└── docs/ticket_extraction.schema.json   # Mẫu dữ liệu GenAI phải trả
```

## Cài đặt và chạy

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # điền OPENAI_API_KEY (không bắt buộc)
uvicorn app.main:app --reload
```

Mở http://localhost:8000. Tài liệu API tự sinh: http://localhost:8000/docs.

Không có `OPENAI_API_KEY` thì app tự dùng **MockExtractor** (đọc theo từ khóa), nên vẫn chạy được toàn bộ luồng mà không tốn tiền. Có thể ép chế độ mock bằng `LLM_MODE=mock` hoặc chọn "Mock (miễn phí)" trên giao diện.

Chạy test:

```bash
pytest -q
```

## Luồng sử dụng

1. Bấm **Nạp 3 ticket mẫu** để có T01, T02, T03 như trong đề. Hàng đợi hiện T02 → T01 → T03.
2. Chọn chip **T04 high lúc 07:00**, bấm **Đọc tin nhắn**, kiểm tra kết quả, bấm **Xác nhận**. T04 lên đầu vì hạn 09:00.
3. **Xem top K** không lấy ticket ra; **Lấy ticket kế tiếp** mới lấy ra.
4. Các chip **Thiếu múi giờ**, **Mã trùng T01**, **Tin nhắn mơ hồ**, **Tin nhắn cài lệnh** để thử ca lỗi. Có thể chọn mức khẩn cấp sai hoặc sửa mã ticket để thấy app chặn.

## API

| Method | Đường dẫn | Việc làm |
|---|---|---|
| POST | `/tickets/extract` | Nhận `message`, `ticket_id?`, `received_at?`, `mode`. GenAI điền mẫu, code kiểm tra, trả JSON + lỗi + cảnh báo. Chưa đưa vào hàng đợi. |
| POST | `/tickets/confirm` | Nhận `extraction_id` + bản người dùng đã sửa. Kiểm tra lại, tính hạn, đưa vào heap. Lỗi → 422, mã trùng → 409. |
| GET | `/tickets/queue?limit=K` | Top K kèm lý do xếp hạng. Không xóa ticket. |
| POST | `/tickets/next` | Lấy ticket đầu hàng đợi, kèm lý do. Hàng đợi rỗng → `ticket: null`. |
| GET | `/tickets/records` | Lịch sử: nội dung gốc, JSON GenAI, bản sửa, kết quả, thời gian. |
| GET | `/schema/ticket-extraction` | JSON Schema GenAI phải trả. |
| POST | `/demo/load-sample`, `/demo/reset` | Nạp dữ liệu mẫu / xóa dữ liệu. |

Ví dụ:

```bash
curl -X POST localhost:8000/tickets/extract -H "Content-Type: application/json" \
  -d '{"ticket_id":"T04","received_at":"2026-10-21T07:00:00+07:00","message":"Tôi bị trừ tiền hai lần","mode":"mock"}'
```

## Mẫu dữ liệu GenAI phải trả

```json
{
  "ticket_id": "T01",
  "intent": "billing",
  "severity": "high",
  "product": "checkout",
  "summary": "Khách bị tính tiền hai lần",
  "needs_human_review": false
}
```

- `intent` ∈ `billing | technical | account | other`; `severity` ∈ `low | medium | high | critical` (khai báo bằng `Literal`, nên JSON Schema gửi cho OpenAI có `enum`).
- `product` có thể `null`; `summary` ≤ 200 ký tự; tin nhắn mơ hồ → `intent=other`, `needs_human_review=true`.
- Gọi bằng `llm.with_structured_output(TicketExtraction, method="json_schema", strict=True, include_raw=True)`. `include_raw=True` để khi model trả sai khuôn, app vẫn hiện bản thô cho người dùng sửa thay vì văng lỗi.

## Quy tắc xếp hàng

Hạn xử lý do **code** tính: critical 30 phút, high 2 giờ, medium 8 giờ, low 24 giờ kể từ `received_at`.

Khóa của min-heap: `(deadline_at, -severity_rank, received_at, ticket_id)`, với critical=4, high=3, medium=2, low=1. Thời gian được đưa về UTC trước khi so sánh nên các ticket khác múi giờ vẫn đúng thứ tự.

| Thao tác | Độ phức tạp |
|---|---|
| Thêm ticket (`heappush`) | O(log n) |
| Lấy ticket kế tiếp (`heappop`) | O(log n) |
| Xem top K (`heapq.nsmallest`, không sửa heap) | O(n log K) |

Mã ticket bị trùng thì **từ chối** (kể cả khi ticket cũ đã được lấy ra xử lý), vì mã do hệ thống cấp và phải duy nhất.

Một điểm đáng chú ý: SLA cố định theo mức, nên "cùng hạn + cùng mức" kéo theo "cùng giờ nhận". Vì vậy trong thực tế tiêu chí `received_at` không bao giờ là tiêu chí phân định; tiêu chí cuối cùng thực sự quyết định là `ticket_id`. Vẫn giữ `received_at` trong khóa để đúng đặc tả và để an toàn nếu sau này SLA thay đổi theo khách hàng.

## Kiểm tra dữ liệu

JSON đúng khuôn vẫn có thể sai, nên `validation.py` kiểm tra lại cả kết quả GenAI lẫn bản người dùng sửa:

- `ticket_id` phải đúng mã hệ thống đã cấp; mã đã tồn tại → 409.
- `intent`, `severity` phải thuộc danh sách cho phép.
- `summary` không rỗng, ≤ 200 ký tự; `needs_human_review` phải là boolean.
- `received_at` phải là ISO 8601 **có múi giờ**.
- Không tính được hạn xử lý → không đưa vào hàng đợi.
- Cảnh báo (không chặn): GenAI đánh dấu cần người xem lại; `intent=other` nhưng không yêu cầu xem lại.

## Lưu vết

Mỗi lượt xử lý ghi vào `data/audit_log.jsonl` (mỗi dòng là một phiên bản của record): nội dung gốc, nguồn (`openai`/`mock`), JSON GenAI trả, lỗi, bản người dùng sửa, danh sách trường đã sửa, ticket cuối, thời gian đọc (ms), thời điểm xác nhận và lấy ra.

Hàng đợi nằm trong bộ nhớ, khởi động lại server sẽ mất. Muốn bền vững thì lưu ticket vào SQLite/Postgres và dựng lại heap khi khởi động (O(n) với `heapify`).

## Test

39 test, gồm:

- **Ca thường:** dữ liệu mẫu ra T02 → T01 → T03; top 2 là T02, T01; xem top K không làm đổi lần lấy kế tiếp; thêm T04 thì T04 lên đầu; đổi thứ tự thêm vẫn ra cùng kết quả.
- **Ca sát giới hạn:** cùng hạn thì critical đứng trước high; trùng hết thì phân định bằng mã ticket; so sánh đúng khi khác múi giờ; hàng đợi rỗng; K lớn hơn số ticket.
- **Dữ liệu sai:** mã trùng (kể cả sau khi đã lấy ra), thời gian thiếu múi giờ, severity/intent ngoài danh sách, mã ticket sai, summary quá dài, xác nhận hai lần, `limit=0`.
- **Hiệu năng:** 50.000 ticket thêm và lấy ra đúng thứ tự trong vài giây.

## GenAI làm gì, code làm gì?

**GenAI** chỉ làm phần đọc hiểu ngôn ngữ: đọc lời khách viết, phân loại yêu cầu (`intent`), ước lượng mức khẩn cấp (`severity`), nhận ra sản phẩm được nhắc tới, viết tóm tắt và tự báo khi tin nhắn mơ hồ. Kết quả bị khóa vào một schema cố định với danh sách giá trị cho phép.

**Code** làm mọi phần cần đúng tuyệt đối và kiểm chứng được: cấp mã ticket và giờ nhận, kiểm tra lại từng trường GenAI trả, tính hạn xử lý theo SLA, xếp hàng bằng min-heap với khóa phân định rõ ràng, giải thích vì sao ticket này đứng trước ticket kia, chặn mã trùng và lưu vết.

**Con người** đứng giữa hai bước: xem GenAI đọc ra gì, sửa nếu sai, rồi mới xác nhận. Nhờ vậy một lỗi đọc của model không tự động làm sai thứ tự hàng đợi, và mỗi vị trí trong hàng đợi đều truy ngược được về quy tắc cụ thể.

## Làm thêm (gợi ý)

Phân công theo kỹ năng: mỗi nhân viên có `skills` và `max_load`. Khi lấy ticket, duyệt heap theo thứ tự ưu tiên và gán cho nhân viên phù hợp còn chỗ (greedy); ticket không ai nhận được thì đưa vào danh sách "chưa có người phù hợp".
