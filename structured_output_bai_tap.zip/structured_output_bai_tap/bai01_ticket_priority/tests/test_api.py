"""Test validation + API. Chạy với MockExtractor nên không tốn tiền gọi model."""
import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.validation import validate_extraction

GOOD = {
    "ticket_id": "T01",
    "intent": "billing",
    "severity": "high",
    "product": "checkout",
    "summary": "Khách bị tính tiền hai lần",
    "needs_human_review": False,
}


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    return TestClient(create_app(tmp_path / "audit.jsonl"))


def extract(client, ticket_id, received_at, message="Tôi bị tính tiền hai lần ở checkout"):
    return client.post(
        "/tickets/extract",
        json={"ticket_id": ticket_id, "received_at": received_at, "message": message, "mode": "mock"},
    )


def add(client, ticket_id, received_at, severity):
    r = extract(client, ticket_id, received_at)
    assert r.status_code == 200, r.text
    body = r.json()
    edited = {**body["extraction"], "severity": severity}  # người dùng chỉnh mức khẩn cấp
    c = client.post("/tickets/confirm", json={"extraction_id": body["extraction_id"], "ticket": edited})
    assert c.status_code == 200, c.text
    return c.json()


# ------------------------------------------------------------- validation
def test_validation_accepts_good_data():
    assert validate_extraction(GOOD, "T01").ok


@pytest.mark.parametrize(
    "patch, expected",
    [
        ({"severity": "urgent"}, "severity"),
        ({"intent": "refund"}, "intent"),
        ({"ticket_id": "T99"}, "không khớp"),
        ({"summary": "x" * 201}, "vượt giới hạn"),
        ({"summary": "   "}, "summary"),
        ({"needs_human_review": "no"}, "needs_human_review"),
    ],
)
def test_validation_rejects_bad_data(patch, expected):
    res = validate_extraction({**GOOD, **patch}, "T01")
    assert not res.ok
    assert any(expected in e for e in res.errors)


def test_validation_missing_field():
    data = dict(GOOD)
    del data["severity"]
    assert any("Thiếu trường" in e for e in validate_extraction(data, "T01").errors)


# ------------------------------------------------------------------ API
def test_end_to_end_sample_order(client):
    add(client, "T01", "2026-10-21T09:00:00+07:00", "high")
    add(client, "T02", "2026-10-21T09:20:00+07:00", "critical")
    add(client, "T03", "2026-10-21T08:30:00+07:00", "medium")

    q = client.get("/tickets/queue", params={"limit": 2}).json()
    assert [i["ticket_id"] for i in q["items"]] == ["T02", "T01"]
    assert q["total"] == 3
    assert q["items"][0]["deadline_at"] == "2026-10-21T09:50:00+07:00"
    assert q["items"][0]["reason"]

    # xem top K không xóa
    assert client.get("/tickets/queue", params={"limit": 2}).json()["total"] == 3

    order = [client.post("/tickets/next").json()["ticket"]["ticket_id"] for _ in range(3)]
    assert order == ["T02", "T01", "T03"]
    assert client.post("/tickets/next").json()["ticket"] is None


def test_T04_jumps_to_front(client):
    client.post("/demo/load-sample")
    add(client, "T04", "2026-10-21T07:00:00+07:00", "high")
    items = client.get("/tickets/queue", params={"limit": 4}).json()["items"]
    assert [i["ticket_id"] for i in items] == ["T04", "T02", "T01", "T03"]


def test_duplicate_ticket_id_rejected(client):
    add(client, "T01", "2026-10-21T09:00:00+07:00", "high")
    r = extract(client, "T01", "2026-10-21T10:00:00+07:00")
    assert r.status_code == 409


def test_confirm_twice_rejected(client):
    body = extract(client, "T01", "2026-10-21T09:00:00+07:00").json()
    payload = {"extraction_id": body["extraction_id"], "ticket": body["extraction"]}
    assert client.post("/tickets/confirm", json=payload).status_code == 200
    assert client.post("/tickets/confirm", json=payload).status_code == 409


def test_naive_received_at_rejected(client):
    r = extract(client, "T07", "2026-10-21T09:15:00")
    assert r.status_code == 422
    assert "múi giờ" in r.json()["detail"]["errors"][0]


def test_invalid_severity_not_queued(client):
    body = extract(client, "T05", "2026-10-21T09:00:00+07:00").json()
    bad = {**body["extraction"], "severity": "urgent"}
    r = client.post("/tickets/confirm", json={"extraction_id": body["extraction_id"], "ticket": bad})
    assert r.status_code == 422
    assert any("severity" in e for e in r.json()["detail"]["errors"])
    assert client.get("/tickets/queue").json()["total"] == 0


def test_wrong_ticket_id_from_user_not_queued(client):
    body = extract(client, "T05", "2026-10-21T09:00:00+07:00").json()
    bad = {**body["extraction"], "ticket_id": "T999"}
    r = client.post("/tickets/confirm", json={"extraction_id": body["extraction_id"], "ticket": bad})
    assert r.status_code == 422


def test_ambiguous_message_flagged_for_review(client):
    body = extract(client, "T06", "2026-10-21T09:10:00+07:00", "ê cái đó sao rồi").json()
    assert body["extraction"]["intent"] == "other"
    assert body["extraction"]["needs_human_review"] is True


def test_audit_record_saved(client):
    add(client, "T01", "2026-10-21T09:00:00+07:00", "critical")
    rec = client.get("/tickets/records").json()[0]
    assert rec["raw_message"] and rec["llm_output"] and rec["user_edited"] and rec["final_ticket"]
    assert rec["user_changed_fields"] == ["severity"]  # mock đọc high, người dùng sửa critical
    assert "extract_latency_ms" in rec and "confirmed_at" in rec


def test_invalid_limit(client):
    assert client.get("/tickets/queue", params={"limit": 0}).status_code == 422
