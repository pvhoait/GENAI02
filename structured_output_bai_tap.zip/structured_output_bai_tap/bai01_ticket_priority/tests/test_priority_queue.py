"""Test phần thuật toán - không gọi GenAI, không cần mạng."""
from datetime import datetime, timedelta, timezone

import pytest

from app.priority_queue import (
    DuplicateTicketError,
    Ticket,
    TicketError,
    TicketQueue,
    compute_deadline,
    explain_order,
)

VN = timezone(timedelta(hours=7))


def dt(hh: int, mm: int, tz=VN) -> datetime:
    return datetime(2026, 10, 21, hh, mm, tzinfo=tz)


@pytest.fixture
def sample_queue() -> TicketQueue:
    q = TicketQueue()
    q.push(Ticket("T01", dt(9, 0), "high"))
    q.push(Ticket("T02", dt(9, 20), "critical"))
    q.push(Ticket("T03", dt(8, 30), "medium"))
    return q


# ----------------------------------------------------------------- ca thường
def test_deadlines_match_sla():
    assert compute_deadline(dt(9, 0), "high") == dt(11, 0)
    assert compute_deadline(dt(9, 20), "critical") == dt(9, 50)
    assert compute_deadline(dt(8, 30), "medium") == dt(16, 30)
    assert compute_deadline(dt(9, 0), "low") == dt(9, 0) + timedelta(hours=24)


def test_sample_order_is_T02_T01_T03(sample_queue):
    assert [sample_queue.pop().ticket_id for _ in range(3)] == ["T02", "T01", "T03"]
    assert sample_queue.pop() is None


def test_top_k_does_not_remove(sample_queue):
    assert [t.ticket_id for t in sample_queue.top_k(2)] == ["T02", "T01"]
    assert [t.ticket_id for t in sample_queue.top_k(2)] == ["T02", "T01"]
    assert len(sample_queue) == 3
    assert sample_queue.pop().ticket_id == "T02"  # xem top K không làm đổi lần lấy kế tiếp


def test_top_k_larger_than_queue(sample_queue):
    assert [t.ticket_id for t in sample_queue.top_k(10)] == ["T02", "T01", "T03"]


def test_new_high_ticket_at_0700_goes_first(sample_queue):
    sample_queue.push(Ticket("T04", dt(7, 0), "high"))  # hạn 09:00
    assert sample_queue.top_k(1)[0].ticket_id == "T04"


def test_order_independent_of_insert_order():
    tickets = [
        Ticket("T03", dt(8, 30), "medium"),
        Ticket("T01", dt(9, 0), "high"),
        Ticket("T02", dt(9, 20), "critical"),
    ]
    q = TicketQueue()
    for t in tickets:
        q.push(t)
    assert [t.ticket_id for t in q.top_k(3)] == ["T02", "T01", "T03"]


# ----------------------------------------------------------- ca sát giới hạn
def test_same_deadline_higher_severity_first():
    q = TicketQueue()
    # Cả hai hạn 11:00: high nhận 09:00 (+2h), critical nhận 10:30 (+30')
    q.push(Ticket("H", dt(9, 0), "high"))
    q.push(Ticket("C", dt(10, 30), "critical"))
    assert [t.ticket_id for t in q.top_k(2)] == ["C", "H"]


def test_different_timezones_compared_by_real_instant():
    # 01:59 UTC = 08:59 +07:00 -> nhận trước A 1 phút nên hạn sớm hơn.
    # Lưu ý: SLA cố định theo mức, nên "cùng hạn + cùng mức" kéo theo "cùng giờ nhận";
    # khi đó mã ticket là tiêu chí phân định cuối cùng (test bên dưới).
    q = TicketQueue()
    q.push(Ticket("A", dt(9, 0), "high"))
    q.push(Ticket("B", datetime(2026, 10, 21, 1, 59, tzinfo=timezone.utc), "high"))
    assert [t.ticket_id for t in q.top_k(2)] == ["B", "A"]


def test_full_tie_broken_by_ticket_id():
    q = TicketQueue()
    q.push(Ticket("T10", dt(9, 0), "high"))
    q.push(Ticket("T09", dt(9, 0), "high"))
    q.push(Ticket("T11", datetime(2026, 10, 21, 2, 0, tzinfo=timezone.utc), "high"))  # cùng thời điểm
    assert [t.ticket_id for t in q.top_k(3)] == ["T09", "T10", "T11"]


def test_explain_mentions_tie_breakers():
    a = Ticket("H", dt(9, 0), "high")
    c = Ticket("C", dt(10, 30), "critical")
    reasons = explain_order([c, a])
    assert "mức critical cao hơn high" in reasons[0]


def test_empty_queue():
    q = TicketQueue()
    assert q.pop() is None
    assert q.top_k(5) == []


# ------------------------------------------------------------- dữ liệu sai
def test_duplicate_id_rejected_even_after_pop(sample_queue):
    with pytest.raises(DuplicateTicketError):
        sample_queue.push(Ticket("T01", dt(10, 0), "low"))
    sample_queue.pop()  # T02 rời hàng đợi
    with pytest.raises(DuplicateTicketError):
        sample_queue.push(Ticket("T02", dt(10, 0), "low"))


def test_naive_datetime_rejected():
    with pytest.raises(TicketError, match="múi giờ"):
        Ticket("T99", datetime(2026, 10, 21, 9, 0), "high")


@pytest.mark.parametrize("bad", ["urgent", "HIGH", "", None])
def test_invalid_severity_rejected(bad):
    with pytest.raises(TicketError):
        Ticket("T99", dt(9, 0), bad)


@pytest.mark.parametrize("k", [0, -1])
def test_invalid_k_rejected(sample_queue, k):
    with pytest.raises(TicketError):
        sample_queue.top_k(k)


def test_empty_ticket_id_rejected():
    with pytest.raises(TicketError):
        Ticket("  ", dt(9, 0), "low")


# ----------------------------------------------------------------- hiệu năng
def test_many_tickets_fast_and_sorted():
    import random
    import time

    rnd = random.Random(42)
    sev = ["low", "medium", "high", "critical"]
    q = TicketQueue()
    start = time.perf_counter()
    for i in range(50_000):
        q.push(Ticket(f"T{i:06d}", dt(0, 0) + timedelta(minutes=rnd.randint(0, 1440)), rnd.choice(sev)))
    keys = [q.pop().sort_key() for _ in range(len(q))]
    assert keys == sorted(keys)
    assert time.perf_counter() - start < 5
