# Bộ bài tập Structured Output × Thuật toán

Bốn bài tập độc lập, cùng một cách làm: **GenAI đọc và điền dữ liệu vào mẫu JSON, con người kiểm tra và sửa, code kiểm tra lại rồi tính kết quả.**

| Thư mục | Bài | Thuật toán chính | Test |
|---|---|---|---|
| `bai01_ticket_priority/` | Khách hàng nào cần được hỗ trợ trước? | Hàng đợi ưu tiên (min-heap) | 39 |
| `bai02_dock_scheduling/` | Xe giao hàng nên vào cửa kho lúc mấy giờ? | Gộp khoảng thời gian, tìm khe trống | 40 |
| `bai03_duplicate_invoice/` | Hóa đơn này đã được gửi trước đó chưa? | Tra cứu bằng khóa (hash map) | 41 |
| `bai04_task_ordering/` | Việc nào phải làm trước? | Topological sort (Kahn + heap), tìm vòng | 32 |

## Công nghệ

Python 3.10+ · FastAPI · LangChain (`langchain-openai`, `with_structured_output` dạng `json_schema` strict) · Pydantic v2 · pytest. Giao diện mỗi bài là một file HTML thuần, không cần build.

## Chạy một bài

Mỗi bài có `requirements.txt`, `.env.example` và `README.md` riêng.

```bash
cd bai01_ticket_priority           # hoặc bai02_..., bai03_..., bai04_...
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # điền OPENAI_API_KEY nếu muốn dùng OpenAI
uvicorn app.main:app --reload      # mở http://localhost:8000
pytest -q                          # chạy test
```

Muốn chạy nhiều bài cùng lúc thì đổi cổng, ví dụ `uvicorn app.main:app --port 8002`.

Không có `OPENAI_API_KEY` thì mỗi bài tự dùng bộ đọc mock miễn phí, nên vẫn chạy được toàn bộ luồng và toàn bộ test mà không tốn tiền gọi model. Tài liệu API tự sinh có tại `/docs`.

## Cấu trúc chung của mỗi bài

```
app/
  schemas.py       Mẫu JSON GenAI phải trả + hằng số nghiệp vụ
  extractor.py     Phần GenAI: OpenAI qua LangChain, kèm MockExtractor
  validation.py    Kiểm tra lại dữ liệu GenAI / người dùng sửa (Bài 04 gộp vào topo.py)
  <thuật toán>.py  priority_queue.py / scheduler.py / dedup.py / topo.py
  storage.py       Lưu vết vào data/audit_log.jsonl
  main.py          FastAPI
  static/index.html
tests/             Test thuật toán (không cần GenAI) + test API (mock)
sample_data/       Dữ liệu mẫu trong đề và các ca lỗi
docs/              JSON Schema GenAI phải trả + ảnh chụp màn hình
```

## Đối chiếu yêu cầu chung

| Yêu cầu | Cách đáp ứng |
|---|---|
| Trang web xem, sửa, xác nhận | Mỗi bài có màn hình nhập liệu, form sửa kết quả GenAI và phần kết quả kèm lý do. |
| GenAI trả đúng schema | Pydantic + `with_structured_output(method="json_schema", strict=True)`. Lựa chọn khai báo bằng `Literal` (enum), trường chưa biết là `null`. |
| Code kiểm tra lại | Mỗi bài có lớp kiểm tra riêng: ngày giờ, múi giờ, ID, số tiền âm, dữ liệu trùng. Dữ liệu sai trả lỗi rõ ràng và không đi vào thuật toán. |
| Lưu vết | Nội dung gốc, JSON GenAI, bản người dùng sửa, các trường đã sửa, kết quả cuối, thời gian xử lý. API key chỉ nằm ở backend (`.env`). |
| Chạy thử không tốn tiền | MockExtractor + dữ liệu mẫu. Test thuật toán không phụ thuộc GenAI. |
| Dữ liệu giả | Toàn bộ dữ liệu mẫu là dữ liệu học tập. |
| Ít nhất 3 test | Mỗi bài có từ 32 đến 41 test, chia ca thường, ca sát giới hạn, dữ liệu sai và hiệu năng. |
| Ảnh luồng chính | `docs/screenshot*.png` trong từng bài. |
