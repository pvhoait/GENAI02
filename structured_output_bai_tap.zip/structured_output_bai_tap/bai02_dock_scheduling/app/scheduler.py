"""Thuật toán Bài 02 - gộp khoảng thời gian và tìm giờ trống. Không phụ thuộc GenAI.

Quy ước khoảng nửa mở [start, end): xe rời cửa lúc 10:00 thì xe sau vào lúc 10:00 là hợp lệ.

Với n booking của một cửa: sắp xếp O(n log n) + gộp O(n) + quét tìm khe O(n).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Iterable, Optional

from .schemas import CLOSE_TIME, DOCK_TYPES, OPEN_TIME, WAREHOUSE_TZ


class ScheduleError(ValueError):
    """Dữ liệu lịch không hợp lệ."""


def ensure_aware(dt: datetime, field: str) -> datetime:
    if not isinstance(dt, datetime):
        raise ScheduleError(f"{field} phải là datetime.")
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ScheduleError(f"{field} thiếu múi giờ (cần dạng ...+07:00).")
    return dt


@dataclass(frozen=True, order=True)
class Interval:
    start: datetime
    end: datetime

    def __post_init__(self) -> None:
        ensure_aware(self.start, "start")
        ensure_aware(self.end, "end")
        if self.end <= self.start:
            raise ScheduleError(
                f"Giờ kết thúc {self.end:%H:%M} phải sau giờ bắt đầu {self.start:%H:%M}."
            )

    def overlaps(self, other: "Interval") -> bool:
        # [a, b) và [c, d) giao nhau khi a < d và c < b; chạm mép (b == c) không tính.
        return self.start < other.end and other.start < self.end


@dataclass(frozen=True)
class Booking:
    booking_id: str
    dock_id: str
    start: datetime
    end: datetime
    request_id: Optional[str] = None
    carrier: Optional[str] = None

    @property
    def interval(self) -> Interval:
        return Interval(self.start, self.end)


@dataclass(frozen=True)
class Dock:
    dock_id: str
    dock_type: str

    def __post_init__(self) -> None:
        if self.dock_type not in DOCK_TYPES:
            raise ScheduleError(f"dock_type '{self.dock_type}' không thuộc {list(DOCK_TYPES)}.")


@dataclass(frozen=True)
class Slot:
    dock_id: str
    start: datetime
    end: datetime


def merge_intervals(intervals: Iterable[Interval]) -> list[Interval]:
    """Sắp xếp theo giờ bắt đầu rồi gộp các khoảng giao nhau HOẶC nối sát nhau."""
    ordered = sorted(intervals, key=lambda iv: (iv.start, iv.end))
    merged: list[Interval] = []
    for iv in ordered:
        if merged and iv.start <= merged[-1].end:  # <= : nối sát cũng gộp
            last = merged[-1]
            if iv.end > last.end:
                merged[-1] = Interval(last.start, iv.end)
        else:
            merged.append(iv)
    return merged


def working_window(day: date, tz=WAREHOUSE_TZ) -> Interval:
    return Interval(datetime.combine(day, OPEN_TIME, tz), datetime.combine(day, CLOSE_TIME, tz))


def busy_intervals(
    bookings: Iterable[Booking], day: date, buffer_minutes: int = 0
) -> list[Interval]:
    """Khoảng bận đã gộp của một cửa trong ngày. buffer = thời gian dọn cửa thêm 2 phía."""
    window = working_window(day)
    buf = timedelta(minutes=buffer_minutes)
    expanded = []
    for b in bookings:
        iv = Interval(b.start - buf, b.end + buf)
        if iv.overlaps(window):
            expanded.append(iv)
    return merge_intervals(expanded)


def first_gap(
    busy: list[Interval], earliest: datetime, duration: timedelta, window: Interval
) -> Optional[datetime]:
    """Giờ bắt đầu sớm nhất >= earliest có đủ `duration` trống trong `window`. busy đã gộp & sắp xếp."""
    t = max(earliest, window.start)
    for iv in busy:
        if iv.end <= t:
            continue  # khoảng bận đã qua
        if t + duration <= iv.start:
            break  # khe trước khoảng bận này đủ dài
        t = max(t, iv.end)  # nhảy qua khoảng bận
    return t if t + duration <= window.end else None


def find_slot(
    docks: Iterable[Dock],
    bookings: Iterable[Booking],
    earliest_start: datetime,
    duration_minutes: int,
    dock_type: str,
    buffer_minutes: int = 0,
) -> Optional[Slot]:
    """Chọn khe sớm nhất; nếu bằng giờ thì chọn mã cửa theo alphabet. None = no_slot."""
    ensure_aware(earliest_start, "earliest_start")
    if not isinstance(duration_minutes, int) or isinstance(duration_minutes, bool) or duration_minutes <= 0:
        raise ScheduleError("duration_minutes phải là số nguyên > 0.")
    if dock_type not in DOCK_TYPES:
        raise ScheduleError(f"dock_type '{dock_type}' không thuộc {list(DOCK_TYPES)}.")

    local = earliest_start.astimezone(WAREHOUSE_TZ)
    day = local.date()  # chỉ tìm trong ngày này, không tự chuyển sang hôm sau
    window = working_window(day)
    duration = timedelta(minutes=duration_minutes)

    by_dock: dict[str, list[Booking]] = {}
    for b in bookings:
        by_dock.setdefault(b.dock_id, []).append(b)

    best: Optional[Slot] = None
    for dock in sorted(docks, key=lambda d: d.dock_id):
        if dock.dock_type != dock_type:
            continue
        busy = busy_intervals(by_dock.get(dock.dock_id, []), day, buffer_minutes)
        start = first_gap(busy, local, duration, window)
        if start is None:
            continue
        # Duyệt cửa theo alphabet và chỉ thay khi sớm hơn hẳn => cùng giờ thì cửa đứng trước thắng.
        if best is None or start < best.start:
            best = Slot(dock.dock_id, start, start + duration)
    return best


def conflicts(
    bookings: Iterable[Booking], dock_id: str, candidate: Interval, buffer_minutes: int = 0
) -> list[Booking]:
    """Các booking của cửa `dock_id` va chạm với khoảng ứng viên (tính cả thời gian dọn cửa)."""
    buf = timedelta(minutes=buffer_minutes)
    out = []
    for b in bookings:
        if b.dock_id != dock_id:
            continue
        if Interval(b.start - buf, b.end + buf).overlaps(candidate):
            out.append(b)
    return out


def within_working_hours(iv: Interval) -> bool:
    local_start = iv.start.astimezone(WAREHOUSE_TZ)
    window = working_window(local_start.date())
    return window.start <= iv.start and iv.end <= window.end
