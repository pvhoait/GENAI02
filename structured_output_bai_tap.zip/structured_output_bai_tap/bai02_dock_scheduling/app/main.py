"""FastAPI backend - Bài 02: Xe giao hàng nên vào cửa kho lúc mấy giờ?

Luồng: POST /requests/extract  (GenAI đọc email -> JSON, code kiểm tra)
    -> người dùng xem/sửa
    -> POST /slots/suggest      (code gộp khoảng bận, tìm khe sớm nhất)
    -> POST /bookings/confirm   (kiểm tra lại xung đột trên dữ liệu MỚI NHẤT rồi mới lưu)
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse

from .extractor import get_extractor
from .scheduler import (
    Booking,
    Dock,
    Interval,
    ScheduleError,
    busy_intervals,
    conflicts,
    find_slot,
    first_gap,
    within_working_hours,
    working_window,
)
from .schemas import (
    CLOSE_TIME,
    OPEN_TIME,
    WAREHOUSE_TZ,
    BookingRequestExtraction,
    ConfirmRequest,
    ExtractRequest,
    SuggestRequest,
)
from .storage import AuditStore, utc_now_iso
from .validation import REQUEST_ID_RE, parse_aware, validate_request

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent
ROOT_DIR = BASE_DIR.parent

QUESTIONS = {
    "earliest_start": "Xe có thể đến kho sớm nhất lúc mấy giờ, ngày nào?",
    "duration_minutes": "Xe cần dùng cửa kho trong bao nhiêu phút?",
    "dock_type": "Hàng cần cửa thường hay cửa lạnh?",
}


def _error(status: int, message: str, errors: Optional[list[str]] = None, **extra: Any):
    raise HTTPException(status, detail={"message": message, "errors": errors or [], **extra})


def _hm(dt: datetime) -> str:
    return dt.astimezone(WAREHOUSE_TZ).strftime("%H:%M")


def booking_to_dict(b: Booking) -> dict[str, Any]:
    return {
        "booking_id": b.booking_id, "dock_id": b.dock_id, "request_id": b.request_id,
        "carrier": b.carrier, "start": b.start.isoformat(), "end": b.end.isoformat(),
    }


def load_sample() -> tuple[list[Dock], list[Booking]]:
    data = json.loads((ROOT_DIR / "sample_data" / "warehouse.json").read_text("utf-8"))
    docks = [Dock(d["dock_id"], d["dock_type"]) for d in data["docks"]]
    bookings = []
    for b in data["bookings"]:
        start, end = parse_aware(b["start"], "start"), parse_aware(b["end"], "end")
        Interval(start, end)  # kiểm tra end > start
        bookings.append(Booking(b["booking_id"], b["dock_id"], start, end, b.get("request_id"), b.get("carrier")))
    return docks, bookings


def create_app(log_path: Optional[Path] = None, buffer_minutes: Optional[int] = None) -> FastAPI:
    app = FastAPI(title="Bài 02 - Đặt giờ cửa kho", version="1.0.0")
    store = AuditStore(log_path)
    lock = threading.Lock()
    buffer = buffer_minutes if buffer_minutes is not None else int(os.getenv("CLEANING_BUFFER_MINUTES", "0"))
    state: dict[str, Any] = {"counter": 0}
    state["docks"], state["bookings"] = load_sample()
    app.state.state = state

    def next_request_id() -> str:
        used = {b.request_id for b in state["bookings"]} | {r["request_id"] for r in store.all()}
        while True:
            state["counter"] += 1
            rid = f"R{state['counter']:03d}"
            if rid not in used:
                return rid

    def booked_ids() -> set[str]:
        return {b.request_id for b in state["bookings"] if b.request_id}

    def explain(dock_type: str, earliest: datetime, duration: int, chosen) -> list[str]:
        """Mỗi cửa cùng loại: khoảng bận đã gộp và giờ trống sớm nhất."""
        day = earliest.astimezone(WAREHOUSE_TZ).date()
        window = working_window(day)
        lines = []
        for dock in sorted(state["docks"], key=lambda d: d.dock_id):
            if dock.dock_type != dock_type:
                continue
            busy = busy_intervals([b for b in state["bookings"] if b.dock_id == dock.dock_id], day, buffer)
            busy_txt = ", ".join(f"{_hm(iv.start)}–{_hm(iv.end)}" for iv in busy) or "trống cả ngày"
            start = first_gap(busy, earliest.astimezone(WAREHOUSE_TZ), timedelta(minutes=duration), window)
            res = f"sớm nhất {_hm(start)}" if start else "không còn khe đủ dài"
            mark = " → được chọn" if chosen and chosen.dock_id == dock.dock_id else ""
            lines.append(f"Cửa {dock.dock_id}: bận {busy_txt}; {res}{mark}.")
        return lines

    # ------------------------------------------------------------------ pages
    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/config")
    def config() -> dict[str, Any]:
        return {
            "openai_available": bool(os.getenv("OPENAI_API_KEY")),
            "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            "open": OPEN_TIME.strftime("%H:%M"), "close": CLOSE_TIME.strftime("%H:%M"),
            "timezone": "+07:00", "buffer_minutes": buffer,
            "docks": [{"dock_id": d.dock_id, "dock_type": d.dock_type} for d in state["docks"]],
        }

    @app.get("/schema/booking-request")
    def schema() -> dict[str, Any]:
        return BookingRequestExtraction.model_json_schema()

    # ------------------------------------------------------------------ extract
    @app.post("/requests/extract")
    def extract(req: ExtractRequest) -> dict[str, Any]:
        if req.request_id is not None:
            rid = req.request_id.strip()
            if not REQUEST_ID_RE.match(rid):
                _error(422, "Mã yêu cầu không hợp lệ.", ["request_id chỉ gồm chữ, số, '-' hoặc '_'."])
            if rid in booked_ids():
                _error(409, f"Yêu cầu '{rid}' đã được đặt lịch.", [f"request_id '{rid}' bị trùng."])
        else:
            rid = next_request_id()
        try:
            ref = date.fromisoformat(req.reference_date) if req.reference_date else datetime.now(WAREHOUSE_TZ).date()
        except ValueError:
            _error(422, "Ngày tham chiếu không hợp lệ.", ["reference_date phải có dạng YYYY-MM-DD."])
        try:
            extractor = get_extractor(req.mode)
        except RuntimeError as exc:
            _error(400, str(exc))

        started = time.perf_counter()
        result = extractor.extract(rid, req.email, ref)
        latency = int((time.perf_counter() - started) * 1000)

        errors, warnings, missing = [], [], []
        if result.data is not None:
            vr = validate_request(result.data, rid)
            errors, warnings, missing = vr.errors, vr.warnings, vr.missing
        if result.error:
            errors.insert(0, result.error)
        record = store.create(
            request_id=rid, raw_email=req.email, reference_date=ref.isoformat(), source=result.source,
            llm_output=result.data, llm_error=result.error, extract_errors=errors, extract_latency_ms=latency,
        )
        return {
            "extraction_id": record["extraction_id"], "request_id": rid, "source": result.source,
            "extraction": result.data, "errors": errors, "warnings": warnings, "missing": missing,
            "questions": [QUESTIONS[m] for m in missing if m in QUESTIONS], "latency_ms": latency,
        }

    def _validated(extraction_id: Optional[str], request: dict[str, Any]):
        record = store.get(extraction_id) if extraction_id else None
        if extraction_id and record is None:
            _error(404, "Không tìm thấy lượt đọc email này.", [f"extraction_id '{extraction_id}' không tồn tại."])
        vr = validate_request(request, record["request_id"] if record else None)
        if vr.errors:
            _error(422, "Dữ liệu chưa hợp lệ, chưa thể tìm giờ.", vr.errors, warnings=vr.warnings)
        return record, vr

    # ------------------------------------------------------------------ suggest
    @app.post("/slots/suggest")
    def suggest(req: SuggestRequest) -> dict[str, Any]:
        record, vr = _validated(req.extraction_id, req.request)
        if vr.missing:
            return {
                "status": "needs_info", "missing": vr.missing,
                "questions": [QUESTIONS[m] for m in vr.missing if m in QUESTIONS], "warnings": vr.warnings,
            }
        n = vr.normalized
        earliest = datetime.fromisoformat(n["earliest_start"])
        with lock:
            slot = find_slot(state["docks"], state["bookings"], earliest, n["duration_minutes"], n["dock_type"], buffer)
            reasons = explain(n["dock_type"], earliest, n["duration_minutes"], slot)
        if not any(d.dock_type == n["dock_type"] for d in state["docks"]):
            reasons = [f"Kho không có cửa loại {n['dock_type']}."]
        if slot is None:
            out = {"status": "no_slot", "reasons": reasons + [
                f"Không còn khe {n['duration_minutes']} phút trong giờ mở cửa {OPEN_TIME:%H:%M}–{CLOSE_TIME:%H:%M} "
                f"ngày {earliest.astimezone(WAREHOUSE_TZ):%d/%m/%Y}. Hệ thống không tự chuyển sang hôm sau."
            ], "warnings": vr.warnings}
        else:
            if len([r for r in reasons if "sớm nhất" in r]) > 1:
                tied = [r for r in reasons if f"sớm nhất {_hm(slot.start)}" in r]
                if len(tied) > 1:
                    reasons.append(f"Nhiều cửa cùng trống lúc {_hm(slot.start)}: chọn cửa có mã đứng trước theo alphabet.")
            out = {
                "status": "ok", "warnings": vr.warnings, "reasons": reasons,
                "slot": {"dock_id": slot.dock_id, "start": slot.start.isoformat(), "end": slot.end.isoformat()},
            }
        if record:
            store.update(record["extraction_id"], user_edited=req.request, suggestion=out, suggested_at=utc_now_iso())
        return out

    # ------------------------------------------------------------------ confirm
    @app.post("/bookings/confirm")
    def confirm(req: ConfirmRequest) -> dict[str, Any]:
        record, vr = _validated(req.extraction_id, req.request)
        if vr.missing:
            _error(422, "Còn thiếu thông tin, chưa thể đặt lịch.", [f"Thiếu {m}" for m in vr.missing])
        n = vr.normalized
        try:
            start, end = parse_aware(req.start, "start"), parse_aware(req.end, "end")
            iv = Interval(start, end)
        except (ValueError, ScheduleError) as exc:
            _error(422, "Khung giờ đặt không hợp lệ.", [str(exc)])
        errs = []
        if int((end - start).total_seconds() // 60) != n["duration_minutes"]:
            errs.append("Khung giờ không khớp duration_minutes của yêu cầu.")
        if start < datetime.fromisoformat(n["earliest_start"]):
            errs.append("Giờ vào cửa sớm hơn giờ xe có thể đến.")
        if not within_working_hours(iv):
            errs.append(f"Khung giờ nằm ngoài giờ mở cửa {OPEN_TIME:%H:%M}–{CLOSE_TIME:%H:%M}.")
        dock = next((d for d in state["docks"] if d.dock_id == req.dock_id), None)
        if dock is None:
            errs.append(f"Không có cửa '{req.dock_id}'.")
        elif dock.dock_type != n["dock_type"]:
            errs.append(f"Cửa {dock.dock_id} là cửa {dock.dock_type}, yêu cầu cần {n['dock_type']}.")
        if errs:
            _error(422, "Không thể đặt khung giờ này.", errs)

        with lock:  # kiểm tra lại trên dữ liệu MỚI NHẤT, rồi mới lưu
            if n["request_id"] in booked_ids():
                _error(409, f"Yêu cầu '{n['request_id']}' đã được đặt lịch trước đó.")
            clash = conflicts(state["bookings"], req.dock_id, iv, buffer)
            if clash:
                desc = [f"{c.request_id or c.booking_id}: {_hm(c.start)}–{_hm(c.end)}" for c in clash]
                _error(409, f"Cửa {req.dock_id} vừa có lịch trùng giờ. Hãy bấm tìm giờ lại.", desc)
            booking = Booking(f"BK-{uuid.uuid4().hex[:6]}", req.dock_id, start, end, n["request_id"], n["carrier"])
            state["bookings"].append(booking)

        if record:
            store.update(record["extraction_id"], status="booked", user_edited=req.request,
                         final_booking=booking_to_dict(booking), booked_at=utc_now_iso())
        return {"status": "booked", "booking": booking_to_dict(booking)}

    # ------------------------------------------------------------------ schedule + demo
    @app.get("/docks/schedule")
    def schedule(day: str = Query("2026-10-21", alias="date")) -> dict[str, Any]:
        try:
            d = date.fromisoformat(day)
        except ValueError:
            _error(422, "Ngày không hợp lệ.", ["date phải có dạng YYYY-MM-DD."])
        window = working_window(d)
        out = []
        for dock in sorted(state["docks"], key=lambda x: x.dock_id):
            own = sorted((b for b in state["bookings"] if b.dock_id == dock.dock_id
                          and Interval(b.start, b.end).overlaps(window)), key=lambda b: b.start)
            busy = busy_intervals(own, d, buffer)
            out.append({
                "dock_id": dock.dock_id, "dock_type": dock.dock_type,
                "bookings": [booking_to_dict(b) for b in own],
                "busy": [{"start": iv.start.isoformat(), "end": iv.end.isoformat()} for iv in busy],
            })
        return {"date": d.isoformat(), "open": window.start.isoformat(), "close": window.end.isoformat(), "docks": out}

    @app.get("/records")
    def records(limit: int = Query(50, ge=1, le=500)) -> list[dict[str, Any]]:
        return list(reversed(store.all()))[:limit]

    @app.post("/demo/reset")
    def reset() -> dict[str, Any]:
        with lock:
            state["docks"], state["bookings"] = load_sample()
            state["counter"] = 0
            store.clear()
        return {"bookings": len(state["bookings"])}

    return app


app = create_app(Path(os.getenv("AUDIT_LOG_PATH", str(ROOT_DIR / "data" / "audit_log.jsonl"))))
