"""Schema dữ liệu Bài 02 - đặt giờ cửa kho.

- BookingRequestExtraction: mẫu JSON GenAI PHẢI trả.
- Cấu hình kho (giờ mở cửa, múi giờ, danh sách cửa): do CODE quyết định.
"""
from __future__ import annotations

from datetime import time, timedelta, timezone
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

WAREHOUSE_TZ = timezone(timedelta(hours=7))
OPEN_TIME = time(8, 0)
CLOSE_TIME = time(18, 0)
DOCK_TYPES: tuple[str, ...] = ("standard", "refrigerated")
MAX_DURATION_MINUTES = 600  # cả ngày làm việc 08:00-18:00
REQUIRED_FIELDS: tuple[str, ...] = ("earliest_start", "duration_minutes", "dock_type")

DockType = Literal["standard", "refrigerated"]
MissingField = Literal["carrier", "earliest_start", "duration_minutes", "dock_type"]


class BookingRequestExtraction(BaseModel):
    """Thông tin đọc ra từ email đặt lịch. Chỉ điền, không chọn cửa, không chọn giờ."""

    request_id: str = Field(description="Mã yêu cầu hệ thống đã cấp. Chép y nguyên.")
    carrier: Optional[str] = Field(description="Tên nhà vận chuyển. null nếu email không nói.")
    earliest_start: Optional[str] = Field(
        description="Giờ sớm nhất xe có thể đến, ISO 8601 CÓ múi giờ, vd 2026-10-21T09:00:00+07:00. "
        "null nếu email không nói rõ ngày hoặc giờ."
    )
    duration_minutes: Optional[int] = Field(
        description="Số phút cần dùng cửa kho, > 0. null nếu email không nói. KHÔNG đoán từ loại hàng."
    )
    dock_type: Optional[DockType] = Field(
        description="standard = cửa thường, refrigerated = cửa lạnh (hàng đông lạnh/mát). "
        "null nếu không xác định được."
    )
    missing_fields: list[MissingField] = Field(
        description="Tên các trường để null vì email không nói."
    )


# ---------------------------------------------------------------------------
# API models
# ---------------------------------------------------------------------------
class ExtractRequest(BaseModel):
    email: str = Field(min_length=1, max_length=5000)
    request_id: Optional[str] = None
    reference_date: Optional[str] = Field(
        default=None, description="Ngày nhận email (YYYY-MM-DD) để GenAI hiểu 'mai', 'thứ 4'..."
    )
    mode: Literal["auto", "mock", "openai"] = "auto"


class SuggestRequest(BaseModel):
    extraction_id: Optional[str] = None
    request: dict[str, Any]


class ConfirmRequest(BaseModel):
    extraction_id: Optional[str] = None
    request: dict[str, Any]
    dock_id: str
    start: str
    end: str
