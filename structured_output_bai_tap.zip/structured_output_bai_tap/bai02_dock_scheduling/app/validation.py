"""Kiểm tra lại dữ liệu GenAI (hoặc người dùng sửa) cho yêu cầu đặt cửa kho."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional

from .schemas import DOCK_TYPES, MAX_DURATION_MINUTES, REQUIRED_FIELDS, WAREHOUSE_TZ
from .scheduler import working_window

REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
FIELDS = {"request_id", "carrier", "earliest_start", "duration_minutes", "dock_type", "missing_fields"}


@dataclass
class ValidationResult:
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)  # trường bắt buộc chưa có -> hỏi lại người dùng
    normalized: dict[str, Any] = field(default_factory=dict)

    @property
    def ready(self) -> bool:
        """Đủ và đúng để tìm giờ."""
        return not self.errors and not self.missing


def parse_aware(value: Any, name: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} bị thiếu.")
    try:
        dt = datetime.fromisoformat(value.strip())
    except ValueError:
        raise ValueError(f"{name} '{value}' không đúng ISO 8601 (vd 2026-10-21T09:00:00+07:00).")
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError(f"{name} '{value}' thiếu múi giờ (cần dạng ...+07:00).")
    return dt


def validate_request(data: Any, expected_request_id: Optional[str] = None) -> ValidationResult:
    res = ValidationResult()
    if not isinstance(data, dict):
        res.errors.append("Dữ liệu không phải object JSON.")
        return res

    extra = set(data) - FIELDS
    if extra:
        res.warnings.append(f"Bỏ qua trường không có trong mẫu: {sorted(extra)}.")

    rid = data.get("request_id")
    if not isinstance(rid, str) or not REQUEST_ID_RE.match(rid.strip()):
        res.errors.append("request_id chỉ gồm chữ, số, '-' hoặc '_' (tối đa 32 ký tự).")
    elif expected_request_id and rid.strip() != expected_request_id:
        res.errors.append(f"request_id '{rid}' không khớp mã hệ thống đã cấp '{expected_request_id}'.")
    res.normalized["request_id"] = rid.strip() if isinstance(rid, str) else rid

    carrier = data.get("carrier")
    if carrier is not None and not isinstance(carrier, str):
        res.errors.append("carrier phải là chuỗi hoặc null.")
    res.normalized["carrier"] = (" ".join(carrier.split()) or None) if isinstance(carrier, str) else None

    # earliest_start
    es = data.get("earliest_start")
    if es is None or (isinstance(es, str) and not es.strip()):
        res.missing.append("earliest_start")
        res.normalized["earliest_start"] = None
    else:
        try:
            dt = parse_aware(es, "earliest_start")
            local = dt.astimezone(WAREHOUSE_TZ)
            if dt.utcoffset() != local.utcoffset():
                res.warnings.append(
                    f"earliest_start dùng múi giờ khác kho; đã quy đổi sang giờ kho {local:%H:%M %d/%m} (+07:00)."
                )
            window = working_window(local.date())
            if local >= window.end:
                res.warnings.append("Xe đến sau giờ đóng cửa 18:00: sẽ không còn chỗ trong ngày.")
            elif local < window.start:
                res.warnings.append("Xe đến trước 08:00: lịch sẽ tính từ lúc mở cửa 08:00.")
            res.normalized["earliest_start"] = local.isoformat()
        except ValueError as exc:
            res.errors.append(str(exc))
            res.normalized["earliest_start"] = es

    # duration_minutes
    dur = data.get("duration_minutes")
    if dur is None:
        res.missing.append("duration_minutes")
    elif isinstance(dur, bool) or not isinstance(dur, int):
        res.errors.append("duration_minutes phải là số nguyên (phút).")
    elif dur <= 0:
        res.errors.append(f"duration_minutes = {dur}: phải lớn hơn 0.")
    elif dur > MAX_DURATION_MINUTES:
        res.errors.append(f"duration_minutes = {dur}: vượt quá cả ngày làm việc ({MAX_DURATION_MINUTES} phút).")
    res.normalized["duration_minutes"] = dur

    dock_type = data.get("dock_type")
    if dock_type is None:
        res.missing.append("dock_type")
    elif dock_type not in DOCK_TYPES:
        res.errors.append(f"dock_type '{dock_type}' không thuộc danh sách cho phép {list(DOCK_TYPES)}.")
    res.normalized["dock_type"] = dock_type

    # missing_fields phải khớp với các trường null
    declared = data.get("missing_fields", [])
    if not isinstance(declared, list):
        res.errors.append("missing_fields phải là danh sách.")
        declared = []
    actually_null = {f for f in REQUIRED_FIELDS if data.get(f) is None}
    if data.get("carrier") is None:
        actually_null.add("carrier")
    undeclared = actually_null - set(declared)
    wrong = {f for f in declared if f in FIELDS and data.get(f) is not None}
    if undeclared:
        res.warnings.append(f"Trường đang null nhưng chưa ghi vào missing_fields: {sorted(undeclared)}.")
    if wrong:
        res.warnings.append(f"missing_fields ghi {sorted(wrong)} nhưng các trường này đã có giá trị.")
    res.normalized["missing_fields"] = sorted(actually_null)
    return res
