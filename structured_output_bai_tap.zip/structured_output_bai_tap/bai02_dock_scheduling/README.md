# Bài 02 - Xe giao hàng nên vào cửa kho lúc mấy giờ?

Trang web đọc email đặt lịch của nhà vận chuyển bằng GenAI (OpenAI qua LangChain), cho nhân viên kho xem và sửa, rồi code **gộp khoảng bận** của từng cửa và tìm khe trống sớm nhất trong giờ 08:00–18:00. Khi xác nhận, backend kiểm tra lại xung đột trên dữ liệu mới nhất trước khi lưu.

![Luồng chính](docs/screenshot.png)

## Cấu trúc

```
bai02_dock_scheduling/
├── app/
│   ├── schemas.py      # Mẫu JSON GenAI phải trả + cấu hình kho (giờ mở cửa, múi giờ)
│   ├── extractor.py    # GenAI: LangChain with_structured_output + MockExtractor (regex)
│   ├── validation.py   # Kiểm tra lại dữ liệu GenAI / người dùng sửa
│   ├── scheduler.py    # THUẬT TOÁN: Interval, merge_intervals, first_gap, find_slot, conflicts
│   ├── storage.py      # Lưu vết data/audit_log.jsonl
│   ├── main.py         # FastAPI
│   └── static/index.html
├── tests/
│   ├── test_scheduler.py   # Test thuật toán, không phụ thuộc GenAI
│   └── test_api.py         # Test validation + API (mock)
├── sample_data/
│   ├── warehouse.json  # Cửa A, B (thường), C (lạnh) và lịch có sẵn ngày 21/10/2026
│   └── emails.json     # Email thử
└── docs/booking_request.schema.json   # Mẫu dữ liệu GenAI phải trả
```

## Cài đặt và chạy

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # điền OPENAI_API_KEY (không bắt buộc)
uvicorn app.main:app --reload      # http://localhost:8000
pytest -q
```

Không có `OPENAI_API_KEY` thì app dùng **MockExtractor** (đọc bằng regex, đủ cho email mẫu), nên chạy được cả luồng mà không tốn tiền.

## Luồng sử dụng

1. Chọn chip **R01 trong đề** → **Đọc email** → **Tìm giờ trống**. Kết quả: cửa B, 10:15–11:15, kèm lý do từng cửa (A bận liên tục 09:00–11:00 vì hai lịch nối sát được gộp).
2. Bấm **Đặt cửa B lúc 10:15**. Đọc lại cùng email với mã khác: gợi ý đổi thành cửa A lúc 11:00.
3. Chip **Thiếu thời lượng**: app không đoán, mà hỏi lại "Xe cần dùng cửa kho trong bao nhiêu phút?".
4. Chip **Gần giờ đóng cửa**: trả `no_slot`, không tự chuyển sang hôm sau.
5. Hai người cùng đặt một giờ: người thứ hai nhận 409 và được nhắc tìm giờ lại.

## API

| Method | Đường dẫn | Việc làm |
|---|---|---|
| POST | `/requests/extract` | Nhận `email`, `request_id?`, `reference_date?`, `mode`. GenAI điền mẫu, code kiểm tra, trả lỗi + trường còn thiếu + câu hỏi lại. |
| POST | `/slots/suggest` | Nhận bản người dùng đã sửa. Trả `ok` + slot + lý do, `needs_info` + câu hỏi, hoặc `no_slot`. |
| POST | `/bookings/confirm` | Nhận `request`, `dock_id`, `start`, `end`. Kiểm tra lại toàn bộ và xung đột trên dữ liệu mới nhất (có khóa), rồi mới lưu. Xung đột → 409. |
| GET | `/docks/schedule?date=YYYY-MM-DD` | Lịch từng cửa: booking và khoảng bận đã gộp. |
| GET | `/records` | Lịch sử: email gốc, JSON GenAI, bản sửa, gợi ý, booking cuối, thời gian. |
| GET | `/schema/booking-request` | JSON Schema GenAI phải trả. |
| POST | `/demo/reset` | Khôi phục lịch mẫu. |

## Mẫu dữ liệu GenAI phải trả

```json
{
  "request_id": "R01",
  "carrier": "ACME Logistics",
  "earliest_start": "2026-10-21T09:00:00+07:00",
  "duration_minutes": 60,
  "dock_type": "standard",
  "missing_fields": []
}
```

`dock_type` khai báo bằng `Literal["standard", "refrigerated"]`, `missing_fields` là danh sách tên trường hợp lệ. Trường chưa biết để `null`. Prompt cấm GenAI đoán thời lượng từ loại hàng, và gửi kèm ngày tham chiếu để GenAI hiểu "mai", "thứ 4".

## Thuật toán

Mọi khoảng thời gian là nửa mở `[start, end)`: xe rời cửa lúc 10:00 và xe sau vào lúc 10:00 là hợp lệ.

1. **Gộp khoảng bận** (`merge_intervals`): sắp xếp booking của cửa theo giờ bắt đầu, rồi gộp các khoảng giao nhau hoặc nối sát (`next.start <= current.end`). 09:00–10:00 và 10:00–11:00 thành 09:00–11:00.
2. **Tìm khe** (`first_gap`): con trỏ `t` bắt đầu từ `max(giờ xe đến, 08:00)`. Duyệt các khoảng bận: nếu khe trước khoảng bận đủ dài thì dừng, ngược lại nhảy `t` tới cuối khoảng bận. Cuối cùng kiểm tra `t + duration <= 18:00`.
3. **Chọn cửa** (`find_slot`): chỉ xét cửa đúng loại, duyệt theo mã alphabet và chỉ thay kết quả khi tìm được giờ sớm hơn hẳn. Vì vậy hai cửa cùng giờ thì cửa có mã đứng trước thắng.
4. **Xác nhận**: dưới `threading.Lock`, kiểm tra `conflicts()` trên danh sách booking hiện tại rồi mới thêm. Hai request cùng giờ thì một cái thắng, cái còn lại nhận 409.

Độ phức tạp với n lịch: sắp xếp O(n log n), gộp và quét O(n).

Chỉ tìm trong ngày của `earliest_start` (theo giờ kho +07:00). Hết chỗ thì trả `no_slot`, không tự chuyển sang hôm sau. Giờ ở múi giờ khác được quy đổi sang +07:00 và có cảnh báo.

**Làm thêm, thời gian dọn cửa:** đặt `CLEANING_BUFFER_MINUTES=15` trong `.env`. Mỗi booking có sẵn được nới thêm 15 phút ở hai đầu trước khi gộp, nên giữa hai xe luôn có ít nhất 15 phút. Cửa lạnh `C` đã có sẵn trong dữ liệu mẫu.

## Kiểm tra dữ liệu

- `request_id` đúng mã hệ thống đã cấp; mã đã đặt lịch → 409.
- `earliest_start` là ISO 8601 có múi giờ; thiếu múi giờ → lỗi.
- `duration_minutes` là số nguyên, lớn hơn 0 và không quá 600.
- `dock_type` thuộc danh sách cho phép.
- Trường bắt buộc còn `null` → `needs_info` kèm câu hỏi lại, không đoán.
- Khi xác nhận: `end > start`, khớp thời lượng, không sớm hơn giờ xe đến, trong giờ mở cửa, đúng loại cửa, không trùng lịch.

## Test

40 test:

- **Ca thường:** R01 ra cửa B 10:15; lịch nối sát được gộp; đặt xong thì gợi ý kế tiếp đổi sang A 11:00; dùng được khe trước booking đầu tiên; hàng lạnh chỉ vào cửa lạnh.
- **Ca sát giới hạn:** lịch kết thúc đúng lúc lịch mới bắt đầu không bị báo trùng; khe vừa đúng bằng thời lượng; kết thúc đúng 18:00; xe đến trước 08:00; hai cửa cùng giờ thì chọn theo alphabet; quy đổi múi giờ; thời gian dọn cửa.
- **Dữ liệu sai:** kết thúc trước bắt đầu, khoảng dài 0, thiếu múi giờ, thời lượng 0/âm/thập phân/chuỗi, loại cửa sai, thiếu thời lượng, hết chỗ, hai người cùng đặt một giờ, mã trùng.

## GenAI làm gì, code làm gì?

**GenAI** chỉ đọc email tự do và điền vào mẫu: ai giao, đến lúc nào, cần bao lâu, hàng thường hay hàng lạnh. Thông tin nào email không nói thì để `null` và ghi vào `missing_fields`.

**Code** quyết định mọi thứ liên quan tới lịch: kiểm tra định dạng và giờ làm việc, gộp khoảng bận, tìm khe sớm nhất, áp quy tắc chọn cửa, và chặn đặt trùng bằng cách kiểm tra lại dưới khóa ngay trước khi lưu.

**Con người** xem và sửa kết quả đọc, trả lời câu hỏi khi email thiếu thông tin, rồi bấm xác nhận.
