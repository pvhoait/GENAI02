"""Test API Bài 02 ở chế độ mock (không tốn tiền gọi model)."""
import pytest
from fastapi.testclient import TestClient

from app.main import create_app
from app.validation import validate_request

EMAIL_R01 = "Bên ACME Logistics báo: xe tôi đến từ 9 giờ ngày 21/10/2026, cần một tiếng để dỡ hàng."


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    return TestClient(create_app(tmp_path / "audit.jsonl", buffer_minutes=0))


def extract(client, email=EMAIL_R01, rid="R01"):
    r = client.post("/requests/extract", json={"email": email, "request_id": rid, "reference_date": "2026-10-21", "mode": "mock"})
    assert r.status_code == 200, r.text
    return r.json()


def test_full_flow_R01(client):
    ex = extract(client)
    assert ex["extraction"]["duration_minutes"] == 60 and ex["errors"] == []
    sug = client.post("/slots/suggest", json={"extraction_id": ex["extraction_id"], "request": ex["extraction"]}).json()
    assert sug["status"] == "ok"
    assert sug["slot"] == {"dock_id": "B", "start": "2026-10-21T10:15:00+07:00", "end": "2026-10-21T11:15:00+07:00"}
    assert any("Cửa A: bận 09:00–11:00" in r for r in sug["reasons"])  # hai lịch nối sát -> một khoảng bận
    ok = client.post("/bookings/confirm", json={"extraction_id": ex["extraction_id"], "request": ex["extraction"], **sug["slot"]})
    assert ok.status_code == 200

    # Xe khác hỏi lại cùng giờ -> kết quả phải đổi
    ex2 = extract(client, rid="R09")
    sug2 = client.post("/slots/suggest", json={"request": ex2["extraction"]}).json()
    assert (sug2["slot"]["dock_id"], sug2["slot"]["start"][11:16]) == ("A", "11:00")


def test_missing_duration_asks_user(client):
    ex = extract(client, "Nhà xe Delta Freight tới lúc 13:30 ngày 21/10/2026.", "R02")
    assert ex["missing"] == ["duration_minutes"]
    sug = client.post("/slots/suggest", json={"request": ex["extraction"]}).json()
    assert sug["status"] == "needs_info" and sug["questions"]


def test_two_people_book_same_slot_second_gets_409(client):
    ex1, ex2 = extract(client, rid="R11"), extract(client, rid="R12")
    sug = client.post("/slots/suggest", json={"request": ex1["extraction"]}).json()
    # Cả hai cùng nhận gợi ý B 10:15 trước khi ai đó xác nhận
    r1 = client.post("/bookings/confirm", json={"request": ex1["extraction"], **sug["slot"]})
    r2 = client.post("/bookings/confirm", json={"request": ex2["extraction"], **sug["slot"]})
    assert r1.status_code == 200 and r2.status_code == 409


def test_no_slot_does_not_move_to_next_day(client):
    ex = extract(client, "Bên Omega đến từ 5 giờ chiều ngày 21/10/2026, cần 2 tiếng.", "R04")
    sug = client.post("/slots/suggest", json={"request": ex["extraction"]}).json()
    assert sug["status"] == "no_slot"


def test_end_before_start_rejected(client):
    ex = extract(client)
    r = client.post("/bookings/confirm", json={"request": ex["extraction"], "dock_id": "B",
                                               "start": "2026-10-21T12:00:00+07:00", "end": "2026-10-21T11:00:00+07:00"})
    assert r.status_code == 422 and "phải sau" in r.json()["detail"]["errors"][0]


def test_naive_time_rejected_on_suggest(client):
    req = {**extract(client)["extraction"], "earliest_start": "2026-10-21T09:00:00"}
    r = client.post("/slots/suggest", json={"request": req})
    assert r.status_code == 422 and "múi giờ" in r.json()["detail"]["errors"][0]


def test_wrong_dock_type_on_confirm(client):
    ex = extract(client)
    r = client.post("/bookings/confirm", json={"request": ex["extraction"], "dock_id": "C",
                                               "start": "2026-10-21T13:00:00+07:00", "end": "2026-10-21T14:00:00+07:00"})
    assert r.status_code == 422


def test_duplicate_request_id_rejected(client):
    ex = extract(client)
    sug = client.post("/slots/suggest", json={"request": ex["extraction"]}).json()
    client.post("/bookings/confirm", json={"request": ex["extraction"], **sug["slot"]})
    r = client.post("/requests/extract", json={"email": EMAIL_R01, "request_id": "R01", "mode": "mock"})
    assert r.status_code == 409


@pytest.mark.parametrize("patch, expected", [
    ({"duration_minutes": 0}, "lớn hơn 0"),
    ({"duration_minutes": -15}, "lớn hơn 0"),
    ({"duration_minutes": "60"}, "số nguyên"),
    ({"dock_type": "frozen"}, "dock_type"),
    ({"earliest_start": "21/10/2026 9h"}, "ISO 8601"),
])
def test_validation_errors(patch, expected):
    base = {"request_id": "R01", "carrier": "ACME", "earliest_start": "2026-10-21T09:00:00+07:00",
            "duration_minutes": 60, "dock_type": "standard", "missing_fields": []}
    res = validate_request({**base, **patch}, "R01")
    assert any(expected in e for e in res.errors)


def test_audit_record(client):
    ex = extract(client)
    sug = client.post("/slots/suggest", json={"extraction_id": ex["extraction_id"], "request": ex["extraction"]}).json()
    client.post("/bookings/confirm", json={"extraction_id": ex["extraction_id"], "request": ex["extraction"], **sug["slot"]})
    rec = client.get("/records").json()[0]
    assert rec["raw_email"] and rec["llm_output"] and rec["final_booking"] and rec["status"] == "booked"
