"""Test thuật toán Bài 02 - không gọi GenAI."""
from datetime import datetime, timedelta, timezone

import pytest

from app.scheduler import (
    Booking,
    Dock,
    Interval,
    ScheduleError,
    conflicts,
    find_slot,
    merge_intervals,
)

VN = timezone(timedelta(hours=7))
DOCKS = [Dock("A", "standard"), Dock("B", "standard"), Dock("C", "refrigerated")]


def t(h, m=0, day=21, tz=VN):
    return datetime(2026, 10, day, h, m, tzinfo=tz)


def bk(dock, h1, m1, h2, m2, bid=None):
    return Booking(bid or f"{dock}{h1}{m1}", dock, t(h1, m1), t(h2, m2))


SAMPLE = [bk("A", 9, 0, 10, 0), bk("A", 10, 0, 11, 0), bk("B", 9, 30, 10, 15)]


# ----------------------------------------------------------------- ca thường
def test_sample_R01_gets_dock_B_at_1015():
    slot = find_slot(DOCKS, SAMPLE, t(9), 60, "standard")
    assert (slot.dock_id, slot.start, slot.end) == ("B", t(10, 15), t(11, 15))


def test_touching_bookings_merge_into_one_busy_block():
    merged = merge_intervals([Interval(t(10), t(11)), Interval(t(9), t(10))])
    assert merged == [Interval(t(9), t(11))]


def test_overlapping_and_nested_merge():
    merged = merge_intervals([Interval(t(9), t(12)), Interval(t(10), t(11)), Interval(t(11, 30), t(13)), Interval(t(14), t(15))])
    assert merged == [Interval(t(9), t(13)), Interval(t(14), t(15))]


def test_result_changes_after_booking_is_added():
    first = find_slot(DOCKS, SAMPLE, t(9), 60, "standard")
    after = SAMPLE + [Booking("R01", first.dock_id, first.start, first.end)]
    second = find_slot(DOCKS, after, t(9), 60, "standard")
    assert (second.dock_id, second.start) == ("A", t(11))


def test_gap_before_first_booking_is_used():
    slot = find_slot(DOCKS, SAMPLE, t(8), 60, "standard")
    assert (slot.dock_id, slot.start) == ("A", t(8))


def test_refrigerated_only_uses_cold_docks():
    bookings = SAMPLE + [bk("C", 8, 0, 12, 0)]
    slot = find_slot(DOCKS, bookings, t(8), 90, "refrigerated")
    assert (slot.dock_id, slot.start) == ("C", t(12))


# ----------------------------------------------------------- ca sát giới hạn
def test_booking_ending_exactly_at_new_start_is_not_conflict():
    assert conflicts(SAMPLE, "A", Interval(t(11), t(12))) == []
    assert conflicts(SAMPLE, "A", Interval(t(10, 59), t(12)))  # chồng 1 phút


def test_gap_exactly_equal_to_duration_is_used():
    bookings = [bk("A", 8, 0, 9, 0), bk("A", 10, 0, 18, 0), bk("B", 8, 0, 18, 0)]
    slot = find_slot(DOCKS, bookings, t(8), 60, "standard")
    assert (slot.dock_id, slot.start, slot.end) == ("A", t(9), t(10))


def test_slot_ending_exactly_at_close_is_allowed():
    slot = find_slot(DOCKS, [], t(17), 60, "standard")
    assert slot.end == t(18)


def test_no_slot_when_past_close_and_not_moved_to_next_day():
    assert find_slot(DOCKS, [], t(17, 30), 60, "standard") is None


def test_no_slot_when_all_docks_full():
    full = [bk("A", 8, 0, 18, 0), bk("B", 8, 0, 18, 0)]
    assert find_slot(DOCKS, full, t(8), 15, "standard") is None


def test_tie_on_time_picks_alphabetical_dock():
    slot = find_slot([Dock("B", "standard"), Dock("A", "standard")], [], t(9), 60, "standard")
    assert slot.dock_id == "A"


def test_arrival_before_open_starts_at_open():
    assert find_slot(DOCKS, [], t(6), 30, "standard").start == t(8)


def test_other_timezone_converted_to_warehouse_time():
    utc_0200 = datetime(2026, 10, 21, 2, 0, tzinfo=timezone.utc)  # = 09:00 +07:00
    slot = find_slot(DOCKS, SAMPLE, utc_0200, 60, "standard")
    assert slot.start == t(10, 15)


def test_cleaning_buffer_extends_busy_time():
    slot = find_slot(DOCKS, SAMPLE, t(9), 60, "standard", buffer_minutes=15)
    # B bận 09:30-10:15 + 15' dọn -> 10:30; A bận tới 11:00 + 15' -> 11:15
    assert (slot.dock_id, slot.start) == ("B", t(10, 30))


def test_bookings_on_other_days_ignored():
    other_day = [Booking("X", "A", t(8, day=22), t(18, day=22))]
    assert find_slot(DOCKS, other_day, t(8), 60, "standard").dock_id == "A"


# ------------------------------------------------------------- dữ liệu sai
def test_end_before_start_rejected():
    with pytest.raises(ScheduleError, match="phải sau"):
        Interval(t(10), t(9))


def test_zero_length_rejected():
    with pytest.raises(ScheduleError):
        Interval(t(10), t(10))


def test_naive_datetime_rejected():
    with pytest.raises(ScheduleError, match="múi giờ"):
        find_slot(DOCKS, [], datetime(2026, 10, 21, 9, 0), 60, "standard")


@pytest.mark.parametrize("bad", [0, -30, None, 1.5, True])
def test_invalid_duration_rejected(bad):
    with pytest.raises(ScheduleError):
        find_slot(DOCKS, [], t(9), bad, "standard")


def test_invalid_dock_type_rejected():
    with pytest.raises(ScheduleError):
        find_slot(DOCKS, [], t(9), 60, "frozen")


def test_performance_many_bookings():
    import time

    bookings = [Booking(f"b{i}", "A", t(8) + timedelta(seconds=i), t(8) + timedelta(seconds=i + 30)) for i in range(0, 36000, 2)]
    start = time.perf_counter()
    find_slot([Dock("A", "standard")], bookings, t(8), 60, "standard")
    assert time.perf_counter() - start < 2
